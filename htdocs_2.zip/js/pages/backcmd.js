$(document).ready(function(){
    var dataTableBackcmd = $('#backcmd').DataTable({
        "autoWidth": true,
        "serverSide": true,
        "paging": true,
        "ajax": {
            "url": "/backcmd/getbackcmd",
            "type": "POST",
            "dataType": "json",
            "contentType": 'application/x-www-form-urlencoded; charset=UTF-8'
        }
    });
});