$(document).ready(function(){
    var dataTableSocks = $('#socks').DataTable({
        //"processing": true,
        "autoWidth": true,
        "serverSide": true,
        "paging": true,
        /*"iDisplayLength": "10",
        "pageLength": 10,*/
        "ajax": {
            "url": "/socks/getsocks",
            "type": "POST",
            "dataType": "json",
            "contentType": 'application/x-www-form-urlencoded; charset=UTF-8'
        }
    });
});