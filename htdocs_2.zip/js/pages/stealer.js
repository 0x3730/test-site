var passwordsDataPagination;
var getPasswordsData;
var searchPasswords;

$(document).ready(function() {
    var $passwordsDataContainer = $('#passwords-data-container');
    var $passwordsDataPaginationView = $('#passwords-data-pagination');
    var passwordsDataPageSize = 10;
    if ($passwordsDataContainer.length && $passwordsDataPaginationView.length) {
        passwordsDataPagination = createPagination(
            $passwordsDataPaginationView,
            '/stealer/get_passwords_data',
            passwordsDataPageSize,
            $passwordsDataContainer,
            $('#passwords_filter').length ? $('#passwords_filter').val() : '',
            getPasswordsFiltersJson()
        );
    }

    searchPasswords = function(isAdditionalSearch) {
        if (isAdditionalSearch === true && $('#passwords_filter').length) {
            $('#passwords_filter').val('');
        } else {
            $('#passwords_filter_service').val('');
            $('#passwords_filter_login').val('');
            $('#passwords_filter_browser').val('');
        }
        getPasswordsData();
    };

    getPasswordsData = function() {
        $passwordsDataPaginationView.pagination('destroy');
        passwordsDataPagination = createPagination(
            $passwordsDataPaginationView,
            '/stealer/get_passwords_data',
            passwordsDataPageSize,
            $passwordsDataContainer,
            $('#passwords_filter').length ? $('#passwords_filter').val() : '',
            getPasswordsFiltersJson()
        );
    };

    function getPasswordsFiltersJson()
    {
        const filters = [
            {
                name: 'botid',
                value: $('#forms_filter_bot_id').val()
            },
            {
                name: 'service',
                value: $('#passwords_filter_service').val()
            },
            {
                name: 'login',
                value: $('#passwords_filter_login').val()
            },
            {
                name: 'browser',
                value: $('#passwords_filter_browser').val()
            }
        ];
        return JSON.stringify(Object.assign({}, filters));
    }

    // forms grabber end
    function createPagination($paginationView, url, pageSize, $dataContainer, filter, additional_filters) {
        filter = filter || '';
        additional_filters = additional_filters || '';
        return $paginationView.pagination({
            dataSource: url,
            locator: 'items',
            showNavigator: true,
            showPageNumbers: true,
            showPrevious: true,
            showNext: true,
            totalNumberLocator: function(response) {
                return response['totalCount'];
            },
            pageSize: pageSize,
            ajax: {
                beforeSend: function() {
                    $dataContainer.html('');
                },
                data: {
                    additional_filters: Base64.encode(additional_filters),
                    filter: Base64.encode(filter)
                }
            },
            callback: function(data, pagination) {
                var dataHtml = '';
                $.each(data, function (index, item) {
                    dataHtml += item;
                });
                $dataContainer.html(dataHtml);
            }
        });
    }
});