$('#delete-group').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();
    arrValues['group_id'] = $('#group_id').val();

    $.ajax({
        type: "post",
        url: "/edit_group/group_delete",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                groupInfo.updateGroupInfo();
                $.jGrowl('Group delete.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                groupInfo.updateGroupInfo();
                $.jGrowl('Group no delete.', {sticky: false, theme: 'growl-error', header: 'Success!', life: 3000});
            }
        }
    })
});

$('#edit-group').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();
    arrValues['group_id'] = $('#group_id').val();
    arrValues['name_group'] = $('#name_group').val();
    arrValues['list_install_app'] = $('#list_install_software').val();
    arrValues['list_url_form_grabber'] = $('#list_url_form_grabber').val();
    arrValues['list_os'] = $('#list_os').val();
    arrValues['list_domain_netview'] = $('#list_netview_domain').val();

    $.ajax({
        type: "post",
        url: "/edit_group/edit_group",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                groupInfo.updateGroupInfo();
                $.jGrowl('Group edit.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                groupInfo.updateGroupInfo();
                $.jGrowl('Group no edit.', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
});