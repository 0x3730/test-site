$(document).ready(function () {
    groupsList.updateGroups();
});

const groupsList = {
    updateGroups: function () {
        $.get(document.location.pathname + '/get_groups_list')
            .success(function (res) {
                $('[data-groups-list]').empty();
                $('[data-groups-list]').append(res);
            });
    }
};

$('#add-group-head-button').click(function () {
    window.location.href = 'add_group';
});

function deleteGroup(id) {
    $.ajax({
        type: 'get',
        url: 'group_bots/group_delete',
        data: 'group_id=' + id,
        headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
        success: function (res) {
            if (res === '1') {
                groupsList.updateGroups();
                $.jGrowl('Group delete.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                groupsList.updateGroups();
                $.jGrowl('Group no delete', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    });
}