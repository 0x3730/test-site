var screenshotsDataPagination;
var getScreenshotsData;
var searchScreenshots;

$(document).ready(function(){
    var $screenshotsDataContainer1 = $('#screenshots-data-container-1');
    var $screenshotsDataContainer2 = $('#screenshots-data-container-2');
    var $screenshotsDataPaginationView = $('#screenshots-data-pagination');
    var screenshotsDataPageSize = 10;
    /*$('[data-type-web-inject]').on('click', () => {
        if (window.CBPGridGalleryCustom != null && window.CBPGridGalleryCustom.masonry != null) {
            if (window.CBPGridGalleryCustom.masonry.maxY < 0) {
                setTimeout(() => {
                    window.CBPGridGalleryCustom.masonry.resize();
                }, 500);
            }
        }
    });*/

    if ($screenshotsDataContainer1.length && $screenshotsDataContainer2.length && $screenshotsDataPaginationView.length) {
        screenshotsDataPagination = createCustomP({
            $paginationView: $screenshotsDataPaginationView,
            url: '/screenshots/get_screenshots_data',
            pageSize: screenshotsDataPageSize,
            $dataContainers: [$screenshotsDataContainer1,$screenshotsDataContainer2],
            filter: $('#screenshots_filter').length ? $('#screenshots_filter').val() : '',
            callbackBefore: () => {
                //window.CBPGridGalleryCustom.destroy();
            },
            callbackAfter: () => {
                $(function(){
                    "use strict";
                    if (window.CBPGridGalleryCustom == null) {
                        window.CBPGridGalleryCustom = new CBPGridGallery(document.getElementById( 'grid-gallery' ));
                    }
                    window.CBPGridGalleryCustom.init(document.getElementById( 'grid-gallery' ));
                });
            }
        })
    }

    searchScreenshots = function(isAdditionalSearch) {
        if (isAdditionalSearch === true && $('#screenshots_filter').length) {
            $('#screenshots_filter').val('');
        }
        getScreenshotsData();
    };

    getScreenshotsData = function() {
        $screenshotsDataPaginationView.pagination('destroy');
        screenshotsDataPagination = createCustomP({
            $paginationView: $screenshotsDataPaginationView,
            url: '/screenshots/get_screenshots_data',
            pageSize: screenshotsDataPageSize,
            $dataContainers: [$screenshotsDataContainer1,$screenshotsDataContainer2],
            filter: $('#screenshots_filter').length ? $('#screenshots_filter').val() : '',
            callbackBefore: () => {
                //window.CBPGridGalleryCustom.destroy();
            },
            callbackAfter: () => {
                $(function(){
                    "use strict";
                    if (window.CBPGridGalleryCustom == null) {
                        window.CBPGridGalleryCustom = new CBPGridGallery(document.getElementById( 'grid-gallery' ));
                    }
                    window.CBPGridGalleryCustom.init(document.getElementById( 'grid-gallery' ));
                });
            }
        });
    };
});