$('#report_status').on("change", function() {
    if ($('#report_status').val() == 1) {
        $('#report_level').prop( "disabled", false );
    } else {
        $('#report_level').prop( "disabled", true );
    }
    var settingVal = $(this).val();
    var settingName = $(this).attr('id');
    console.log(settingName + ' - ' + settingVal);
    updSetting(settingName, settingVal);
});

$('#report_level').on("change", function(e) {
    var settingVal = $(this).val();
    var settingName = $(this).attr('id');
    console.log(settingName + ' - ' + settingVal);
    updSetting(settingName, settingVal);
});

$('#gate_status').on("change", function(e) {
    var settingVal = $(this).val();
    var settingName = $(this).attr('id');
    console.log(settingName + ' - ' + settingVal);
    updSetting(settingName, settingVal);
});

$('#knock_timeout').on("change", function(e) {
    var settingVal = $(this).val();
    var settingName = $(this).attr('id');
    console.log(settingName + ' - ' + settingVal);
    updSetting(settingName, settingVal);
});

$('#lifetime').on("change", function(e) {
    var settingVal = $(this).val();
    var settingName = $(this).attr('id');
    console.log(settingName + ' - ' + settingVal);
    updSetting(settingName, settingVal);
});

function updSetting(setting_name, setting_value) {
    $.ajax({
        type: "get",
        url: "/settings/update_setting",
        data: "setting_name="+setting_name+"&setting_value="+setting_value,
        success: function(res) {
            if (res == '1')
                $.jGrowl('Setting updated.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 1000 });
            else
                $.jGrowl('Setting not updated.', { sticky: false, theme: 'growl-error', header: 'Success!', life: 1000 });
        }
    });
}

function updModules() {
    $.ajax({
        type: "post",
        url: "/settings/update_modules",
        success: function(res) {
            if (res == '1')
                $.jGrowl('Hashes are updated.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 1000 });
            else
                $.jGrowl('Hashes are not updated.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 1000 });
        }
    });
    return false;
}