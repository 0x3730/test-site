$(document).ready(function(){

    $('#form-web-injects-group-new').on('submit', function(el) {
        var data = [];
        data['name'] = $('#new-webinject-group-name').val();
        data['description'] = $('#new-webinject-group-description').val();

        var $injects = $('#web-injects-new-group').find('[data-webinject-checkbox]');

        var injects = [];
        $injects.each(function(ind, element) {
            if (element.checked === true) {
                injects.push($(element).data('webinject-checkbox'));
            }
        });
        data['injects'] = JSON.stringify(injects);
        $.ajax({
            type: "post",
            url: "/webinjects_main/create_group",
            data: Object.assign({}, data),
            success: function(res) {
                if (res == '1') {
                    $('#web-injects-new-group').modal('hide');
                    $('#new-webinject-group-name').val('');
                    $('#new-webinject-group-description').val('');
                    $injects.each(function(ind, element) {
                        $(element).parent().removeClass('checked');
                    });
                    loadGroupsList();
                    dataTableWebInjectsGroups.draw();
                    $.jGrowl('Group was create successfully.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                } else {
                    $.jGrowl('Group was not create.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
                }
            }
        });
        el.preventDefault();
    });
});