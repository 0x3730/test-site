$(document).ready(function(){
    $('#form-web-injects-group-edit').on('submit', function(el) {
        $form = $(this);
        var data = [];
        data['id'] = $('#edit-webinject-group-id').val();
        data['name'] = $('#edit-webinject-group-name').val();
        data['description'] = $('#edit-webinject-group-description').val();
        $.ajax({
            type: "post",
            url: "/webinjects_main/update_group",
            data: Object.assign({}, data),
            success: function(res) {
                if (res == '1') {
                    $('#web-injects-edit-group').modal('hide');
                    $form.trigger('reset');
                    dataTableWebInjectsGroups.draw();
                    dataTableWebInjectsCampaigns.draw();
                    $.jGrowl('Group was update successfully.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                } else {
                    $.jGrowl('Group was not update.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
                }
            }
        });
        el.preventDefault();
    });
});