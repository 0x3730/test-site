function createCustomPagination($paginationView, url, pageSize, $dataContainer, filter, additional_filters, callback) {
    filter = filter || '';
    additional_filters = additional_filters || '';
    return $paginationView.pagination({
        dataSource: url,
        locator: 'items',
        showNavigator: true,
        showPageNumbers: true,
        showPrevious: true,
        showNext: true,
        totalNumberLocator: function(response) {
            return response['totalCount'];
        },
        pageSize: pageSize,
        ajax: {
            beforeSend: function() {
                $dataContainer.html('');
            },
            data: {
                additional_filters: Base64.encode(additional_filters),
                filter: Base64.encode(filter)
            }
        },
        callback: function(data, pagination) {
            var dataHtml = '';
            $.each(data, function (index, item) {
                dataHtml += item;
            });
            $dataContainer.html(dataHtml);
            callback();
        }
    });
}

function createCustomP(params) {
    var parameters = {
        $paginationView: null,
        url: null,
        pageSize: null,
        $dataContainers: null,
        filter: null,
        additional_filters: null,
        callbackBefore: null,
        callbackAfter: null
    };
    if (params == null) {
        return null;
    }
    if (typeof params !== 'object') {
        return null;
    }

    parameters = params;

    parameters.filter = params.filter || '';
    parameters.additional_filters = params.additional_filters || '';

    if (typeof parameters.$paginationView == null) {
        console.error('Empty pagination view');
        return null;
    }

    if (parameters.url == null) {
        console.error('Empty url');
        return null;
    }

    if (parameters.$dataContainers == null || (typeof parameters.$dataContainers !== 'object')) {
        console.error('Empty data containers');
        return null;
    }

    if (parameters.pageSize == null) {
        parameters.pageSize = 5;
    }

    return parameters.$paginationView.pagination({
        dataSource: parameters.url,
        locator: 'items',
        showNavigator: true,
        showPageNumbers: true,
        showPrevious: true,
        showNext: true,
        totalNumberLocator: function (response) {
            return response['totalCount'];
        },
        pageSize: parameters.pageSize,
        ajax: {
            beforeSend: function () {
                if (Object.prototype.toString.call(parameters.$dataContainers) !== '[object Array]') {
                    parameters.$dataContainers = [parameters.$dataContainers];
                }
                parameters.$dataContainers.forEach($container => $container.html(''));
            },
            data: {
                additional_filters: Base64.encode(parameters.additional_filters),
                filter: Base64.encode(parameters.filter)
            }
        },
        callback: function (data, pagination) {
            if (parameters.callbackBefore != null) {
                parameters.callbackBefore();
            }
            parameters.$dataContainers.forEach(($container, containerIndex) => {
                var dataHtml = '';
                $.each(data, function (index, item) {
                    if (Object.prototype.toString.call(item) === '[object Array]') {
                        dataHtml += item[containerIndex];
                    } else {
                        dataHtml += item;
                    }
                });
                $container.html(dataHtml)
            });
            if (parameters.callbackAfter != null) {
                parameters.callbackAfter();
            }
        }
    });
}