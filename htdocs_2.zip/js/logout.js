var sendLogOut = null;

$(document).ready(function() {
    sendLogOut = function() {
        $.ajax({
            type: "POST",
            url: "/login/logout",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            success: function(res) {
                window.location.href = "../404";
            }
        });
    };
});