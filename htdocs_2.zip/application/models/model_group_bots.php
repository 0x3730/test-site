<?php

class Model_Group_Bots extends Model
{
    public function getGroups()
    {
        $groups_info = $this->getDB()->queryRows('SELECT * FROM `group_bots`');
        if (!empty($groups_info)) {
            foreach ($groups_info as $groups_list => $value) {
                echo '<tr>';
                echo '<td><a href="/edit_group?group_id=' . $value['id'] . '">'.$value['name_group'].'</a></td>';
                echo '<td><i style="cursor: pointer;" class="fa fa-trash-o fa-lg text-danger" onclick="deleteGroup(' . $value['id'] . ')"></i></td>';
                echo '</tr>';
            }
        }
    }

    public function deleteGroup()
    {
        if (!empty($this->request_data['group_id'])) {
            $id = $this->request_data['group_id'];

            $this->getDB()->sql("DELETE FROM `group_bots` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }
    }
}

?>