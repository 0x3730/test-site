<?php

class Model_Installed_Software extends Model
{

    public function get_data()
    {

    }

    public function getInstalledSoftware()
    {
        $software = $this->getDB()->queryRows('SELECT name, vendor, count(*) as count FROM reports_software GROUP BY name, vendor ORDER BY count DESC');
        return $software;
    }

    public function getInstalledAntiviruses()
    {
        $antiViruses = $this->getDB()->queryRows('SELECT name, count(*) as count FROM reports_antivirus GROUP BY name ORDER BY count DESC');
        return $antiViruses;
    }

    public function getInstalledFirewalls()
    {
        $firewalls = $this->getDB()->queryRows('SELECT name, count(*) as count FROM reports_firewall GROUP BY name ORDER BY count DESC');
        return $firewalls;
    }

}