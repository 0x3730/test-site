<?php

class PaginationWorker
{
    /**
     * @var PaginationResponseData Response data
     */
    private $responseData;

    /**
     * @var int Number of items on the page
     */
    private $pageSize;

    /**
     * @var int Number of the row which is a first row for taking the data
     */
    private $startLimit;

    /**
     * @var PaginationFilter Filter
     */
    private $filter;

    public function __construct($pageSize, $pageNumber)
    {
        $this->pageSize = (int)$pageSize;
        $this->startLimit = ((int)$pageNumber === 1) ? 0 : ((int)$pageNumber - 1) * $this->pageSize;
        $this->responseData = new PaginationResponseData();
        $this->filter = new PaginationFilter();
    }

    /**
     * Get converted data (in pagination format)
     * @param int $dataCount
     * @param array $dataArray
     * @param $callback
     * @param null $data
     * @return string
     */
    public function getJsonEncodedData($dataCount, $dataArray, $callback, $data = null)
    {
        $this->responseData->totalCount = $dataCount;
        foreach ($dataArray as $dataItem)
        {
            if ($data == null)
            {
                $this->responseData->items[] = $callback($dataItem);
            }
            else
            {
                $this->responseData->items[] = $callback($dataItem, $data);
            }
        }
        return json_encode($this->responseData);
    }

    /**
     * Get generated automatically limit
     * @return string
     */
    public function getLimit()
    {
        return ' LIMIT '.$this->startLimit.', '.$this->pageSize;
    }

    public function getOrderBy($field, $desc = false)
    {
        $retVal = ' ORDER BY ' . $field;
        if ($desc)
        {
            $retVal .= ' DESC';
        }
        else
        {
            $retVal .= ' ASC';
        }
        return $retVal;
    }

    /**
     * Input filters with object format: { name: '', value: '' }
     * @param array $filtersList
     * @param bool $firstEnter
     * @return $this
     */
    public function setAdditionalFilter($filtersList, $firstEnter = false)
    {
        $this->filter->setAdditionalFilter($filtersList, $firstEnter);
        return $this;
    }

    /**
     * Input common filter, created by user
     * @param string $filterText
     * @param array $filterValues
     * @return $this
     */
    public function setFilter($filterText, $filterValues)
    {
        $this->filter->setCustomFilter($filterText, $filterValues);
        return $this;
    }

    public function addCustomFilter($filterText, $filterValues = null)
    {
        $this->filter->addCustomFilter($filterText, $filterValues);
        return $this;
    }

    /**
     * Get filter user-defined or generated automatically
     * @return String
     */
    public function getFilterText()
    {
        return $this->filter->getFilter();
    }

    /**
     * Get filter's values
     * @return array|ArrayObject
     */
    public function getFilterValues()
    {
        return $this->filter->getValues();
    }
}

class PaginationResponseData
{
    public $items;
    public $totalCount;

    public function __construct()
    {
        $this->items = array();
    }
}

class PaginationFilter
{
    /**
     * @var String
     */
    private $filterText;

    /**
     * @var ArrayObject
     */
    private $filterValues;

    public function __construct()
    {
        $this->filterValues = array();
    }

    public function setAdditionalFilter($filtersList, $firstEnter)
    {
        foreach ($filtersList as $filterIndex => $filter)
        {
            if (!empty($filter['value']))
            {
                if (!empty($this->filterText) && $filterIndex < count($filtersList))
                {
                    $this->filterText .= ' AND ';
                } else {
                    if ($firstEnter)
                    {
                        $this->filterText .= ' WHERE (';
                    } else
                    {
                        $this->filterText .= ' AND (';
                    }
                }
                $this->filterText .= $filter['name'] . ' LIKE ' . ':' . $filter['name'];
                $this->filterValues[':'.$filter['name']] = $this->getPatternConvertedToSqlView($filter['value']);
            }
        }
        if (!empty($this->filterText))
        {
            $this->filterText .= ')';
        }
    }

    public function setCustomFilter($filterText, $filterValues)
    {
        $this->filterText = $filterText;
        $convertedValues = array();

        foreach ($filterValues as $index => $filterValue)
        {
            $convertedValues[$index] = $this->getPatternConvertedToSqlView($filterValue);
        }

        $this->filterValues = $convertedValues;
    }

    public function addCustomFilter($filterText, $filterValues)
    {
        if ($this->filterText == NULL)
        {
            $this->filterText .= ' WHERE ';
        } else {
            $this->filterText .= ' AND ';
        }
        $this->filterText .= $filterText;

        if ($filterValues == null)
        {
            return;
        }

        foreach ($filterValues as $index => $filterValue)
        {
            $this->filterValues[$index] = $filterValue;
        }
    }

    public function getFilter()
    {
        return $this->filterText;
    }

    public function getValues()
    {
        return $this->filterValues;
    }

    /**
     * Get pattern converted to sql format
     * @param String $pattern
     * @return String
     */
    private function getPatternConvertedToSqlView($pattern)
    {
        return str_replace(array('*', '?'), array('%', '_'), $pattern);
    }

}