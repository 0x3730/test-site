<?php

class Model_Updater_Groups extends Model
{

}

?>