<?php

class Model_Http_Grabber_Settings extends Model
{

    public function get_data()
    {

    }

    public function saveConfiguration()
    {
        $this->getDB()->update('http_grabber_settings', array('config' => $this->request_data['config']), '1');
        return true;
    }

    public function loadConfiguration()
    {
        return $this->getDB()->queryValue('SELECT config FROM http_grabber_settings');
    }

    public function saveSettings()
    {
        require_once 'application/modules/protobuf/pb_proto_http_grabber.php';
        $httpGb = new http_grabber_message();
        $httpGb->set_request_type($this->request_data['request_type']);
        $httpGb->set_content_type($this->request_data['content_type']);
        $blacklistArr = json_decode($this->request_data['blacklist'], true);
        $keywordsArr = json_decode($this->request_data['keywords'], true);
        foreach ($blacklistArr as $record) {
            $httpGb->append_blacklist($record);
        }
        foreach ($keywordsArr as $keyword) {
            $httpGb->append_keywords($keyword);
        }
        $output = $httpGb->SerializeToString();
        $this->getDB()->update('components',
            array('config' => $output, 'active' => $this->request_data['status']),
            'name=:name',array(':name' => 'http_grabber'));
    }

    public function loadSettings()
    {
        require_once 'application/modules/protobuf/pb_proto_http_grabber.php';
        $httpGb = new http_grabber_message();
        $config = $this->getDB()->queryValue('SELECT config FROM components WHERE name = :name',
            array(':name' => 'http_grabber'));
        if (!empty($config) && $config != '') {
            $httpGb->ParseFromString($config);
            $assocConfig = array();
            $assocConfig['request_type'] = $httpGb->request_type();
            $assocConfig['content_type'] = $httpGb->content_type();
            $assocConfig['blacklist'] = array();
            $assocConfig['keywords'] = array();
            for ($blInd = 0; $blInd < $httpGb->blacklist_size(); $blInd++) {
                $assocConfig['blacklist'][$blInd] = $httpGb->blacklist($blInd);
            }
            for ($kwInd = 0; $kwInd < $httpGb->keywords_size(); $kwInd++) {
                $assocConfig['keywords'] = $httpGb->keywords($kwInd);
            }
            $assocConfig['status'] = $this->getDB()->queryValue('SELECT active FROM components WHERE name = :name',
                array(':name' => 'http_grabber'));
            return json_encode($assocConfig);
        }
        return null;
    }
}