<?php

class Model_Backcmd extends Model
{

    public function get_data()
    {

    }

    public function getBackcmd()
    {
        include 'application/models/accessory_models/BrowserDataWorker.php';
        $browserWorker = new BrowserDataWorker();
        return $browserWorker->sortBackCmd($this->request_data);
    }
}