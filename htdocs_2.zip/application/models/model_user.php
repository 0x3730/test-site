<?php

class Model_User extends Model
{
    public function getUserInfo()
    {
        $user_id = $this->request_data['user_id'];

        $user_info = $this->getDB()->queryRow('SELECT * FROM `users` WHERE id=:id', array(':id' => $user_id));
        $users_roles = $this->getDB()->queryRows('SELECT * FROM `roles_list`');

        if (!empty($user_info)) {
            echo 'ID: <span class="bot-info-value" data-botid="">' . $user_info['id'] . '</span><br><br>';
            echo '<input type="hidden" id="edit_user_id" value="' . $user_info['id'] . '">';
            echo 'Login: <span class="bot-info-value"><input type="text" id="edit_user_login" placeholder="Login" class="input-group form-control" value="' . $user_info['username'] . '"></span><br>';
            echo 'Password: <span class="bot-info-value"><input type="password" id="edit_user_password"  placeholder="Password" class="input-group form-control"></span><br>';
            echo 'Privilege this user: <span class="bot-info-value"><input type="text" disabled placeholder="Privilege" class="input-group form-control" value="' . $user_info['privileges'] . '"></span><br>';
            echo '<label for="user_privilege" style="width:100%;">Change Privilege:</label>';
            echo '<select name="user_privilege" class="form-control" id="edit_user_privilege">';
            foreach ($users_roles as $value_roles) {
                echo "<option value=" . $value_roles['id'] . ">" . $value_roles['name_role'] . "</option>";
            }
            echo '</select></br>';
            echo 'Last online: <span class="bot-info-value">' . $user_info['last_online'] . '</span>';
        } else {
            return NULL;
        }
    }

    public function editUser()
    {
        if ($this->checkInfoEditCorrect()) {
            $edit_user_id = $this->request_data['edit_user_id'];
            $edit_user_login = $this->request_data['edit_user_login'];
            $edit_user_privilege = $this->request_data['edit_user_privilege'];

            $privilege = $this->getDB()->queryRow('SELECT * FROM `roles_list` WHERE id=:id', array(':id' => $edit_user_privilege));
            if (!empty($this->request_data['edit_user_password'])) {
                $edit_user_password = $this->request_data['edit_user_password'];

                $edit_hash_new_password = hash('sha256', $edit_user_password);

                $this->getDB()->update('users', array('username' => $edit_user_login, 'password' => $edit_hash_new_password, 'privileges' => $edit_user_privilege, 'list_access' => $privilege['list_access']), 'id=:id', array(':id' => $edit_user_id));
                return true;
            } elseif (empty($this->request_data['edit_user_password'])) {
                $edit_user_password = '';
                $this->getDB()->update('users', array('username' => $edit_user_login, 'privileges' => $edit_user_privilege, 'list_access' => $privilege['list_access']), 'id=:id', array(':id' => $edit_user_id));
                return true;
            } else {
                return false;
            }


        }
        return false;
    }

    public function deleteUser()
    {
        if (!empty($this->request_data['user_id'])) {
            $id = $this->request_data['user_id'];

            $this->getDB()->sql("DELETE FROM `users` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }
    }

    private function checkInfoEditCorrect()
    {
        if (!empty($this->request_data['edit_user_login']) &&
            (!empty($this->request_data['edit_user_privilege']))) {
            return true;
        } else {
            return false;
        }
    }

}

?>