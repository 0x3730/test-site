<?php

class Model_Operating_Systems extends Model
{

    public function get_data()
    {

    }

    public function getOsStats()
    {
        $outStats = array();
        $onlineAll = 0;
        $offlineAll = 0;
        $AllCount = 0;
        $knock = $this->getDB()->queryValue("SELECT setting_value FROM general_settings WHERE setting_name = 'knock_timeout'");
        $op_systems = $this->getDB()->queryValues('SELECT DISTINCT os FROM bots LIMIT 10');

        foreach ($op_systems as $index => $os)
        {
            $countOnline = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE os=:os AND last_login + :on > UNIX_TIMESTAMP()',
                array(':on' => $knock * 60, ':os' => $os));
            $countOffline = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE os=:os AND last_login + :on < UNIX_TIMESTAMP()',
                array(':on' => $knock * 60, ':os' => $os));
            $countAll = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE os=:os',
                array(':os' => $os));

            $onlineAll += $countOnline;
            $offlineAll += $countOffline;
            $AllCount += $countAll;

            $outStats[$index]['os'] = htmlspecialchars($os);
            $outStats[$index]['count_online'] = $countOnline;
            $outStats[$index]['count_offline'] = $countOffline;
            $outStats[$index]['count_all'] = $countAll;
        }

        uasort($outStats, array($this, 'cmp_bots_function_desc'));
        $outStats[] = array(
            'os' => '<b>All</b>',
            'count_online' => '<b>' . $onlineAll . '</b>',
            'count_offline' => '<b>' . $offlineAll . '</b>',
            'count_all' => '<b>' . $AllCount . '</b>');

        return $outStats;
    }

    private function cmp_bots_function_desc($a, $b)
    {
        return ($a['count_all'] < $b['count_all']);
    }

}