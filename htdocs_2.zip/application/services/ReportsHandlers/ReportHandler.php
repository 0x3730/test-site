<?php

class ReportHandler {
    protected $data;
    private $pdo;
    private $dbh;

    protected function getDB() {
        return DBClient::DB();
    }

    public function grabDataFromProtobuf($input_data, $botId) { }

    public function storeDataToServer() { }

    public function setData($data) {
        $this->data = $data;
    }

    protected function dataIsEmpty() { }

    protected function getBotIdByRowId($botRowId = null)
    {
        $botid = $this->getDB()->getValue('bots', 'botid', 'id=:bot_id', array(':bot_id' => !empty($botRowId) ? $botRowId : $this->request_data['bot_id']));
        if (!empty($botid))
        {
            return $botid;
        }
        return null;
    }

    protected function getRowIdByBotId($botId = null)
    {
        $bot_id = $this->getDB()->getValue('bots', 'id', 'botid=:botid', array(':botid' => !empty($botId) ? $botId : $this->request_data['botid']));
        if (!empty($bot_id))
        {
            return $bot_id;
        }
        return null;
    }
}