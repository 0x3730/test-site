<?php

class ReportsErrors
{
    public static function ResultError()
    {
        die('0');
    }

    public static function ResultSuccess()
    {
        die('1');
    }
}