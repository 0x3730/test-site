<?php
session_start();

class Controller_Screenshots extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Screenshots();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array(
                'js/plugins/gridgallery/js/modernizr.custom.js',
                'js/plugins/gridgallery/js/imagesloaded.pkgd.min.js',
                'js/plugins/gridgallery/js/masonry.pkgd.min.js',
                'js/plugins/gridgallery/js/classie.js',
                'js/plugins/gridgallery/js/cbpgridgallery.js',
                'plugins/pagination/pagination.min.js',
                'js/custom/pagination.js',
                'js/pages/screenshots.js'
            ));
            $this->view->addCSS(array(
                'js/plugins/gridgallery/css/component.css',
                'plugins/pagination/pagination.css'
            ));
            $this->view->generate('screenshots_view.php', array(
                'settings' => $settings
            ));
        //}
    }

    public function action_get_screenshots_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Screenshots();
            $this->model->setRequestData($this->data);
            die($this->model->getScreenshotsData());
        //}
    }
}