<?php
session_start();

class Controller_Login extends Controller {
    public function action_index() {
        /*$this->model = new Model_Login();
        $this->model->setResponseData($this->data);*/
        $actualPageName = 'login_page_for_users_bitch';
        $this->view->onePageGenerate('login_view.php', array('actualPageName' => $actualPageName));
    }

    public function action_tryauth() {
        $this->model = new Model_Login();
        $this->model->setRequestData($this->data);
        if ($this->model->tryToAuth()) {
            die('true');
        }
        die('false');
    }

    public function action_logout() {
        Authorization::logOut();
    }
}