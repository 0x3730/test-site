<?php
session_start();

class Controller_Bots extends Controller {

    public function action_index() {
        //parent::action_index();
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bots();
            $bots_list = $this->model->getBots();
            $settings = $this->model->getSettings();
            $this->view->addCSS(array(
                'js/plugins/gridgallery/css/component.css',
                'plugins/pagination/pagination.css'
            ));
            $this->view->addJavaScripts(array(
                'plugins/pagination/pagination.min.js',
                'js/custom/pagination.js',
                'js/pages/bots.js'
            ));
            $this->view->generate('bots_view.php', array('bots_list' => $bots_list, 'settings' => $settings));
        //}
    }

    public function action_comment_update() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bots();
            $this->model->setRequestData($this->data);
            if ($this->model->updateComment())
                die('Updated!');
            else
                die('Not updated :c');
        //}
    }

    public function action_bot_delete() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bots();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteBot())
                die('1');
            else
                die('0');
        //}
    }

    public function action_get_bots_data()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bots();
            $this->model->setRequestData($this->data);
            die($this->model->getBotsData());
        //}
    }
}