<?php
session_start();

class Controller_Modules extends Controller {

    public function action_index() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $first_module_info = $this->model->getFirstModuleInfo();
            $configs = $this->model->getConfigsInformation($first_module_info['id']);
            $modules = $this->model->getModules();
            $this->view->addCSS(array('css/jquery.mCustomScrollbar.min.css', 'css/pages/module.css', 'css/jquery.spin.css'));
            $this->view->addJavaScripts(array('js/plugins/jquery.mCustomScrollbar.concat.min.js', 'js/plugins/scriptjava.js', 'js/plugins/jquery.spin.js', 'js/pages/modules.js'));
            $this->view->generate('modules_view.php', array('settings' => $settings, 'module_info' => $first_module_info, 'modules' => $modules, 'configs' => $configs));
        }
    }

    public function action_get_modules() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $resp = $this->model->getModules();
            if ($resp)
                die(json_encode($resp));
            else
                die("0");
        }
    }

    public function action_get_active_modules() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $resp = $this->model->getModules(true);
            if ($resp)
                die(json_encode($resp));
            else
                die("0");
        }
    }

    public function action_get_module() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            $resp = $this->model->getModuleInfo();
            if ($resp)
                die(json_encode($resp));
            else
                die("0");
        }
    }

    public function action_save_module_info() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            $resp = $this->model->saveModuleInfo();
            if ($resp)
                die("1");
            else
                die("0");
        }
    }

    public function action_get_configs_for_module() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            $configs = $this->model->getConfigsInformation();
            die(json_encode($configs));
        }
    }

    public function action_get_config_info() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            $res = $this->model->getConfigData();
            die($res);
        }
    }

    // decrypt from base64
    public function action_save_new_config() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            if ($this->model->addConfig())
                die("1");
            else
                die("0");
        }
    }

    // decrypt from base64
    public function action_save_config() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            if ($this->model->updateConfig())
                die("1");
            else
                die("0");
        }
    }

    public function action_delete_config() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteConfig())
                die("1");
            else
                die("0");
        }
    }
}