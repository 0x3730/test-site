<?php
session_start();

class Controller_Http_Grabber_Settings extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber_Settings();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/http_grabber_settings.js'));
            $grabberConfiguration = $this->model->loadConfiguration();
            $this->view->generate('http_grabber_settings_view.php', array(
                'settings' => $settings, 'grabberConfiguration' => $grabberConfiguration
            ));
        //}
    }

    public function action_save_config() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber_Settings();
            $this->model->setRequestData($this->data);
            if ($this->model->saveConfiguration())
                die('1');
            die('0');
        //}
    }

    /*function action_save_settings() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber_Settings();
            $this->model->setRequestData($this->data);
            $this->model->saveSettings();
        }
    }

    function action_load_settings() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber_Settings();
            $this->model->setRequestData($this->data);
            die($this->model->loadSettings());
        }
    }*/
}