<?php
session_start();

class Controller_Modules_Tasks extends Controller {

    public function action_index() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules_Tasks();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $tasks = $this->model->getTasks();
            $tasks_settings = $this->model->getTasksOptions();
            $this->view->addJavaScripts(array('js/pages/modules_tasks.js'));
            $this->view->generate('modules_tasks_view.php', array('settings' => $settings, 'tasks_arr' => $tasks, 'tasks_settings' => $tasks_settings));
        }
    }

    public function action_newtask() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules_Tasks();
            $this->model->setRequestData($this->data);
            if ($this->model->createTask())
                die('1');
            else
                die('0');
        }
    }

    public function action_updtask() {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Modules_Tasks();
            $this->model->setRequestData($this->data);
            if ($this->model->updateTask()) {
                die('1');
            } else {
                die('0');
            }
        }
    }
}