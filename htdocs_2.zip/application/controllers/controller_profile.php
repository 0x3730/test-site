<?php
session_start();

class Controller_Profile extends Controller
{
    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Profile();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/profile.js'));
            $this->view->generate('profile_view.php', array('settings' => $settings));
        //}
    }

    public function action_get_profile_user()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Profile();
            $this->model->setRequestData($this->data);
            die($this->model->getProfile());
        //}
    }

    public function action_edit_profile()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Profile();
            $this->model->setRequestData($this->data);
            if ($this->model->editProfile()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }
}

?>