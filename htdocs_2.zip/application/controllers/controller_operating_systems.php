<?php
session_start();

class Controller_Operating_Systems extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Operating_Systems();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $osStats = $this->model->getOsStats();
            $this->view->generate('operating_systems_view.php', array(
                'settings' => $settings,
                'os_stats' => $osStats
            ));
        //}
    }
}