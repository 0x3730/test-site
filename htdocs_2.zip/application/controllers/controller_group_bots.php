<?php
session_start();

class Controller_Group_Bots extends Controller
{
    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Group_Bots();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/groups_bots.js'));
            $this->view->generate('group_bots_view.php', array('settings' => $settings));
        //}
    }

    public function action_get_groups_list()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Group_Bots();
            $this->model->setRequestData($this->data);
            die($this->model->getGroups());
        //}
    }

    public function action_group_delete()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Group_Bots();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteGroup()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }
}

?>