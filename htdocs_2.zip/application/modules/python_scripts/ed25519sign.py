import sys
import json
from base64 import b64encode, b64decode
import nacl.signing

# NOTE need 32-byte string for seed
# TODO realize script for generate new public key

try:
    paramsJson = sys.stdin.read()
    params = json.loads(paramsJson)
    signingKey = nacl.signing.SigningKey(b64decode(params['seed']))
    #publicKey = signingKey.verify_key.encode(encoder=nacl.encoding.RawEncoder)
    signature = signingKey.sign(b64decode(params['data']), encoder=nacl.encoding.RawEncoder)
    print(b64encode(signature[0:64]))
except Exception:
    print(0)