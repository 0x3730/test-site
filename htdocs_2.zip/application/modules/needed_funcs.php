<?php

function saveToFile($path, $data)
{
    if (file_exists($path))
        unlink($path);
    if (!file_exists(dirname($path)))
        if (!mkdir($concurrentDirectory = dirname($path), 0777, true) && !is_dir($concurrentDirectory)) {
            throw new \RuntimeException(sprintf('Directory "%s" was not created', $concurrentDirectory));
        }
    file_put_contents($path, $data);
    /*$file = fopen($path, "w");
    fwrite($file, $data);
    fclose($file);*/
}

function readFromFile($path)
{
    $file_data = '';
    if (file_exists($path)) {
        $file_data = file_get_contents($path);
    }
    if ($file_data)
        return $file_data;
    else
        return false;
}

function millitime()
{
    $microtime = microtime();
    $comps = explode(' ', $microtime);

    return sprintf('%d%03d', $comps[1], $comps[0] * 1000);
}

/**
 * Delete a file or recursively delete a directory
 *
 * @param string $str Path to file or directory
 * @return bool
 */
function recursiveDelete($str)
{
    if (is_file($str))
    {
        return @unlink($str);
    }
    else if (is_dir($str))
    {
        $scan = glob(rtrim($str,'/').'/*');
        foreach($scan as $index=>$path)
        {
            recursiveDelete($path);
        }
        return @rmdir($str);
    }
}

/**
 * Checks if a folder exist and return canonicalized absolute pathname (sort version)
 * @param string $folder the path being checked.
 * @return mixed returns the canonicalized absolute pathname on success otherwise FALSE is returned
 */
function folder_exist($folder)
{
    // Get canonicalized absolute pathname
    $path = realpath($folder);

    // If it exist, check if it's a directory
    return ($path !== false AND is_dir($path)) ? $path : false;
}