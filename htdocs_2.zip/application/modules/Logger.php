<?php

class Logger
{
    /**
     * @param string $controller Name of controller
     * @param string $function Name of function
     * @param string $log Json encoded log
     * @param null|string $botid
     * @param null|string $dump_data Any data
     */
    public static function Error($controller, $function, $log, $botid = null, $dump_data = null)
    {
        self::Log($controller, $function, $log, LogLevel::Error, $botid, $dump_data);
    }

    public static function Trace($controller, $function, $log, $botid = null, $dump_data = null)
    {
        if (!TRACE_ENABLED)
        {
            return;
        }

        self::Log($controller, $function, $log, LogLevel::Trace, $botid, $dump_data);
    }

    public static function Warning($controller, $function, $log, $botid = null, $dump_data = null)
    {
        self::Log($controller, $function, $log, LogLevel::Warning, $botid, $dump_data);
    }

    /**
     * @param string $dump_data
     * @param int $log_id
     */
    public static function SaveDump($dump_data, $log_id)
    {
        $filename = LOG_DUMP_PATH . 'dump_' . $log_id . '.txt';
        if (!file_exists(dirname($filename)) && !mkdir($concurrentDirectory = dirname($filename), 0777, true) && !is_dir($concurrentDirectory)) {
            throw new \RuntimeException(sprintf('Directory "%s" was not created', $concurrentDirectory));
        }
        file_put_contents($filename, $dump_data);
    }

    /**
     * @param string $controller
     * @param string $function
     * @param string $log
     * @param int $level
     * @param null|string $botid
     * @param null|string $dump_data
     */
    private static function Log($controller, $function, $log, $level = LogLevel::Trace, $botid = null, $dump_data = null)
    {
        $hLog = new Log($controller, $function, $log, $botid, $level);
        $log_id = DBClient::DB()->insert('logs', $hLog->getDataForInsert());

        if ($log_id > 0 && !empty($dump_data))
        {
            self::SaveDump($dump_data, $log_id);
        }
    }
}

class Log
{
    private $controller;
    private $function;
    private $log;
    private $botid;
    private $level;
    private $request_id;

    /**
     * Log constructor.
     * @param string $controller
     * @param string $function
     * @param string $log
     * @param null $botid
     * @param int $level
     */
    public function __construct($controller, $function, $log, $botid = null, $level = LogLevel::Trace)
    {
        if (!empty($botid)) {
            $this->botid = $botid;
        }
        $this->controller = $controller;
        $this->function = $function;
        $this->log = $log;
        $this->level = $level;
        $this->request_id = $_SERVER['UNIQUE_REQUEST_ID'];
    }

    /**
     * @return array Data for inserting into DB
     */
    public function getDataForInsert()
    {
        $data = array();
        $data['controller'] = $this->controller;
        $data['function'] = $this->function;
        $data['log'] = (!empty($this->botid) ? ('<BOTID>' . $this->botid . '</BOTID>>') : '') . $this->log;
        $data['level'] = $this->level;
        $data['request_id'] = $this->request_id;
        return $data;
    }
}