<?php

class DBClient {

    private static $pdo;
    private static $dbh;

    static function DB() {
        if (!isset(self::$dbh) && empty(self::$dbh)) {
            self::$pdo = new PDO(DATABASE_SOURCE_NAME, DATABASE_USER_NAME, DATABASE_USER_PASSWORD);
            self::$dbh = new Db(self::$pdo);
        }
        return self::$dbh;
    }
}