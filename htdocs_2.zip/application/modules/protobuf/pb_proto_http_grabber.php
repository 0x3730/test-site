<?php
class http_grabber_message extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = array();
    $this->fields["4"] = "PBString";
    $this->values["4"] = array();
  }
  function request_type()
  {
    return $this->_get_value("1");
  }
  function set_request_type($value)
  {
    return $this->_set_value("1", $value);
  }
  function content_type()
  {
    return $this->_get_value("2");
  }
  function set_content_type($value)
  {
    return $this->_set_value("2", $value);
  }
  function keywords($offset)
  {
    $v = $this->_get_arr_value("3", $offset);
    return $v->get_value();
  }
  function append_keywords($value)
  {
    $v = $this->_add_arr_value("3");
    $v->set_value($value);
  }
  function set_keywords($index, $value)
  {
    $v = new $this->fields["3"]();
    $v->set_value($value);
    $this->_set_arr_value("3", $index, $v);
  }
  function remove_last_keywords()
  {
    $this->_remove_last_arr_value("3");
  }
  function keywords_size()
  {
    return $this->_get_arr_size("3");
  }
  function blacklist($offset)
  {
    $v = $this->_get_arr_value("4", $offset);
    return $v->get_value();
  }
  function append_blacklist($value)
  {
    $v = $this->_add_arr_value("4");
    $v->set_value($value);
  }
  function set_blacklist($index, $value)
  {
    $v = new $this->fields["4"]();
    $v->set_value($value);
    $this->_set_arr_value("4", $index, $v);
  }
  function remove_last_blacklist()
  {
    $this->_remove_last_arr_value("4");
  }
  function blacklist_size()
  {
    return $this->_get_arr_size("4");
  }
}
?>