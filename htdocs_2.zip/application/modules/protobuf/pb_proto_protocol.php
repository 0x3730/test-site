<?php
class system_data extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBInt";
    $this->values["2"] = "";
    $this->fields["3"] = "PBInt";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
    $this->fields["5"] = "PBString";
    $this->values["5"] = "";
    $this->fields["6"] = "PBString";
    $this->values["6"] = "";
    $this->fields["7"] = "PBInt";
    $this->values["7"] = "";
  }
  function uid()
  {
    return $this->_get_value("1");
  }
  function set_uid($value)
  {
    return $this->_set_value("1", $value);
  }
  function version()
  {
    return $this->_get_value("2");
  }
  function set_version($value)
  {
    return $this->_set_value("2", $value);
  }
  function cores()
  {
    return $this->_get_value("3");
  }
  function set_cores($value)
  {
    return $this->_set_value("3", $value);
  }
  function display_resolution()
  {
    return $this->_get_value("4");
  }
  function set_display_resolution($value)
  {
    return $this->_set_value("4", $value);
  }
  function osVersion()
  {
    return $this->_get_value("5");
  }
  function set_osVersion($value)
  {
    return $this->_set_value("5", $value);
  }
  function computerName()
  {
    return $this->_get_value("6");
  }
  function set_computerName($value)
  {
    return $this->_set_value("6", $value);
  }
  function architecture()
  {
    return $this->_get_value("7");
  }
  function set_architecture($value)
  {
    return $this->_set_value("7", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["uid"] = $this->uid();
    $returnArray["version"] = $this->version();
    $returnArray["cores"] = $this->cores();
    $returnArray["display_resolution"] = $this->display_resolution();
    $returnArray["osVersion"] = $this->osVersion();
    $returnArray["computerName"] = $this->computerName();
    $returnArray["architecture"] = $this->architecture();
    return $returnArray;
  }
}
class moduleContext extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBInt";
    $this->values["3"] = "";
    $this->fields["4"] = "PBInt";
    $this->values["4"] = "";
  }
  function ImageX64()
  {
    return $this->_get_value("1");
  }
  function set_ImageX64($value)
  {
    return $this->_set_value("1", $value);
  }
  function ImageX32()
  {
    return $this->_get_value("2");
  }
  function set_ImageX32($value)
  {
    return $this->_set_value("2", $value);
  }
  function ImageX64Size()
  {
    return $this->_get_value("3");
  }
  function set_ImageX64Size($value)
  {
    return $this->_set_value("3", $value);
  }
  function ImageX32size()
  {
    return $this->_get_value("4");
  }
  function set_ImageX32size($value)
  {
    return $this->_set_value("4", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["ImageX64"] = $this->ImageX64();
    $returnArray["ImageX32"] = $this->ImageX32();
    $returnArray["ImageX64Size"] = $this->ImageX64Size();
    $returnArray["ImageX32size"] = $this->ImageX32size();
    return $returnArray;
  }
}
class moduleInfo extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBInt";
    $this->values["1"] = "";
  }
  function id()
  {
    return $this->_get_value("1");
  }
  function set_id($value)
  {
    return $this->_set_value("1", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["id"] = $this->id();
    return $returnArray;
  }
}
class settings extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBInt";
    $this->values["1"] = "";
    $this->fields["2"] = "PBBool";
    $this->values["2"] = "";
    $this->fields["3"] = "PBInt";
    $this->values["3"] = "";
  }
  function reportPolicy()
  {
    return $this->_get_value("1");
  }
  function set_reportPolicy($value)
  {
    return $this->_set_value("1", $value);
  }
  function coreProtection()
  {
    return $this->_get_value("2");
  }
  function set_coreProtection($value)
  {
    return $this->_set_value("2", $value);
  }
  function knockTimeout()
  {
    return $this->_get_value("3");
  }
  function set_knockTimeout($value)
  {
    return $this->_set_value("3", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["reportPolicy"] = $this->reportPolicy();
    $returnArray["coreProtection"] = $this->coreProtection();
    $returnArray["knockTimeout"] = $this->knockTimeout();
    return $returnArray;
  }
}
class module extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBInt";
    $this->values["1"] = "";
    $this->fields["2"] = "PBBool";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
  }
  function id()
  {
    return $this->_get_value("1");
  }
  function set_id($value)
  {
    return $this->_set_value("1", $value);
  }
  function constantlyActive()
  {
    return $this->_get_value("2");
  }
  function set_constantlyActive($value)
  {
    return $this->_set_value("2", $value);
  }
  function hash_x32()
  {
    return $this->_get_value("3");
  }
  function set_hash_x32($value)
  {
    return $this->_set_value("3", $value);
  }
  function hash_x64()
  {
    return $this->_get_value("4");
  }
  function set_hash_x64($value)
  {
    return $this->_set_value("4", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["id"] = $this->id();
    $returnArray["constantlyActive"] = $this->constantlyActive();
    $returnArray["hash_x32"] = $this->hash_x32();
    $returnArray["hash_x64"] = $this->hash_x64();
    return $returnArray;
  }
}
class task extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBInt";
    $this->values["1"] = "";
    $this->fields["2"] = "PBInt";
    $this->values["2"] = "";
    $this->fields["3"] = "PBInt";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
  }
  function id()
  {
    return $this->_get_value("1");
  }
  function set_id($value)
  {
    return $this->_set_value("1", $value);
  }
  function sid()
  {
    return $this->_get_value("2");
  }
  function set_sid($value)
  {
    return $this->_set_value("2", $value);
  }
  function command()
  {
    return $this->_get_value("3");
  }
  function set_command($value)
  {
    return $this->_set_value("3", $value);
  }
  function context()
  {
    return $this->_get_value("4");
  }
  function set_context($value)
  {
    return $this->_set_value("4", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["id"] = $this->id();
    $returnArray["sid"] = $this->sid();
    $returnArray["command"] = $this->command();
    $returnArray["context"] = $this->context();
    return $returnArray;
  }
}
class data extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "settings";
    $this->values["1"] = "";
    $this->fields["2"] = "task";
    $this->values["2"] = array();
    $this->fields["3"] = "module";
    $this->values["3"] = array();
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
    $this->fields["5"] = "PBString";
    $this->values["5"] = "";
  }
  function settings()
  {
    return $this->_get_value("1");
  }
  function set_settings($value)
  {
    return $this->_set_value("1", $value);
  }
  function tasks($offset)
  {
    return $this->_get_arr_value("2", $offset);
  }
  function add_tasks()
  {
    return $this->_add_arr_value("2");
  }
  function set_tasks($index, $value)
  {
    $this->_set_arr_value("2", $index, $value);
  }
  function remove_last_tasks()
  {
    $this->_remove_last_arr_value("2");
  }
  function tasks_size()
  {
    return $this->_get_arr_size("2");
  }
  function modules($offset)
  {
    return $this->_get_arr_value("3", $offset);
  }
  function add_modules()
  {
    return $this->_add_arr_value("3");
  }
  function set_modules($index, $value)
  {
    $this->_set_arr_value("3", $index, $value);
  }
  function remove_last_modules()
  {
    $this->_remove_last_arr_value("3");
  }
  function modules_size()
  {
    return $this->_get_arr_size("3");
  }
  function injects()
  {
    return $this->_get_value("4");
  }
  function set_injects($value)
  {
    return $this->_set_value("4", $value);
  }
  function grabber_settings()
  {
    return $this->_get_value("5");
  }
  function set_grabber_settings($value)
  {
    return $this->_set_value("5", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
$returnArray["settings"] = $this->settings()->getAssocArray();
    $arr_size = $this->tasks_size();
    $returnArray["tasks"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["tasks"][$ind] = $this->tasks($ind)->getAssocArray();
    }
    $arr_size = $this->modules_size();
    $returnArray["modules"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["modules"][$ind] = $this->modules($ind)->getAssocArray();
    }
    $returnArray["injects"] = $this->injects();
    $returnArray["grabber_settings"] = $this->grabber_settings();
    return $returnArray;
  }
}
class report extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBInt";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
  }
  function reportType()
  {
    return $this->_get_value("1");
  }
  function set_reportType($value)
  {
    return $this->_set_value("1", $value);
  }
  function report()
  {
    return $this->_get_value("2");
  }
  function set_report($value)
  {
    return $this->_set_value("2", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["reportType"] = $this->reportType();
    $returnArray["report"] = $this->report();
    return $returnArray;
  }
}
class taskExecInfo extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBInt";
    $this->values["1"] = "";
    $this->fields["2"] = "PBInt";
    $this->values["2"] = "";
    $this->fields["3"] = "PBInt";
    $this->values["3"] = "";
    $this->fields["4"] = "PBBool";
    $this->values["4"] = "";
  }
  function task_id()
  {
    return $this->_get_value("1");
  }
  function set_task_id($value)
  {
    return $this->_set_value("1", $value);
  }
  function sid()
  {
    return $this->_get_value("2");
  }
  function set_sid($value)
  {
    return $this->_set_value("2", $value);
  }
  function status()
  {
    return $this->_get_value("3");
  }
  function set_status($value)
  {
    return $this->_set_value("3", $value);
  }
  function is_completed()
  {
    return $this->_get_value("4");
  }
  function set_is_completed($value)
  {
    return $this->_set_value("4", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["task_id"] = $this->task_id();
    $returnArray["sid"] = $this->sid();
    $returnArray["status"] = $this->status();
    $returnArray["is_completed"] = $this->is_completed();
    return $returnArray;
  }
}
class generalPacket extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBInt";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = array();
    $this->fields["4"] = "PBString";
    $this->values["4"] = array();
  }
  function uid()
  {
    return $this->_get_value("1");
  }
  function set_uid($value)
  {
    return $this->_set_value("1", $value);
  }
  function messageType()
  {
    return $this->_get_value("2");
  }
  function set_messageType($value)
  {
    return $this->_set_value("2", $value);
  }
  function payload($offset)
  {
    $v = $this->_get_arr_value("3", $offset);
    return $v->get_value();
  }
  function append_payload($value)
  {
    $v = $this->_add_arr_value("3");
    $v->set_value($value);
  }
  function set_payload($index, $value)
  {
    $v = new $this->fields["3"]();
    $v->set_value($value);
    $this->_set_arr_value("3", $index, $v);
  }
  function remove_last_payload()
  {
    $this->_remove_last_arr_value("3");
  }
  function payload_size()
  {
    return $this->_get_arr_size("3");
  }
  function signature($offset)
  {
    $v = $this->_get_arr_value("4", $offset);
    return $v->get_value();
  }
  function append_signature($value)
  {
    $v = $this->_add_arr_value("4");
    $v->set_value($value);
  }
  function set_signature($index, $value)
  {
    $v = new $this->fields["4"]();
    $v->set_value($value);
    $this->_set_arr_value("4", $index, $v);
  }
  function remove_last_signature()
  {
    $this->_remove_last_arr_value("4");
  }
  function signature_size()
  {
    return $this->_get_arr_size("4");
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["uid"] = $this->uid();
    $returnArray["messageType"] = $this->messageType();
    $arr_size = $this->payload_size();
    $returnArray["payload"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["payload"][$ind] = $this->payload($ind);
    }
    $arr_size = $this->signature_size();
    $returnArray["signature"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["signature"][$ind] = $this->signature($ind);
    }
    return $returnArray;
  }
}
class reportScreenshot extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
  }
  function mimeType()
  {
    return $this->_get_value("1");
  }
  function set_mimeType($value)
  {
    return $this->_set_value("1", $value);
  }
  function data()
  {
    return $this->_get_value("2");
  }
  function set_data($value)
  {
    return $this->_set_value("2", $value);
  }
  function description()
  {
    return $this->_get_value("3");
  }
  function set_description($value)
  {
    return $this->_set_value("3", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["mimeType"] = $this->mimeType();
    $returnArray["data"] = $this->data();
    $returnArray["description"] = $this->description();
    return $returnArray;
  }
}
class reportAntiviruses extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
  }
  function antiviruses_list()
  {
    return $this->_get_value("1");
  }
  function set_antiviruses_list($value)
  {
    return $this->_set_value("1", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["antiviruses_list"] = $this->antiviruses_list();
    return $returnArray;
  }
}
class reportFirewalls extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
  }
  function firewalls_list()
  {
    return $this->_get_value("1");
  }
  function set_firewalls_list($value)
  {
    return $this->_set_value("1", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["firewalls_list"] = $this->firewalls_list();
    return $returnArray;
  }
}
class reportSoftware_SoftwareInfo extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
  }
  function name()
  {
    return $this->_get_value("1");
  }
  function set_name($value)
  {
    return $this->_set_value("1", $value);
  }
  function vendor()
  {
    return $this->_get_value("2");
  }
  function set_vendor($value)
  {
    return $this->_set_value("2", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["name"] = $this->name();
    $returnArray["vendor"] = $this->vendor();
    return $returnArray;
  }
}
class reportSoftware extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "reportSoftware_SoftwareInfo";
    $this->values["1"] = array();
  }
  function software($offset)
  {
    return $this->_get_arr_value("1", $offset);
  }
  function add_software()
  {
    return $this->_add_arr_value("1");
  }
  function set_software($index, $value)
  {
    $this->_set_arr_value("1", $index, $value);
  }
  function remove_last_software()
  {
    $this->_remove_last_arr_value("1");
  }
  function software_size()
  {
    return $this->_get_arr_size("1");
  }
  function getAssocArray()
  {
    $returnArray = array();
    $arr_size = $this->software_size();
    $returnArray["software"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["software"][$ind] = $this->software($ind)->getAssocArray();
    }
    return $returnArray;
  }
}
class reportHttpGrabber extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
    $this->fields["5"] = "PBString";
    $this->values["5"] = "";
    $this->fields["6"] = "PBString";
    $this->values["6"] = "";
    $this->fields["7"] = "PBString";
    $this->values["7"] = "";
    $this->fields["8"] = "PBString";
    $this->values["8"] = "";
    $this->fields["9"] = "PBInt";
    $this->values["9"] = "";
  }
  function url()
  {
    return $this->_get_value("1");
  }
  function set_url($value)
  {
    return $this->_set_value("1", $value);
  }
  function useragent()
  {
    return $this->_get_value("2");
  }
  function set_useragent($value)
  {
    return $this->_set_value("2", $value);
  }
  function content_type()
  {
    return $this->_get_value("3");
  }
  function set_content_type($value)
  {
    return $this->_set_value("3", $value);
  }
  function accept_encoding()
  {
    return $this->_get_value("4");
  }
  function set_accept_encoding($value)
  {
    return $this->_set_value("4", $value);
  }
  function accept_language()
  {
    return $this->_get_value("5");
  }
  function set_accept_language($value)
  {
    return $this->_set_value("5", $value);
  }
  function referer()
  {
    return $this->_get_value("6");
  }
  function set_referer($value)
  {
    return $this->_set_value("6", $value);
  }
  function cookie()
  {
    return $this->_get_value("7");
  }
  function set_cookie($value)
  {
    return $this->_set_value("7", $value);
  }
  function post_data()
  {
    return $this->_get_value("8");
  }
  function set_post_data($value)
  {
    return $this->_set_value("8", $value);
  }
  function flags()
  {
    return $this->_get_value("9");
  }
  function set_flags($value)
  {
    return $this->_set_value("9", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["url"] = $this->url();
    $returnArray["useragent"] = $this->useragent();
    $returnArray["content_type"] = $this->content_type();
    $returnArray["accept_encoding"] = $this->accept_encoding();
    $returnArray["accept_language"] = $this->accept_language();
    $returnArray["referer"] = $this->referer();
    $returnArray["cookie"] = $this->cookie();
    $returnArray["post_data"] = $this->post_data();
    $returnArray["flags"] = $this->flags();
    return $returnArray;
  }
}
class ReportNetView_NetView extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
  }
  function name()
  {
    return $this->_get_value("1");
  }
  function set_name($value)
  {
    return $this->_set_value("1", $value);
  }
  function type()
  {
    return $this->_get_value("2");
  }
  function set_type($value)
  {
    return $this->_set_value("2", $value);
  }
  function platform()
  {
    return $this->_get_value("3");
  }
  function set_platform($value)
  {
    return $this->_set_value("3", $value);
  }
  function comment()
  {
    return $this->_get_value("4");
  }
  function set_comment($value)
  {
    return $this->_set_value("4", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["name"] = $this->name();
    $returnArray["type"] = $this->type();
    $returnArray["platform"] = $this->platform();
    $returnArray["comment"] = $this->comment();
    return $returnArray;
  }
}
class ReportNetView_Domain extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBInt";
    $this->values["2"] = "";
  }
  function name()
  {
    return $this->_get_value("1");
  }
  function set_name($value)
  {
    return $this->_set_value("1", $value);
  }
  function role()
  {
    return $this->_get_value("2");
  }
  function set_role($value)
  {
    return $this->_set_value("2", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["name"] = $this->name();
    $returnArray["role"] = $this->role();
    return $returnArray;
  }
}
class ReportNetView extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "ReportNetView_NetView";
    $this->values["1"] = array();
    $this->fields["2"] = "ReportNetView_Domain";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
  }
  function netViewInfo($offset)
  {
    return $this->_get_arr_value("1", $offset);
  }
  function add_netViewInfo()
  {
    return $this->_add_arr_value("1");
  }
  function set_netViewInfo($index, $value)
  {
    $this->_set_arr_value("1", $index, $value);
  }
  function remove_last_netViewInfo()
  {
    $this->_remove_last_arr_value("1");
  }
  function netViewInfo_size()
  {
    return $this->_get_arr_size("1");
  }
  function domainInfo()
  {
    return $this->_get_value("2");
  }
  function set_domainInfo($value)
  {
    return $this->_set_value("2", $value);
  }
  function extendedName()
  {
    return $this->_get_value("3");
  }
  function set_extendedName($value)
  {
    return $this->_set_value("3", $value);
  }
  function networkShares()
  {
    return $this->_get_value("4");
  }
  function set_networkShares($value)
  {
    return $this->_set_value("4", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $arr_size = $this->netViewInfo_size();
    $returnArray["netViewInfo"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["netViewInfo"][$ind] = $this->netViewInfo($ind)->getAssocArray();
    }
$returnArray["domainInfo"] = $this->domainInfo()->getAssocArray();
    $returnArray["extendedName"] = $this->extendedName();
    $returnArray["networkShares"] = $this->networkShares();
    return $returnArray;
  }
}
?>