<?php

require_once('parser/pb_parser_v2.php');
$test = new PBParser();
$test->parse('./protocol.proto');