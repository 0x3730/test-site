<?php

class PacketDataModules extends PacketData {

    private $id;
    private $hash;

    protected function parsePacket()
    {

    }

    protected function generatePacket()
    {

    }
}