<?php
require_once 'application/modules/protobuf/protocol/Packet.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
class PacketReport extends Packet {
    public function __construct($data)
    {
        $this->protoPacket = new report();
        if (!empty($data))
            $this->protoPacket->ParseFromString($data);
    }
}