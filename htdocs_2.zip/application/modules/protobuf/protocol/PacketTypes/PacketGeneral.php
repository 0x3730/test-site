<?php
require_once 'application/modules/protobuf/protocol/Packet.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
class PacketGeneral extends Packet {

    public function __construct($data = null)
    {
        $this->protoPacket = new generalPacket();
        if ($data != null) {
            $this->protoPacket->ParseFromString($data);
        }
    }

    public function setUid($uid)
    {
        $this->protoPacket->set_uid($uid);
    }

    // string
    public function addPayload($payload)
    {
        $this->protoPacket->append_payload($payload);
    }

    public function addSignature($signature)
    {
        $this->protoPacket->append_signature($signature);
    }

    public function setMessageType($messageType)
    {
        $this->protoPacket->set_messageType($messageType);
    }
}