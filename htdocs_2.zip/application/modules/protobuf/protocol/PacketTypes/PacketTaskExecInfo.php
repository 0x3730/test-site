<?php
require_once 'application/modules/protobuf/protocol/Packet.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
class PacketTaskExecInfo extends Packet {
    public function __construct($data)
    {
        $this->protoPacket = new taskExecInfo();
        if (!empty($data))
            $this->protoPacket->ParseFromString($data);
    }
}