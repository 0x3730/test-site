<?php
class serviceAccount extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
  }
  function service()
  {
    return $this->_get_value("1");
  }
  function set_service($value)
  {
    return $this->_set_value("1", $value);
  }
  function login()
  {
    return $this->_get_value("2");
  }
  function set_login($value)
  {
    return $this->_set_value("2", $value);
  }
  function password()
  {
    return $this->_get_value("3");
  }
  function set_password($value)
  {
    return $this->_set_value("3", $value);
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["service"] = $this->service();
    $returnArray["login"] = $this->login();
    $returnArray["password"] = $this->password();
    return $returnArray;
  }
}
class browser extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = array();
    $this->fields["3"] = "serviceAccount";
    $this->values["3"] = array();
  }
  function browser()
  {
    return $this->_get_value("1");
  }
  function set_browser($value)
  {
    return $this->_set_value("1", $value);
  }
  function cookies($offset)
  {
    $v = $this->_get_arr_value("2", $offset);
    return $v->get_value();
  }
  function append_cookies($value)
  {
    $v = $this->_add_arr_value("2");
    $v->set_value($value);
  }
  function set_cookies($index, $value)
  {
    $v = new $this->fields["2"]();
    $v->set_value($value);
    $this->_set_arr_value("2", $index, $v);
  }
  function remove_last_cookies()
  {
    $this->_remove_last_arr_value("2");
  }
  function cookies_size()
  {
    return $this->_get_arr_size("2");
  }
  function accounts($offset)
  {
    return $this->_get_arr_value("3", $offset);
  }
  function add_accounts()
  {
    return $this->_add_arr_value("3");
  }
  function set_accounts($index, $value)
  {
    $this->_set_arr_value("3", $index, $value);
  }
  function remove_last_accounts()
  {
    $this->_remove_last_arr_value("3");
  }
  function accounts_size()
  {
    return $this->_get_arr_size("3");
  }
  function getAssocArray()
  {
    $returnArray = array();
    $returnArray["browser"] = $this->browser();
    $arr_size = $this->cookies_size();
    $returnArray["cookies"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["cookies"][$ind] = $this->cookies($ind);
    }
    $arr_size = $this->accounts_size();
    $returnArray["accounts"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["accounts"][$ind] = $this->accounts($ind)->getAssocArray();
    }
    return $returnArray;
  }
}
class browsersData extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["2"] = "browser";
    $this->values["2"] = array();
  }
  function browsers($offset)
  {
    return $this->_get_arr_value("2", $offset);
  }
  function add_browsers()
  {
    return $this->_add_arr_value("2");
  }
  function set_browsers($index, $value)
  {
    $this->_set_arr_value("2", $index, $value);
  }
  function remove_last_browsers()
  {
    $this->_remove_last_arr_value("2");
  }
  function browsers_size()
  {
    return $this->_get_arr_size("2");
  }
  function getAssocArray()
  {
    $returnArray = array();
    $arr_size = $this->browsers_size();
    $returnArray["browsers"] = array();
    for($ind = 0; $ind < $arr_size; ++$ind) {
        $returnArray["browsers"][$ind] = $this->browsers($ind)->getAssocArray();
    }
    return $returnArray;
  }
}
?>