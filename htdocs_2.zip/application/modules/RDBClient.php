<?php

class RDBClient {

    private static $pdo;
    private static $dbh;

    static function DB() {
        if (!isset(self::$dbh) && empty(self::$dbh)) {
            self::$pdo = new PDO(REMOTE_DATABASE_SOURCE_NAME, REMOTE_DATABASE_USER_NAME, REMOTE_DATABASE_USER_PASSWORD);
            self::$dbh = new Db(self::$pdo);
        }
        return self::$dbh;
    }
}