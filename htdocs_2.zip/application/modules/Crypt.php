<?php

require_once 'application/modules/sodium_compat-1.12.2/autoload.php';

// TODO: обернуть весь код в исключения
class Crypt
{
    public static function encode($message)
    {
        $nonce = \Sodium\randombytes_buf(24);

        //$encoded = \ParagonIE_Sodium_Core32_XSalsa20::xsalsa20_xor($message, $nonce, XSALSA20_CRYPT_KEY);

        $encoded = Crypt::callPythonXSalsa(XSALSA20_CRYPT_KEY, $nonce, $message);
        unset($message);
        Logger::Trace('Crypt (class)', 'encode', 'Response message encoded. Encoded message is empty: ');
        //Logger::Trace('Crypt (class)', 'encode', 'Response message encoded. Encoded message is empty: ' . (empty($encoded) ? 'true' : 'false'));

        if ($encoded == null)
        {
            return null;
        }

        // die((int)(memory_get_peak_usage(true) / 1024));
        return $nonce . $encoded;
    }

    public static function decode($encryptedMessage)
    {
        Logger::Trace('Crypt (class)', 'decode', 'Start to decode protobuf packet');
        $nonce = substr($encryptedMessage, 0, 24);
        $clearMessage = substr($encryptedMessage, 24);

        unset($encryptedMessage);

        Logger::Trace('Crypt (class)', 'decode', $nonce);

        $decoded = Crypt::callPythonXSalsa(XSALSA20_CRYPT_KEY, $nonce, $clearMessage);

        unset($clearMessage);

        Logger::Trace('Crypt (class)', 'decode', 'End to decode protobuf packet. Decoded string is empty: ' . (empty($decoded) ? 'true' : 'false'));

        if ($decoded == null)
        {
            return null;
        }

        return $decoded;
        //return \ParagonIE_Sodium_Core32_XSalsa20::xsalsa20_xor($clearMessage, $nonce, XSALSA20_CRYPT_KEY);
    }

    private static function callPythonXSalsa($key, $nonce, $buffer)
    {
        try
        {
            $paramsObj = array();
            $paramsObj['nonce'] = base64_encode($nonce);
            $paramsObj['key'] = base64_encode($key);
            $paramsObj['buffer'] = base64_encode($buffer);

            unset($buffer);

            $params = json_encode($paramsObj);

            unset($paramsObj);

            //$cmd = 'XSALSA_PARAMS=' . escapeshellarg($params) . ' python ' . __DIR__ . '/python_scripts/xsalsaCrypt.py';

            $cmd = 'python ' . __DIR__ . '/python_scripts/xsalsaCrypt.py';

            $descriptorspec = array(
                0 => array("pipe", "r"),
                1 => array("pipe", "w"),
                2 => array("pipe", "w")
            );

            $process = proc_open($cmd, $descriptorspec, $pipes);

            if (is_resource($process))
            {
                fwrite($pipes[0], $params);
                fclose($pipes[0]);

                $output = stream_get_contents($pipes[1]);
                $stderr = stream_get_contents($pipes[2]);
                fclose($pipes[1]);
                fclose($pipes[2]);

                if (!empty($stderr))
                {
                    Logger::Error('Crypt (class)', 'callPythonXSalsa', $stderr);
                }


                if ($output === '0')
                {
                    return null;
                }
                return base64_decode($output);
            }

            return null;
        }
        catch(Exception $ex)
        {
            die($ex);
        }
    }
}