<?php

class Controller {
	
	protected $model;
	protected $view;
	protected $data;

	public function __construct()
	{
		$this->view = new View();
	}
	
	// действие по умолчанию
	public function action_index()
	{
		// TODO: make the auth test else redirect to 403
	}

	public function setData(&$data) {
	    $this->data = $data;
    }
}
