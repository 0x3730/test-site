<?php
namespace DAL\Models
{
    class SoftwareReport
    {

    }
}