<?php

namespace DAL\Models
{
    class Task
    {

    }
}