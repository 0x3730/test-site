<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Countries</h6></div>
            <div class="form-actions text-center">
                <table class="table table-condensed table-bordered">
                    <thead>
                    <tr>
                        <th>Country</th>
                        <th>Online Bots</th>
                        <th>Offline Bots</th>
                        <th>Total Bots</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $countries_stats_table = '';
                    foreach($countries_stats as $countries_stat) {
                        $countries_stats_table.='
                                        <tr>
                                            <td>'.$countries_stat['country'].'</td>
                                            <td>'.$countries_stat['count_online'].'</td>
                                            <td>'.$countries_stat['count_offline'].'</td>
                                            <td>'.$countries_stat['count_all'].'</td>
                                        </tr>';
                    }
                    echo $countries_stats_table;
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>