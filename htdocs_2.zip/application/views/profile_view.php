<div class="page-title">
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="row">
                <div class="col-sm-3 col-md-3 col-lg-3" data-user-profile>

                </div>
                <div class="form-group" style="margin-top: 16%; margin-left: 1%;">
                    <button class="btn btn-default" id="edit_user_profile">
                        Edit
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>