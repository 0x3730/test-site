<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div class="input-group">
                    <input id="screenshots_filter" type="text" name="botid" class="form-control search-input" placeholder="Pattern (only supported '*' and '?')">
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="submit" onclick="searchScreenshots(false)"><i class="icon-search"></i></button>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div id="grid-gallery" class="grid-gallery">
                    <section class="grid-wrap">
                        <ul class="grid" id="screenshots-data-container-1">
                        </ul>
                    </section>
                    <section class="slideshow">
                        <ul id="screenshots-data-container-2">
                        </ul>
                        <nav>
                            <span class="fa fa-angle-left nav-prev"></span>
                            <span class="fa fa-angle-right nav-next"></span>
                            <span class="icon-close nav-close"></span>
                        </nav>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div id="screenshots-data-pagination"></div>
            </div>
        </div>
    </div>
</div>