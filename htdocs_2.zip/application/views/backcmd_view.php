<div class="page-title">
    <h5><i class="fa fa-bars"></i> Backcmd Logs </h5>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div style="padding: 15px; overflow: auto">
                <table id="backcmd" class="table table-condensed" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th style="word-wrap: break-word;">BOT ID</th>
                        <th style="word-wrap: break-word;">IP</th>
                        <th style="word-wrap: break-word;">PORT</th>
                        <th style="word-wrap: break-word;">LOGIN</th>
                        <th style="word-wrap: break-word;">PASSWORD</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>