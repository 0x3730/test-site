<script>
    $(document).ready(function () {
        userInfo.updateUserInfo();
    });

    const userInfo = {
        updateUserInfo: function () {
            $.get(document.location.pathname + '/get_user_info?user_id=<?php echo $_GET['user_id']; ?>')
                .success(function (res) {
                    $('[data-user-edit]').empty();
                    $('[data-user-edit]').append(res);
                });
        }
    };
</script>
<div class="page-title">
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="row">
                <div class="col-sm-3 col-md-3 col-lg-3" data-user-edit>

                </div>
                <div class="form-group" style="margin-top: 23%; margin-left: 1%;">
                    <button class="btn btn-default" id="edit_user_button">
                        Edit
                    </button>
                    <button class="btn btn-danger" id="delete_user_button">
                        Delete User
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>