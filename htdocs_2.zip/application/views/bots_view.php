<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Bots List</h6></div>

            <div class="accordion panel-group" id="accordion-filters" role="tablist" aria-multiselectable="false">
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="general-filter-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion-filters" href="#general-filter" aria-expanded="true" aria-controls="general-filter">
                                General filter
                            </a>
                        </h4>
                    </div>
                    <div id="general-filter" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="general-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="input-group">
                                <input type="text" id="bots_filter" class="form-control search-input" placeholder="only supported '*' and '?'">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="submit" onclick="searchBotsData(false)"><i class="icon-search"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="advanced-filter-heading">
                        <h4 class="panel-title">
                            <a class="collapsed" data-toggle="collapse" data-parent="#accordion-filters" href="#advanced-filter" aria-expanded="false" aria-controls="advanced-filter">
                                Advanced filter
                            </a>
                        </h4>
                    </div>
                    <div id="advanced-filter" class="panel-collapse collapse" role="tabpanel" aria-labelledby="advanced-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="row">
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Bot ID</label>
                                    <input id="bots_filter_bot_id" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>OS</label>
                                    <input id="bots_filter_os" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Domain Name</label>
                                    <input id="bots_filter_domain_name" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>IP</label>
                                    <input id="bots_filter_ip" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Flow ID</label>
                                    <input id="bots_filter_build_version" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Country</label>
                                    <input id="bots_filter_country" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Layer IP</label>
                                    <input id="bots_filter_layer_ip" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Status</label>
                                    <div class="checkbox">
                                        <label>
                                            <input id="bots_filter_online" type="checkbox">Online
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-sm-12 text-right">
                                    <button class="btn btn-default" onclick="searchBotsData(true)">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br>

            <div style="overflow: auto">
                <table class="table table-condensed table-bordered ex-coder-adminki-pidor">
                    <thead>
                    <tr>
                        <th>BOT ID</th>
                        <th>OS</th>
                        <th>Domain</th>
                        <th>1<small>st</small> login</th>
                        <th>IP</th>
                        <th>Layer IP</th>
                        <th>Flow ID</th>
                        <th>Country</th>
                        <th>Status</th>
                        <th>Action</th>
                        <th>Comment</th>
                    </tr>
                    </thead>
                    <tbody id="bots-data-container">
                    </tbody>
                </table>
            </div>

            <div id="bots-data-pagination"></div>
        </div>
    </div>
</div>