<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Users List</h6></div>

            <!-- <div class="accordion panel-group" id="accordion-filters" role="tablist" aria-multiselectable="false">
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="general-filter-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion-filters" href="#general-filter"
                               aria-expanded="false" aria-controls="general-filter">
                                Search
                            </a>
                        </h4>
                    </div>
                    <div id="general-filter" class="panel-collapse collapse" role="tabpanel"
                         aria-labelledby="general-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="input-group">
                                <input type="text" id="bots_filter" class="form-control search-input"
                                       placeholder="Only supported search login">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="submit"><i
                                                class="icon-search"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="accordion panel-group" id="accordion-filters-0" role="tablist" aria-multiselectable="false">
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="general-filter-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion-filters-0" href="#general-filter-0"
                               aria-expanded="false" aria-controls="general-filter">
                                Add User
                            </a>
                        </h4>
                    </div>
                    <div id="general-filter-0" class="panel-collapse collapse" role="tabpanel"
                         aria-labelledby="general-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="row">
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Login</label>
                                    <input id="new_user_login" type="text" class="form-control" placeholder="Login">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Password</label>
                                    <input id="new_user_password" type="password" class="form-control"
                                           placeholder="Password">

                                    <label>Preset Access Role</label>
                                    <select name="roles" class="form-control" id="new_user_privilege" data-roles-list-view>

                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-sm-12 text-right">
                                    <button class="btn btn-default" id="add_new_user">Add User</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="accordion panel-group hidden" id="accordion-filters-1" role="tablist" aria-multiselectable="false">
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="general-filter-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion-filters-1" href="#general-filter-1"
                               aria-expanded="false" aria-controls="general-filter">
                                Add Role
                            </a>
                        </h4>
                    </div>
                    <div id="general-filter-1" class="panel-collapse collapse" role="tabpanel"
                         aria-labelledby="general-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="row">
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Name Role</label>
                                    <input id="new_role_name" type="text" class="form-control" placeholder="Role Name">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Allow All</label>
                                    <input id="access_all" type="checkbox" class="form-control" value="ALL">
                                    <label>Allow Admin CP</label>
                                    <input id="access_users_cp" type="checkbox" class="form-control" value="ALLOW_USERS_CP">
                                    <label>Allow Bots</label>
                                    <input id="access_bots" type="checkbox" class="form-control" value="ALLOW_BOTS">
                                    <label>Allow Task</label>
                                    <input id="access_task_cp" type="checkbox" class="form-control" value="ALLOW_TASK_CP">
                                    <label>Allow Web Inject</label>
                                    <input id="access_web_inj_cp" type="checkbox" class="form-control" value="ALLOW_WEB_INJ_CP">
                                    <label>Allow Grabber Settings</label>
                                    <input id="access_grabber_settings_cp" type="checkbox" class="form-control" value="ALLOW_GRABBER_SETTINGS_CP">
                                    <label>Allow All Reports</label>
                                    <input id="access_all_report" type="checkbox" class="form-control" value="ALLOW_ALL_REPORTS">
                                    <label>Allow Report Stealer</label>
                                    <input id="access_report_stealer" type="checkbox" class="form-control" value="ALLOW_REPORT_STEALER">
                                    <label>Allow Report Socks</label>
                                    <input id="access_report_socks" type="checkbox" class="form-control" value="ALLOW_REPORT_SOCKS">
                                    <label>Allow Report BackCMD</label>
                                    <input id="access_report_backcmd" type="checkbox" class="form-control" value="ALLOW_REPORT_BACKCMD">
                                    <label>Allow Report HTTP Grabber</label>
                                    <input id="access_report_http_grabber" type="checkbox" class="form-control" value="ALLOW_REPORT_HTTP_GRABBER">
                                    <label>Allow Report Screenshots</label>
                                    <input id="access_report_screenshots" type="checkbox" class="form-control" value="ALLOW_REPORT_SCREENSHOTS">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-sm-12 text-right">
                                    <button class="btn btn-default" id="add_new_role">Add Role</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br>

            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#users-cp-tab-1" id='users-cp-tab-1-button' role="tab" data-toggle="tab">Users CP</a>
                </li>
                <li role="presentation"><a href="#role-cp-tab-2" id='role-cp-tab-2-button' role="tab" data-toggle="tab">Role CP</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active fade in" id="users-cp-tab-1">
                    <div style="overflow: auto">
                        <table class="table table-condensed table-condensed" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Login</th>
                                <th>Last online</th>
                                <th>Action Edit</th>
                                <th>Action Delete</th>
                            </tr>
                            </thead>
                            <tbody data-users-list>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade" id="role-cp-tab-2">
                    <div style="overflow: auto">
                        <table class="table table-condensed table-condensed" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name Role</th>
                                <!-- <th>List Access</th> -->
                                <th>Action Edit</th>
                                <th>Action Delete</th>
                            </tr>
                            </thead>
                            <tbody data-roles-list>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>