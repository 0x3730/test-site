<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Software</h6></div>
            <div class="panel-body">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab1" role="tab" data-toggle="tab">Installed software</a></li>
                        <li role="presentation"><a href="#tab2" role="tab" data-toggle="tab">Antiviruses</a></li>
                        <li role="presentation"><a href="#tab3" role="tab" data-toggle="tab">Firewalls</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active fade in" id="tab1">
                            <table class="table table-condensed table-bordered">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Vendor</th>
                                    <th>Count</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $software_data = '';
                                foreach($software as $software_item) {
                                    $software_data.='
                                        <tr>
                                            <td>'.htmlspecialchars($software_item['name']).'</td>
                                            <td>'.htmlspecialchars($software_item['vendor']).'</td>
                                            <td>'.htmlspecialchars($software_item['count']).'</td>
                                        </tr>';
                                }
                                echo $software_data;
                                ?>
                                </tbody>
                            </table>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab2">
                            <table class="table table-condensed table-bordered">
                                <thead>
                                <tr>
                                    <th>Antivirus name</th>
                                    <th>Count</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $antiViruses_data = '';
                                foreach($antiViruses as $antiVirus) {
                                    $antiViruses_data.='
                                        <tr>
                                            <td>'.htmlspecialchars($antiVirus['name']).'</td>
                                            <td>'.htmlspecialchars($antiVirus['count']).'</td>
                                        </tr>';
                                }
                                echo $antiViruses_data;
                                ?>
                                </tbody>
                            </table>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab3">
                            <table class="table table-condensed table-bordered">
                                <thead>
                                <tr>
                                    <th>Firewall name</th>
                                    <th>Count</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $firewall_data = '';
                                foreach($firewalls as $firewall) {
                                    $firewall_data.='
                                        <tr>
                                            <td>'.htmlspecialchars($firewall['name']).'</td>
                                            <td>'.htmlspecialchars($firewall['count']).'</td>
                                        </tr>';
                                }
                                echo $firewall_data;
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>