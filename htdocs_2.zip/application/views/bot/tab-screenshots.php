<!--<div id="screenshots-data-container"></div>
<div id="screenshots-data-pagination"></div>-->
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div id="grid-gallery" class="grid-gallery">
                    <section class="grid-wrap">
                        <ul class="grid" id="screenshots-data-container-1">
                        </ul>
                    </section>
                    <section class="slideshow">
                        <ul id="screenshots-data-container-2">
                        </ul>
                        <nav>
                            <span class="fa fa-angle-left nav-prev"></span>
                            <span class="fa fa-angle-right nav-next"></span>
                            <span class="icon-close nav-close"></span>
                        </nav>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div id="screenshots-data-pagination"></div>
            </div>
        </div>
    </div>
</div>