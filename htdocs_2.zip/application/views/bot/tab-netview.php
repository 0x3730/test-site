<?php //echo json_encode($netViewInfo); ?>
<h5>Domain info</h5>
<div style="overflow: auto">
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <td><?php echo htmlspecialchars($netViewInfo['domain_name']);?></td>
            </tr>
            <tr>
                <th>Role</th>
                <td><?php echo htmlspecialchars($netViewInfo['domain_role']);?></td>
            </tr>
            <tr>
                <th>Extended name</th>
                <td><?php echo htmlspecialchars($netViewInfo['extended_name']);?></td>
            </tr>
            <tr>
                <th>Network shares</th>
                <td style="border-bottom: 1px solid #ddd;"><?php echo htmlspecialchars($netViewInfo['network_shares']);?></td>
            </tr>
        </thead>
    </table>
</div>
<h5>Clients</h5>
<div class="list-group">
<?php
    if (!empty($netViewInfo['clients'])) {
        foreach ($netViewInfo['clients'] as $client) {
            // class="list-group-item active"
            echo '
            <div class="list-group-item bot-netview-list-item-margin">
                <h4 class="list-group-item-heading">' . htmlspecialchars($client['name']) . '</h4>
                <p class="list-group-item-text">Type: ' . htmlspecialchars($client['type']) . '<br>Platform: ' . htmlspecialchars($client['platform']) . '<br>Comment: ' . htmlspecialchars($client['comment']) . '</p>
            </div>
            ';
        }
    } else {
        echo 'Clients was not found.';
    }
?>
</div>

