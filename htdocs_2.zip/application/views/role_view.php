<script>
    $(document).ready(function () {
        roleInfo.updateRoleInfo();
    });

    const roleInfo = {
        updateRoleInfo: function () {
            $.get(document.location.pathname + '/get_role_info?role_id=<?php echo $_GET['role_id']; ?>')
                .success(function (res) {
                    $('[data-role-edit]').empty();
                    $('[data-role-edit]').append(res);
                });
        }
    };
</script>
<div class="page-title">
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="row">
                <div class="col-sm-3 col-md-3 col-lg-3" data-role-edit>

                </div>
                <div class="form-group" style="margin-top: 33%; margin-left: 1%;">
                    <button class="btn btn-default" id="edit_role_button">
                        Edit
                    </button>
                    <button class="btn btn-danger" id="delete_role_button" onclick='deleteRole(<?php echo $_GET['role_id']; ?>)'>
                        Delete Role
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>