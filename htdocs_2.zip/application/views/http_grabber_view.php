<div class="page-title">
</div>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">

            <div class="accordion panel-group" id="accordion-filters" role="tablist" aria-multiselectable="false">
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="general-filter-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion-filters" href="#general-filter" aria-expanded="true" aria-controls="general-filter">
                                General filter
                            </a>
                        </h4>
                    </div>
                    <div id="general-filter" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="general-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="input-group">
                                <input type="text" id="http_grabber_filter" class="form-control search-input" placeholder="Type text for filtering rows...">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="submit" onclick="searchHttpGrabberData(false)"><i class="icon-search"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-white">
                    <div class="panel-heading" role="tab" id="advanced-filter-heading">
                        <h4 class="panel-title">
                            <a class="collapsed" data-toggle="collapse" data-parent="#accordion-filters" href="#advanced-filter" aria-expanded="false" aria-controls="advanced-filter">
                                Advanced filter
                            </a>
                        </h4>
                    </div>
                    <div id="advanced-filter" class="panel-collapse collapse" role="tabpanel" aria-labelledby="advanced-filter-heading">
                        <div class="panel-body" style="padding: 20px;">
                            <div class="row">
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Bot ID</label>
                                    <input id="forms_filter_bot_id" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>URL</label>
                                    <input id="forms_filter_url" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>User-Agent</label>
                                    <input id="forms_filter_user_agent" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Content-Type</label>
                                    <input id="forms_filter_content_type" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Referer</label>
                                    <input id="forms_filter_referer" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Cookie</label>
                                    <input id="forms_filter_cookie" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                                <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                    <label>Post Data</label>
                                    <input id="forms_filter_post_data" type="text" class="form-control" placeholder="only supported '*' and '?'">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-sm-12 text-right">
                                    <button class="btn btn-default" onclick="searchHttpGrabberData(true)">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>


            <div id="http-grabber-data-container"></div>
            <div id="http-grabber-data-pagination"></div>
        </div>
    </div>
</div>