<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading panel-heading--with-btn">
                <h6 class="panel-title" id="web-injects-head-title">Web-Injects Campaigns</h6>
                <button type="button" class="btn btn-default" id="web-injects-head-button">New campaign</button>
            </div>
            <div class="panel-body">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#inject-tab-1" role="tab" data-toggle="tab" data-type-web-inject="inject-tab-1">Web-Injects Campaigns</a></li>
                        <li role="presentation"><a href="#inject-tab-2" role="tab" data-toggle="tab" data-type-web-inject="inject-tab-2">Web-Injects Groups</a></li>
                        <li role="presentation"><a href="#inject-tab-3" role="tab" data-toggle="tab" data-type-web-inject="inject-tab-3">Web-Injects List</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active fade in" id="inject-tab-1">
                            <div style="overflow: auto">
                                <table id="table-web-injects-campaigns" class="table table-condensed" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th style="text-transform: uppercase; word-wrap: break-word;">Campaign</th>
                                        <th style="text-transform: uppercase; word-wrap: break-word;">Description</th>
                                        <th style="text-transform: uppercase; word-wrap: break-word;">Injects count</th>
                                        <th>ACTIONS</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="inject-tab-2">
                            <div style="overflow: auto">
                                <table id="table-web-injects-groups" class="table table-condensed" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th style="word-wrap: break-word;">GROUP</th>
                                        <th style="word-wrap: break-word;">DESCRIPTION</th>
                                        <th style="word-wrap: break-word;">INJECTS COUNT</th>
                                        <th>ACTIONS</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="inject-tab-3">
                            <div style="overflow: auto">
                                <table id="table-web-injects" class="table table-condensed" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th style="word-wrap: break-word;">NAME</th>
                                        <th style="word-wrap: break-word;">DESCRIPTION</th>
                                        <th>ACTIONS</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>