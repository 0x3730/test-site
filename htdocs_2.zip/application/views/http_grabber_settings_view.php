<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">HTTP Grabber settings</h6></div>
            <div class="panel-body">
                <form id="http_grabber_settings" role="form" action="javascript:void(0);">
                    <div class="form-group">
                        <label>Configuration</label>
                        <textarea id="configuration" class="form-control" placeholder="Enter configuration..." style="resize: none; min-height: 400px;"><?php echo $grabberConfiguration;?></textarea>
                    </div>
                    <!--<div class="form-group">
                        <label>Status</label>
                        <select data-placeholder="Choose a status..." class="select-full select2-offscreen" tabindex="-1" id="status">
                            <option value="1">Enabled</option>
                            <option value="0">Disabled</option>
                        </select>
                    </div>-->
                   <!-- <div class="form-group">
                        <label>Request type</label>
                        <select data-placeholder="Choose a request type..." class="select-full select2-offscreen" tabindex="-1" id="request_type">
                            <option value="GET">GET</option>
                            <option value="POST">POST</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Content-type</label>
                        <input id="content_type" class="form-control" placeholder="Enter content-type...">
                    </div>
                    <div class="form-group">
                        <label>Keywords</label>
                        <input type="text" id="keywords" class="tags" data-placeholder="Enter keywords...">
                    </div>
                    <div class="form-group">
                        <label>Blacklist</label>
                        <input type="text" id="blacklist" class="tags" data-no-duplicate-text="Duplicate tags" data-placeholder="Fill blacklist...">
                    </div>-->
                    <div class="row form-actions">
                        <div class="col-xs-12">
                            <button type="submit" class="btn btn-danger  pull-right">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>