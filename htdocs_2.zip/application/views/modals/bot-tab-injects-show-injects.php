<div id="bot-tab-injects-show-injects" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Injects list</h5>
            </div>

            <!-- Table inside modal -->
            <div class="modal-body">
                <div style="padding: 15px; overflow: auto">
                    <table id="bot-tab-injects-show-injects-table" class="table table-condensed table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th style="word-wrap: break-word;">NAME</th>
                                <th style="word-wrap: break-word;">DESCRIPTION</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
