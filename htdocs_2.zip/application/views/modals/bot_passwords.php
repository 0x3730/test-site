<div id="passwords_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Password Logs</h5>
            </div>

            <!-- Table inside modal -->
            <div class="modal-body has-padding">
                <div class="panel panel-white">
                    <div style="padding: 15px; overflow: auto">
                        <table id="bot_passwords" class="table table-condensed" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th style="word-wrap: break-word;">SERVICE</th>
                                    <th style="word-wrap: break-word;">LOGIN</th>
                                    <th style="word-wrap: break-word;">PASSWORD</th>
                                    <th style="word-wrap: break-word;">BROWSER</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
