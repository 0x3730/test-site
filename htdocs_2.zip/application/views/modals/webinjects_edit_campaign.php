<div id="web-injects-edit-campaign" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Campaign edit</h5>
            </div>

            <!-- Table inside modal -->
            <form id="form-web-injects-campaign-edit" data-campaign-id="" role="form" action="#">
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Name</label>
                        <input id="edit-webinject-campaign-name" class="form-control" placeholder="Enter campaign's name..." required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea id="edit-webinject-campaign-description" class="form-control" placeholder="Enter campaign's description..." style="resize: none; min-height: 80px;"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Bot Ids</label>
                        <textarea id="edit-webinject-campaign-botids" class="form-control" placeholder="Example: 12345, 23465, 234256" style="resize: none; min-height: 80px;" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Countries</label>
                        <textarea id="edit-webinject-campaign-countries" class="form-control" placeholder="Example: DE, EN, PL" style="resize: none; min-height: 80px;" required></textarea>
                    </div>
                    <div class="accordion panel-group" id="accordion-goi" role="tablist" aria-multiselectable="false">
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="accordion-goi-header">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion-goi" href="#accordion-goi-data" aria-controls="accordion-goi-data">
                                        Edit group or injects
                                    </a>
                                </h4>
                            </div>
                            <div id="accordion-goi-data" class="panel-collapse collapse" role="tabpanel" aria-labelledby="accordion-goi-header">
                                <div class="panel-body">
                                    <div role="tabpanel">
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li role="presentation" class="active"><a href="#campaign-edit-group-or-inject-tab-1" role="tab" data-toggle="tab" data-type-group-or-inject-edit="1">Choose group</a></li>
                                            <li role="presentation"><a href="#campaign-edit-group-or-inject-tab-2" role="tab" data-toggle="tab" data-type-group-or-inject-edit="2">Choose injects</a></li>
                                        </ul>
                                        <!-- Tab panes -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane active fade in" id="campaign-edit-group-or-inject-tab-1">
                                                <div class="form-group" data-campaign-edit-groups-list></div>
                                            </div>
                                            <div role="tabpanel" class="tab-pane fade" id="campaign-edit-group-or-inject-tab-2">
                                                <div class="form-group">
                                                    <div class="webinjects-check-list-scroll" data-campaign-edit-injects-list></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="text-right">
                        <input type="submit" value="Save" class="btn btn-default">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
