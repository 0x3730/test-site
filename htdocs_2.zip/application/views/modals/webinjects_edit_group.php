<div id="web-injects-edit-group" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Edit group</h5>
            </div>

            <!-- Table inside modal -->
            <form id="form-web-injects-group-edit" role="form" action="#">
                <div class="modal-body has-padding">
                        <div class="form-group">
                            <label>Name</label>
                            <input id="edit-webinject-group-name" class="form-control" placeholder="Enter group's name..." required>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea id="edit-webinject-group-description" class="form-control" placeholder="Enter group's description..." style="resize: none; min-height: 80px;"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="text-right">
                                <input type="submit" value="Save changes" class="btn btn-default">
                            </div>
                        </div>
                        <input id="edit-webinject-group-id" value="" hidden>
                    <label>Injects in the group</label>
                    <div class="panel">
                        <div class="form-group">
                            <div class="webinjects-check-list-scroll injects-list-block" data-injects-list-in-group>
                            </div>
                        </div>
                    </div>
                    <label>Injects out of the group</label>
                    <div class="panel">
                        <div class="form-group">
                            <div class="webinjects-check-list-scroll injects-list-block" data-injects-list-out-of-group>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                </div>
            </form>
        </div>
    </div>
</div>
