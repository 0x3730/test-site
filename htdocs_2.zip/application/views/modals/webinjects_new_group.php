<div id="web-injects-new-group" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Group creation</h5>
            </div>

            <!-- Table inside modal -->
            <form id="form-web-injects-group-new" role="form" action="#">
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Name</label>
                        <input id="new-webinject-group-name" class="form-control" placeholder="Enter group's name..." required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea id="new-webinject-group-description" class="form-control" placeholder="Enter group's description..." style="resize: none; min-height: 80px;"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Injects</label>
                        <!--<textarea id="new-webinject-source" class="form-control textarea-expanded" style="resize: none; min-height: 200px;" required></textarea>-->
                        <div class="webinjects-check-list-scroll" data-all-injects-list>
                            <?php
                                if (!empty($injectsList)) {
                                    foreach ($injectsList as $inject) {
                                        echo '
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" data-webinject-checkbox="'. $inject['id'] .'">'. $inject['name'] .'
                                            </label>
                                        </div>
                                        ';
                                    }
                                } else {
                                    echo 'Injects was not found.';
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="text-right">
                        <input type="submit" value="Create group" class="btn btn-default">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
