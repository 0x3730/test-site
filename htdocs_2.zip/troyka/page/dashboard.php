<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./css/dashboard.css">
	</head>
	
	<body>
		<div class="dashboard-container">
			<div class="dashboard-content">
				<div class="dashboard-content-title">
					Amount
				</div>
				
				<div class="dashboard-listview-container">
					<table>
						<?php
							$a_SimpleData = GetSimpleStats();
							echo "
								<td>
									All: $a_SimpleData[0]
								</td>
								<td>
									<span class=\"online\">Online:</span> $a_SimpleData[1]
								</td>
								<td>
									<span class=\"offline\">Offline:</span> $a_SimpleData[2]
								</td>
								<td>
									<span class=\"dead\">Dead:</span> $a_SimpleData[3]
								</td>
								<td>
									x64: $a_SimpleData[4]
								</td>
								<td>
									x86: $a_SimpleData[5]
								</td>
								<td>
									<span class=\"admin\">Admin:</span> $a_SimpleData[6]
								</td>
								<td>
									<span class=\"user\">User:</span> $a_SimpleData[7]
								</td>
							";
						?>
					</table>
				</div>
			</div>
			
			<div class="dashboard-group-box">
				<div class="dashboard-content group-box">
					<div class="dashboard-content-title">
						Computer Info
					</div>
					
					<div class="dashboard-listview-container">
						<table>
							<?php
								$a_WindowsData = GetWindowsStats();
								$b_SomeAdded = false;
								
								for($i = 0; $i < count($a_WindowsData); $i++)
								{
									$s_Windows = htmlentities($a_WindowsData[$i]["windows"]);
									$s_WindowsCount = htmlentities($a_WindowsData[$i]["wcount"]);
									
									echo "<tr>
										<td>
											$s_Windows
										</td>
										<td>
											$s_WindowsCount
										</td>
									</tr>
									";
									
									$b_SomeAdded = true;
								}
								
								if(!$b_SomeAdded)
									echo "<tr><th colspan=\"2\">~ Empty ~</th></tr>";
							?>
						</table>
					</div>
				</div>
				
				<div class="dashboard-content group-box">
					<div class="dashboard-content-title">
						Countries Info
					</div>
					
					<div class="dashboard-listview-container">
						<table>
							<?php
								$a_CountriesData = GetCountryStats();
								$b_SomeAdded = false;
								
								$iMax = count($a_CountriesData);
								if($iMax > 10)
									$iMax = 10;
								
								for($i = 0; $i < $iMax; $i++)
								{
									if(!$a_CountriesData[$i]["country"] or !$a_CountriesData[$i]["ccount"])
										break;
									
									$s_Country = htmlentities($a_CountriesData[$i]["country"]);
									$s_CountryCount = htmlentities($a_CountriesData[$i]["ccount"]);
									
									echo "<tr>
										<td>
											$s_Country
										</td>
										<td>
											$s_CountryCount
										</td>
									</tr>
									";
									
									$b_SomeAdded = true;
								}
								
								if(!$b_SomeAdded)
									echo "<tr><th colspan=\"2\">~ Empty ~</th></tr>";
							?>
						</table>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>