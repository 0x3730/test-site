<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./css/footer.css">
	</head>
	
	<body>
		<div class="footer-container">
			~ D.O.S.P ~
		</div>
	</body>
</html>