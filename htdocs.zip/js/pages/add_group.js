$('#add_group').click(function (e) {
    e.preventDefault();

    var arrValues = new Array();
    arrValues['name_group'] = $('#name_group').val();
    arrValues['list_install_software'] = $('#list_install_software').val();
    arrValues['list_url_form_grabber'] = $('#list_url_form_grabber').val();
    arrValues['list_os'] = $('#list_os').val();
    arrValues['list_netview_domain'] = $('#list_netview_domain').val();

    $.ajax({
        type: "post",
        url: 'add_group/add_new_group',
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res === '1') {
                $.jGrowl('Group added.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                $.jGrowl('Group no added', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
});