var dataTableWebInjects = null;
var dataTableWebInjectsGroups = null;
var dataTableWebInjectsCampaigns = null;

$(document).ready(function() {

    var webInjectTabs = [
        {
            TabId: 'inject-tab-1',
            TabName: 'Web-Injects Campaigns',
            ButtonName: 'New campaign',
            ModalOpen: function () { $('#web-injects-new-campaign').modal('show') }
        },
        {
            TabId: 'inject-tab-2',
            TabName: 'Web-Injects Groups',
            ButtonName: 'New group',
            ModalOpen: function () { $('#web-injects-new-group').modal('show') }
        },
        {
            TabId: 'inject-tab-3',
            TabName: 'Web-Injects List',
            ButtonName: 'New web-inject',
            ModalOpen: function () { $('#web-injects-new-webinject').modal('show') }
        }
    ];

    var currentTab = webInjectTabs[0];

    $('[data-type-web-inject]').on('click', function(el) {
        var $element = $(this);
        var $headerText = $('#web-injects-head-title');
        var $headerButton = $('#web-injects-head-button');

        var tabData = getTabById($element.data('type-web-inject'));
        if (currentTab === null || (currentTab !== null && tabData.TabId !== currentTab.TabId)) {
            changeTextFade($headerText, tabData.TabName);
            changeTextFade($headerButton, tabData.ButtonName);
            currentTab = tabData;
        }
    });

    $('#web-injects-head-button').on('click', function(el) {
        currentTab.ModalOpen();
    });

    expandTextarea('new-webinject-description');
    expandTextarea('new-webinject-source');

    $('.webinjects-check-list-scroll').slimScroll({
        height: '200px'
    });

    dataTableWebInjects = initDataTable('table-web-injects', '/webinjects_main/get_webinjects');
    dataTableWebInjectsGroups = initDataTable('table-web-injects-groups', '/webinjects_main/get_groups');
    dataTableWebInjectsCampaigns = initDataTable('table-web-injects-campaigns', '/webinjects_main/get_campaigns');

    /**
     * Web-injects table redraw listener
     */
    dataTableWebInjects.on('draw.dt', function () {
        $('[data-edit-inject-id]').on('click', function(el){
            getInjectDataById($(this).data('edit-inject-id'));
            $('#web-injects-edit-webinject').modal('show');
        });
    });

    /**
     * Groups table redraw listener
     */
    dataTableWebInjectsGroups.on('draw.dt', function () {
        $('[data-edit-group-id]').on('click', function(el) {
            getGroupDataById($(this).data('edit-group-id'));
            $('#web-injects-edit-group').modal('show');
        });
    });

    /**
     * Campaigns table redraw listener
     */
    dataTableWebInjectsCampaigns.on('draw.dt', function () {
        $('[data-edit-campaign-id]').on('click', function(el) {
            getCampaignDataById($(this).data('edit-campaign-id'));
            $('#web-injects-edit-campaign').modal('show');
        });
    });

    function getTabById(tabId) {
        if (tabId !== null) {
            return webInjectTabs.find(function(tab) {
                return tab.TabId === tabId;
            });
        }
    }

    function changeTextFade($element, text) {
        $element.fadeOut(150, function() { $element.text(text).fadeIn(150) });
    }
});

function expandTextarea(id) {
    document.getElementById(id).addEventListener('keyup', function() {
        this.style.overflow = 'hidden';
        this.style.height = 0;
        this.style.height = this.scrollHeight + 'px';
    }, false);
}

function initDataTable(id, url) {
    return $('#' + id).DataTable({
        "select": true,
        "autoWidth": false,
        "serverSide": true,
        "paging": true,
        "iDisplayLength": "10",
        "pageLength": 10,
        "ajax": {
            "url": url,
            "type": "POST",
            "dataType": "json",
            "contentType": 'application/x-www-form-urlencoded; charset=UTF-8'
        }
    });
}

function loadDataForModal() {

}

function loadInjectsList() {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_injects_list",
        headers: {"Content-Type" : "text/html; charset=utf-8"},
        success: function(res) {
            var injects = JSON.parse(res);
            var options = '';
            injects.forEach(function(inject) {
                options = options + '<div class="checkbox">' +
                    '<label>' +
                    '<input type="checkbox" data-webinject-checkbox="' + inject['id'] + '">' + inject['name'] +
                    '</label>' +
                    '</div>';
            });
            $('[data-all-injects-list]').html(options);
            $('[data-webinject-checkbox]').uniform();
        }
    });
}

function getCampaignDataById(id) {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_campaign_info",
        data: "id=" + id,
        success: function(res) {
            var campaign = JSON.parse(res);
            $('#edit-webinject-campaign-name').val(campaign['name']);
            $('#edit-webinject-campaign-description').val(campaign['description']);
            $('#edit-webinject-campaign-botids').val(campaign['botids']);
            $('#edit-webinject-campaign-countries').val(campaign['countries']);
            createInjectsListWithSelectedInjects(campaign['injects']);
            createGroupsListWithSelectedGroup(campaign['groups']);
            $('#form-web-injects-campaign-edit').data('campaign-id', id);
        }
    });
}

function loadGroupsList() {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_groups_list",
        success: function(res) {
            var groups = JSON.parse(res);
            var options = '';
            groups.forEach(function(group) {
                options = options + '<option value="' + group['id'] + '">' + group['name'] + '</option>"';
            });
            $('#new-webinject-campaign-group').html(options);
        }
    });
}

function getInjectDataById(id) {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_inject_info",
        data: "id=" + id,
        success: function(res) {
            var inject = JSON.parse(res);
            $('#edit-webinject-name').val(inject['name']);
            $('#edit-webinject-description').val(inject['description']);
            $('#edit-webinject-source').val(inject['source']);
            $('#edit-webinject-id').val(inject['id']);
        }
    });
}

function getGroupDataById(id) {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_group_info",
        data: "id=" + id,
        success: function(res) {
            getExcludedInjects(id);
            var group = JSON.parse(res);
            $('#edit-webinject-group-name').val(group['name']);
            $('#edit-webinject-group-description').val(group['description']);
            var injects = '';
            group['injects'].forEach(function(inject) {
                injects = injects + '<div class="btn btn-default btn-xs" data-inject-in-the-group="' + inject['id'] + '">' + inject['name'] + '<i class="fa fa-arrow-down"></i></div>';
            });
            $('[data-injects-list-in-group]').html(injects);
            $('#edit-webinject-group-id').val(group['id']);
        }
    });
}

function getExcludedInjects(group_id) {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_excluded_injects",
        data: "group_id=" + group_id,
        success: function(res) {
            var injectsAssoc = JSON.parse(res);
            var injects = '';
            injectsAssoc.forEach(function(inject) {
                injects = injects + '<div class="btn btn-default btn-xs" data-inject-out-of-the-group="' + inject['id'] + '">' + inject['name'] + '<i class="fa fa-arrow-up"></i></div>';
            });
            $('[data-injects-list-out-of-group]').html(injects);
            setListenerForInjectInGroup();
            setListenerForDeleteFromGroup();
        }
    });
}

function setListenerForInjectInGroup() {
    var $element = $('[data-inject-out-of-the-group]');
    $element.off();
    $element.on('click', function(el) {
        $el = $(this);
        toggleBlocksWithInjects(true);
        var data = [];
        data['group_id'] = $('#edit-webinject-group-id').val();
        data['inject_id'] = $el.data('inject-out-of-the-group');
        $.ajax({
            type: "post",
            url: "/webinjects_main/add_inject_to_group",
            data: Object.assign({}, data),
            success: function(res) {
                if (res !== '1') {
                    $.jGrowl('Inject was not add.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
                } else {
                    toggleBlocksWithInjects(false);
                    getGroupDataById(data['group_id']);
                    getExcludedInjects(data['group_id']);
                    dataTableWebInjectsGroups.draw();
                    dataTableWebInjectsCampaigns.draw();
                }
            }
        });
    });
}

function setListenerForDeleteFromGroup() {
    var $element = $('[data-inject-in-the-group]');
    $element.off();
    $element.on('click', function(el) {
        $el = $(this);
        toggleBlocksWithInjects(true);
        var data = [];
        data['group_id'] = $('#edit-webinject-group-id').val();
        data['inject_id'] = $el.data('inject-in-the-group');
        $.ajax({
            type: "post",
            url: "/webinjects_main/delete_inject_from_group",
            data: Object.assign({}, data),
            success: function(res) {
                if (res !== '1') {
                    $.jGrowl('Inject was not delete.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
                } else {
                    toggleBlocksWithInjects(false);
                    getGroupDataById(data['group_id']);
                    getExcludedInjects(data['group_id']);
                    dataTableWebInjectsGroups.draw();
                    dataTableWebInjectsCampaigns.draw();
                }
            }
        });
    });
}

function toggleBlocksWithInjects(isActive) {
    $('data-inject-out-of-the-group').prop('disabled', isActive);
    $('data-inject-in-the-group').prop('disabled', isActive);
}