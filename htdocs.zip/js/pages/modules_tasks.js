$('.select2-container-multi').show();

$('.unselect_all').on("click", function () {
    id = $(this).parent().attr('for');
    $('#' + id).select2('destroy').find('option').prop('selected', false).end().select2();
});

$(".select_all").on("click", function () {
    id = $(this).parent().attr('for');
    $('#' + id).select2('destroy').find('option').prop('selected', 'selected').end().select2();
});

$('#tasks i.fa-trash-o,i.fa-stop-circle-o,i.fa-play-circle-o').click(function () {
    task_id = $(this).parents('tr').attr('id');
    type = $(this).data('type');

    $.post('/modules_tasks/updtask', {task_id: task_id, action: type});

    type_msg = {'delete':'deleted','stop':'stoped','start':'started'};

    $.jGrowl('Task successfully '+type_msg[type], { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });

    if(type == "delete"){
        $(this).parents('tr').remove();
    }

});

$('#create_task').click(function(e){
    e.preventDefault();
    var arrValues= new Array();
    arrValues['os'] = $('#os').val();
    arrValues['country'] = $('#countries').val();
    arrValues['module_id'] = $('#module_chosen').val();
    if ($('#config_is_choosing').is(":checked") == true) {
        arrValues['config_id'] = $('#config_chosen').val();
    }
    arrValues['context'] = $('#context').val();
    if ($('#flags').val() == '') {
        arrValues['flags'] = 0;
    } else {
        arrValues['flags'] = $('#flags').val();
    }
    arrValues['interval'] = $('#interval').val();


    console.log(Object.assign({}, arrValues));

    $.ajax({
        type: "post",
        url: "/modules_tasks/newtask",
        data: Object.assign({}, arrValues),
        success: function(res) {
            $('#form_modal').modal('hide');
            if (res == '1') {
                $.jGrowl('Task added.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                setTimeout(function() {window.location.reload();}, 7000);
            } else {
                $.jGrowl('Task not added.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }
        }
    });
});

$('#module_chosen').on("change", function(e) {
    var newModuleID = $(this).val();
    getConfigsForModule(newModuleID);
});

$('#config_is_choosing').on("change", function(){
    if ($('#config_is_choosing').is(":checked") == false) {
        $('#config_chosen').prop( "disabled", true );
    } else {
        $('#config_chosen').prop( "disabled", false );
    }
});

function showCreateTaskModal() {
    $('#config_chosen').prop( "disabled", true );
    $('#module_chosen').html('');
    $('#config_chosen').html('');
    $('#os').select2('destroy').find('option').prop('selected', false).end().select2();
    $('#countries').select2('destroy').find('option').prop('selected', false).end().select2();
    $('#context').val('');
    $('#flags').val('');
    $('#interval').val('');
    $.ajax({
        type: "get",
        dataType: 'json',
        url: "/modules/get_active_modules",
        success: function(res) {
            var resp_modules = res;
            if (Array.isArray(resp_modules)) {
                if (resp_modules.length > 0) {
                    resp_modules.forEach(function (item) {
                        $('#module_chosen').append(
                            '<option value="'+item.id+'">'+item.name+'</option>'
                        );
                    });
                    $('#module_chosen').val(resp_modules[0].id).trigger('change');
                    //$('#module_status').val(jsonRes['status']).trigger('change');
                }
            }
        }
    });
    $('#form_modal').modal('show');
}

function getConfigsForModule(module_id) {
    $('#config_is_choosing').prop("checked", false);
    $('#config_chosen').prop( "disabled", true );

    $.ajax({
        type: "get",
        dataType: 'json',
        url: "/modules/get_configs_for_module",
        data: "module_id="+module_id,
        success: function(res) {
            $('#config_chosen').html('');
            var resp_configs = res;
            if (Array.isArray(resp_configs)) {
                if (resp_configs.length > 0) {
                    resp_configs.forEach(function (item) {
                        $('#config_chosen').append(
                            '<option value="'+item.id+'">'+item.name+'</option>'
                        );
                    });
                    $('#config_is_choosing').prop( "disabled", false );
                    $('#config_chosen').val(resp_configs[0].id).trigger('change');
                } else {
                    $('#config_chosen').prop( "disabled", true );
                    $('#config_is_choosing').prop( "disabled", true );
                }
            } else {
                $('#config_chosen').prop( "disabled", true );
                $('#config_is_choosing').prop( "disabled", true );
            }
        }
    });
}

