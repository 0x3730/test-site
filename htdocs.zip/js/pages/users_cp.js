$(document).ready(function () {
    usersList.updateUsers();
    rolesList.updateRoles();
    rolesListView.updateRoleListView();
});

const usersList = {
    updateUsers: function () {
        $.get(document.location.pathname + '/get_users_list')
            .success(function (res) {
                $('[data-users-list]').empty();
                $('[data-users-list]').append(res);
            });
    }
};


const rolesList = {
    updateRoles: function () {
        $.get(document.location.pathname + '/get_roles_list')
            .success(function (res) {
                $('[data-roles-list]').empty();
                $('[data-roles-list]').append(res)
            });
    }
};

const rolesListView = {
    updateRoleListView: function () {
        $.get(document.location.pathname + '/get_roles_list_view')
            .success(function (res) {
                $('[data-roles-list-view]').empty();
                $('[data-roles-list-view]').append(res);

            });
    }
};

$('#add_new_user').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();
    arrValues['new_user_login'] = $('#new_user_login').val();
    arrValues['new_user_password'] = $('#new_user_password').val();
    arrValues['new_user_privilege'] = $('#new_user_privilege').val();

    $.ajax({
        type: "post",
        url: "/users_cp/add_new_user",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                usersList.updateUsers();
                $.jGrowl('User added.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                usersList.updateUsers();
                $.jGrowl('User no added', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })

});

$("#users-cp-tab-1-button").click(function () {
    $("#role-cp-tab-2").addClass('hidden');
    var element0 = document.getElementById("users-cp-tab-1");
    element0.classList.remove('hidden');
    usersList.updateUsers();

    var element1 = document.getElementById("accordion-filters-0");
    element1.classList.remove('hidden');
    $("#accordion-filters-1").addClass('hidden');
});

$("#role-cp-tab-2-button").click(function () {
    $("#users-cp-tab-1").addClass('hidden');
    var element0 = document.getElementById("role-cp-tab-2");
    element0.classList.remove('hidden');
    rolesList.updateRoles();

    var element1 = document.getElementById("accordion-filters-1");
    element1.classList.remove('hidden');

    $("#accordion-filters-0").addClass('hidden');
});


function deleteUser(id) {
    $.ajax({
        type: "get",
        url: 'users_cp/user_delete',
        data: "user_id=" + id,
        headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
        success: function (res) {
            if (res === '1') {
                usersList.updateUsers();
                $.jGrowl('User delete.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                usersList.updateUsers();
                $.jGrowl('User no delete', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    });

}

$('#add_new_role').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();

    arrValues['new_role_name'] = $('#new_role_name').val();

    if ($("#access_all").is(":checked")) {
        arrValues['access_all'] = $('#access_all').val();
    } else {
        arrValues['access_all'] = '';
    }

    if ($("#access_users_cp").is(":checked")) {
        arrValues['access_users_cp'] = $('#access_users_cp').val();
    } else {
        arrValues['access_users_cp'] = '';
    }

    if ($("#access_bots").is(":checked")) {
        arrValues['access_bots'] = $('#access_bots').val();
    } else {
        arrValues['access_bots'] = '';
    }

    if ($("#access_task_cp").is(":checked")) {
        arrValues['access_task_cp'] = $('#access_task_cp').val();
    } else {
        arrValues['access_task_cp'] = '';
    }

    if ($("#access_web_inj_cp").is(":checked")) {
        arrValues['access_web_inj_cp'] = $('#access_web_inj_cp').val();
    } else {
        arrValues['access_web_inj_cp'] = '';
    }

    if ($("#access_grabber_settings_cp").is(":checked")) {
        arrValues['access_grabber_settings_cp'] = $('#access_grabber_settings_cp').val();
    } else {
        arrValues['access_grabber_settings_cp'] = '';
    }

    if ($("#access_all_report").is(":checked")) {
        arrValues['access_all_report'] = $('#access_all_report').val();
    } else {
        arrValues['access_all_report'] = '';
    }

    if ($("#access_report_stealer").is(":checked")) {
        arrValues['access_report_stealer'] = $('#access_report_stealer').val();
    } else {
        arrValues['access_report_stealer'] = '';
    }

    if ($("#access_report_socks").is(":checked")) {
        arrValues['access_report_socks'] = $('#access_report_socks').val();
    } else {
        arrValues['access_report_socks'] = '';
    }

    if ($("#access_report_backcmd").is(":checked")) {
        arrValues['access_report_backcmd'] = $('#access_report_backcmd').val();
    } else {
        arrValues['access_report_backcmd'] = '';
    }

    if ($("#access_report_http_grabber").is(":checked")) {
        arrValues['access_report_http_grabber'] = $('#access_report_http_grabber').val();
    } else {
        arrValues['access_report_http_grabber'] = '';
    }

    if ($("#access_report_screenshots").is(":checked")) {
        arrValues['access_report_screenshots'] = $('#access_report_screenshots').val();
    } else {
        arrValues['access_report_screenshots'] = '';
    }

    $.ajax({
        type: "post",
        url: "users_cp/add_new_role",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                rolesList.updateRoles();
                $.jGrowl('Role added.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                rolesList.updateRoles();
                $.jGrowl('Role no added', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
});

function deleteRole(id) {
    $.ajax({
        type: "get",
        url: 'users_cp/role_delete',
        data: "role_id=" + id,
        headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
        success: function (res) {
            if (res === '1') {
                rolesList.updateRoles();
                $.jGrowl('Role delete.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                rolesList.updateRoles();
                $.jGrowl('Role no delete', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
}