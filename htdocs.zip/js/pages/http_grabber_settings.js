$(document).ready(function(){
    /*var keywords_tags = $('#keywords').tagsInput({width:'100%'});
    var blacklist_tags = $('#blacklist').tagsInput({width:'100%'});

    $('#status').on("change", function() {
        if ($('#status').val() == 1) {
            $('#request_type').prop("disabled", false);
            $('#content_type').prop("disabled", false);
            $('#keywords').prop("disabled", false);
            $('#keywords_tagsinput :input').prop("disabled", false);
            $('#blacklist_tagsinput :input').prop("disabled", false);
        } else {
            $('#request_type').prop("disabled", true);
            $('#content_type').prop("disabled", true);
            $('#keywords').prop("disabled", true);
            $('#keywords_tagsinput :input').prop("disabled", true);
            $('#blacklist_tagsinput :input').prop("disabled", true);
        }
    });*/

    expandTextarea('configuration');

    $('#http_grabber_settings').on('submit', function() {
        /*var data = [];
        data['status'] = $('#status').val();
        data['request_type'] = $('#request_type').val();
        data['content_type'] = $('#content_type').val();
        data['keywords'] = $('#keywords').val();
        data['blacklist'] = $('#blacklist').val();*/

        var data = [];
        data['config'] = $('#configuration').val();
        $.ajax({
            type: "post",
            url: "/http_grabber_settings/save_config",
            data: Object.assign({}, data),
            success: function (res) {
                if (res === '1') {

                    $.jGrowl('Configuration saved successfully.', {
                        sticky: false,
                        theme: 'growl-success',
                        header: 'Success!',
                        life: 3000
                    });
                } else {
                    $.jGrowl('Configuration was not save.', {
                        sticky: false,
                        theme: 'growl-error',
                        header: 'Error!',
                        life: 3000
                    });
                }
            }
        });
    });

});

function initializeTagsInput(hTag, str) {
    hTag.importTags(str);
}

function loadConfig() {
    $.ajax({
        type: "get",
        url: "/http_grabber_settings/load_settings",
        data: Object.assign({}, arrValues),
        success: function(res) {
            $('#form_modal').modal('hide');
            if (res == '1') {
                // clear form
                $('#os').select2('destroy').find('option').prop('selected', false).end().select2();
                $('#countries').select2('destroy').find('option').prop('selected', false).end().select2();
                $('#context').val('');
                $.jGrowl('Task added.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                setTimeout(function() {window.location.reload();}, 7000);
            } else {
                $.jGrowl('Task not added.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }
        }
    });
}

function expandTextarea(id) {
    document.getElementById(id).addEventListener('keyup', function() {
        this.style.overflow = 'hidden';
        this.style.height = 0;
        this.style.height = this.scrollHeight + 'px';
    }, false);
}