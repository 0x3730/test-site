$(document).ready(function () {
    profileList.updateProfile();
});

const profileList = {
    updateProfile: function () {
        $.get(document.location.pathname + '/get_profile_user')
            .success(function (res) {
                $('[data-user-profile]').empty();
                $('[data-user-profile]').append(res);
            });
    }
};

$('#edit_user_profile').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();
    arrValues['user_profile_password'] = $('#edit_profile_password').val();
    arrValues['user_id'] = $('#edit_profile_id').val();
    arrValues['user_profile_old_password'] = $('#edit_profile_old_password').val();

    $.ajax({
        type: "post",
        url: "/profile/edit_profile",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                profileList.updateProfile();
                $.jGrowl('Profile edit.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                profileList.updateProfile();
                $.jGrowl('Profile no edit.', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
});