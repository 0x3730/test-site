$('#delete_user_button').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();
    arrValues['user_id'] = $('#edit_user_id').val();

    $.ajax({
        type: "post",
        url: "/user/user_delete",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                userInfo.updateUserInfo();
                $.jGrowl('User delete.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                userInfo.updateUserInfo();
                $.jGrowl('User no delete.', {sticky: false, theme: 'growl-error', header: 'Success!', life: 3000});
            }
        }
    })
});


$('#edit_user_button').click(function (e) {
    e.preventDefault();
    var arrValues = new Array();
    arrValues['edit_user_id'] = $('#edit_user_id').val();
    arrValues['edit_user_login'] = $('#edit_user_login').val();
    arrValues['edit_user_password'] = $('#edit_user_password').val();
    arrValues['edit_user_privilege'] = $('#edit_user_privilege').val();

    $.ajax({
        type: "post",
        url: "/user/edit_user",
        data: Object.assign({}, arrValues),
        success: function (res) {
            if (res == '1') {
                userInfo.updateUserInfo();
                $.jGrowl('User edit.', {sticky: false, theme: 'growl-success', header: 'Success!', life: 3000});
            } else {
                userInfo.updateUserInfo();
                $.jGrowl('User no edit.', {sticky: false, theme: 'growl-error', header: 'Error!', life: 3000});
            }
        }
    })
});
