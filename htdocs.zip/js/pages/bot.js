var passwordsDataPagination;
var getPasswordsData;
var httpGrabberDataPagination;
var getHttpGrabberData;
var searchPasswords;
var searchHttpGrabberData;

$(document).ready(function(){

    var bot_id = $('#bot-info-botid').data('botid');

    var $passwordsDataContainer = $('#passwords-data-container');
    var $passwordsDataPaginationView = $('#passwords-data-pagination');
    var passwordsDataPageSize = 10;
    if ($passwordsDataContainer.length && $passwordsDataPaginationView.length) {
        passwordsDataPagination = createPagination(
            $passwordsDataPaginationView,
            '/bot/get_passwords_data?bot_id=' + bot_id,
            passwordsDataPageSize,
            $passwordsDataContainer,
            $('#passwords_filter').length ? $('#passwords_filter').val() : '',
            getPasswordsFiltersJson()
        );
    }

    searchPasswords = function(isAdditionalSearch) {
        if (isAdditionalSearch === true && $('#passwords_filter').length) {
            $('#passwords_filter').val('');
        } else {
            $('#passwords_filter_service').val('');
            $('#passwords_filter_login').val('');
            $('#passwords_filter_browser').val('');
        }
        getPasswordsData();
    };

    getPasswordsData = function() {
        $passwordsDataPaginationView.pagination('destroy');
        passwordsDataPagination = createPagination(
            $passwordsDataPaginationView,
            '/bot/get_passwords_data?bot_id=' + bot_id,
            passwordsDataPageSize,
            $passwordsDataContainer,
            $('#passwords_filter').length ? $('#passwords_filter').val() : '',
            getPasswordsFiltersJson()
        );
    };

    function getPasswordsFiltersJson()
    {
        const filters = [
            {
                name: 'service',
                value: $('#passwords_filter_service').val()
            },
            {
                name: 'login',
                value: $('#passwords_filter_login').val()
            },
            {
                name: 'browser',
                value: $('#passwords_filter_browser').val()
            }
        ];
        return JSON.stringify(Object.assign({}, filters));
    }

    //passwords end

    // screenshots
    var $screenshotsDataContainer1 = $('#screenshots-data-container-1');
    var $screenshotsDataContainer2 = $('#screenshots-data-container-2');
    var $screenshotsDataPaginationView = $('#screenshots-data-pagination');
    var screenshotsDataPageSize = 10;
    $('[data-type-web-inject]').on('click', () => {
        if (window.CBPGridGalleryCustom != null && window.CBPGridGalleryCustom.masonry != null) {
            if (window.CBPGridGalleryCustom.masonry.maxY < 0) {
                setTimeout(() => {
                    window.CBPGridGalleryCustom.masonry.resize();
                }, 500);
            }
        }
    });
    if ($screenshotsDataContainer1.length && $screenshotsDataContainer2.length && $screenshotsDataPaginationView.length) {
        createCustomP({
            $paginationView: $screenshotsDataPaginationView,
            url: '/bot/get_screenshots_data?bot_id=' + bot_id,
            pageSize: screenshotsDataPageSize,
            $dataContainers: [$screenshotsDataContainer1,$screenshotsDataContainer2],
            callbackBefore: () => {},
            callbackAfter: () => {
                $(function(){
                    "use strict";
                    if (window.CBPGridGalleryCustom == null) {
                        window.CBPGridGalleryCustom = new CBPGridGallery(document.getElementById( 'grid-gallery' ));
                    }
                    window.CBPGridGalleryCustom.init(document.getElementById( 'grid-gallery' ));
                });
            }
        })
    }

    // screenshots end


    // forms grabber
    var $httpGrabberDataContainer = $('#http-grabber-data-container');
    var $httpGrabberDataPaginationView = $('#http-grabber-data-pagination');
    var httpGrabberDataPageSize = 10;
    if ($httpGrabberDataContainer.length && $httpGrabberDataPaginationView.length) {
        httpGrabberDataPagination = createPagination(
            $httpGrabberDataPaginationView,
            '/bot/get_http_grabber_data?bot_id=' + bot_id,
            httpGrabberDataPageSize,
            $httpGrabberDataContainer,
            $('#http_grabber_filter').length ? $('#http_grabber_filter').val() : '',
            getGrabberFiltersJson()
        );
    }

    searchHttpGrabberData = function(isAdditionalSearch) {
        if (isAdditionalSearch === true && $('#http_grabber_filter').length) {
            $('#http_grabber_filter').val('');
        } else {
            $('#forms_filter_url').val('');
            $('#forms_filter_user_agent').val('');
            $('#forms_filter_content_type').val('');
            $('#forms_filter_referer').val('');
            $('#forms_filter_cookie').val('');
            $('#forms_filter_post_data').val('');
        }
        getHttpGrabberData();
    };

    getHttpGrabberData = function() {
        $httpGrabberDataPaginationView.pagination('destroy');
        httpGrabberDataPagination = createPagination(
            $httpGrabberDataPaginationView,
            '/bot/get_http_grabber_data?bot_id=' + bot_id,
            httpGrabberDataPageSize,
            $httpGrabberDataContainer,
            $('#http_grabber_filter').length ? $('#http_grabber_filter').val() : '',
            getGrabberFiltersJson()
        );
    };

    function getGrabberFiltersJson()
    {
        const filters = [
            {
                name: 'url',
                value: $('#forms_filter_url').val()
            },
            {
                name: 'useragent',
                value: $('#forms_filter_user_agent').val()
            },
            {
                name: 'content_type',
                value: $('#forms_filter_content_type').val()
            },
            {
                name: 'referer',
                value: $('#forms_filter_referer').val()
            },
            {
                name: 'cookie',
                value: $('#forms_filter_cookie').val()
            },
            {
                name: 'post_data',
                value: $('#forms_filter_post_data').val()
            }
        ];
        return JSON.stringify(Object.assign({}, filters));
    }


    // forms grabber end

    function createPagination($paginationView, url, pageSize, $dataContainer, filter, additional_filters) {
        filter = filter || '';
        additional_filters = additional_filters || '';
        return $paginationView.pagination({
            dataSource: url,
            locator: 'items',
            showNavigator: true,
            showPageNumbers: true,
            showPrevious: true,
            showNext: true,
            totalNumberLocator: function(response) {
                return response['totalCount'];
            },
            pageSize: pageSize,
            ajax: {
                beforeSend: function() {
                    $dataContainer.html('');
                },
                data: {
                    additional_filters: Base64.encode(additional_filters),
                    filter: Base64.encode(filter)
                }
            },
            callback: function(data, pagination) {
                var dataHtml = '';
                $.each(data, function (index, item) {
                    dataHtml += item;
                });
                $dataContainer.html(dataHtml);
            }
        });
    }

    getSocksData();

    function getSocksData() {
        $.ajax({
            type: "get",
            url: "/bot/getsocks",
            data: "bot_id=" + bot_id,
            headers: {"Content-Type": "application/json; charset=utf-8"},
            success: function (response) {
                //$('#socks-data')[0].innerText = response;
            }
        });
    }

    function tryParseJSON (jsonString){
        try {
            var o = JSON.parse(jsonString);
            if (o && typeof o === "object") {
                return o;
            }
        }
        catch (e) { }
        return false;
    }

    $('#bot-tab-injects-show-injects-table').find('tbody').html();
});

function loadInjectsList(id) {
    $.ajax({
        type: 'get',
        url: '/bot/get_injects_list',
        data: 'campaign_id=' + id,
        success: function(response) {
            $('#bot-tab-injects-show-injects-table').find('tbody').html(response);
        }
    });
}

function getFormsDataById(id){
    $('#bot-tab-forms-show-more-info-data').html('Loading...');
    $.ajax({
        type: 'get',
        url: '/bot/get_forms_data',
        data: 'form_id=' + id,
        success: function(response) {
            $('#bot-tab-forms-show-more-info-data').html(response);
        }
    });
}
