$$r(function() {

});

$("#configs_scroll").mCustomScrollbar({
    //theme: "dark",
    //autoHideScrollbar: true,
    scrollInertia: 300
});

$('#save_module').click(function(e){
    e.preventDefault();
    var arrValues= new Array();
    arrValues['module_id'] = $('#module_id').text();
    arrValues['url_x32'] = Base64.encode($('#url_x32').val());
    arrValues['url_x64'] = Base64.encode($('#url_x64').val());
    arrValues['hash_x32'] = Base64.encode($('#hash_x32').val());
    arrValues['hash_x64'] = Base64.encode($('#hash_x64').val());
    arrValues['status'] = $('#module_status').val();

    $.ajax({
        type: "post",
        url: "/modules/save_module_info",
        data: Object.assign({}, arrValues),
        success: function(res) {
            if (res == '1') {
                $.jGrowl('Module info updated.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
            } else {
                $.jGrowl('Module info not updated.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }
        }
    });
});

$('#modules_names').on("change", function(e) {
    var newModuleID = $(this).val();
    $.ajax({
        type: "get",
        url: "/modules/get_module",
        data: "module_id="+newModuleID,
        success: function(res) {
            if (res) {
                var jsonRes = $.parseJSON(res);
                $('#module_name').text(jsonRes['name']);
                $('#module_id').text(jsonRes['id']);
                $('#url_x32').val(jsonRes['url_x32']);
                $('#url_x64').val(jsonRes['url_x64']);
                $('#hash_x32').val(jsonRes['hash_x32']);
                $('#hash_x64').val(jsonRes['hash_x64']);
                $('#module_status').val(jsonRes['status']).trigger('change');
                updateConfigsForModule(newModuleID);
            }
            else
                $.jGrowl('Module information was not received.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 1000 });
        }
    });

});

$('#knock_timeout').on("change", function(e) {
    var settingVal = $(this).val();
    var settingName = $(this).attr('id');
    console.log(settingName + ' - ' + settingVal);
    updSetting(settingName, settingVal);
});

$('#new_config_save').click(function(e){
    e.preventDefault();
    var arrValues= new Array();
    arrValues['module_id'] = $('#module_id').text();
    arrValues['config_name'] = Base64.encode($('#new_config_name').val());
    arrValues['config_body'] = Base64.encode($('#new_config_field').val());
    console.log(Object.assign({}, arrValues));
    $.ajax({
        type: "post",
        url: "/modules/save_new_config",
        data: Object.assign({}, arrValues),
        success: function(res) {
            $('#new_config_modal').modal('hide');
            $('#new_config_name').val('');
            $('#new_config_field').val('');
            if (res == '1') {
                $.jGrowl('Config have been created.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                updateConfigsForModule($('#module_id').text());
            } else {
                $.jGrowl('Config have not been created.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }
        }
    });
});

$('#editable_config_save').click(function(e){
    e.preventDefault();
    var arrValues= new Array();
    arrValues['config_id'] = $('#editable_config_id').val();
    arrValues['config_name'] = Base64.encode($('#editable_config_name').val());
    arrValues['config_body'] = Base64.encode($('#editable_config_field').val());
    console.log(Object.assign({}, arrValues));
    $.ajax({
        type: "post",
        url: "/modules/save_config",
        data: Object.assign({}, arrValues),
        success: function(res) {
            $('#editable_config_modal').modal('hide');
            $('#editable_config_id').val('');
            $('#editable_config_name').val('');
            $('#editable_config_field').val('');
            if (res == '1') {
                $.jGrowl('Config have been saved.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                updateConfigsForModule($('#module_id').text());
            } else {
                $.jGrowl('Config have not been saved.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }
        }
    });
});

// in the next
function updateConfigsForModule(module_id) {
    //var module_id = $('#module_id').text();
    var resp_configs;
    $.ajax({
        type: "get",
        dataType: 'json',
        url: "/modules/get_configs_for_module",
        data: "module_id="+module_id,
        success: function(res) {
            $('#configs_scroll').mCustomScrollbar('destroy');
            $('#configs_scroll').text('');
            resp_configs = res;
            if (Array.isArray(resp_configs)) {
                if (resp_configs.length > 0) {
                    resp_configs.forEach(function (item) {
                        $('#configs_scroll').append(
                            '<div id="config_'+item.id+'" class="input-group">' +
                                '<input id="config_name_'+item.id+'" type="text" class="form-control" value="'+item.name+'" disabled>' +
                                '<div class="input-group-btn">' +
                                    '<button onclick="editCfg(this)" class="btn btn-default open_edit_config" data-toggle="modal" data-target="#editable_config_modal" type="button" style="height: 34px;"><i class="fa fa-cogs"></i></button>' +
                                    '<button onclick="deleteCfg(this)" class="btn btn-default delete_config" type="button" style="height: 34px;"><i class="fa fa-trash-o"></i></button>' +
                                '</div>' +
                            '</div>'
                        );
                    });
                    $("#configs_scroll").mCustomScrollbar({
                        scrollInertia: 300
                    });
                } else {
                    $('#configs_scroll').text('Configs didn\'t find.');
                }
            }
        }
    });
}

function editCfg(el) {
    var config_id = $(el).parent().parent().attr("id").split('_')[1];
    var config_name = $(el).parent().parent().find("input").val();
    $('#editable_config_id').val(config_id);
    $('#editable_config_name').val(config_name);
    $.ajax({
        type: "get",
        url: "/modules/get_config_info",
        data: "config_id="+config_id,
        success: function(res) {
            $('#editable_config_field').val(res);
        }
    });
}

function deleteCfg(el) {
    var config_element = $(el).parent().parent();
    var config_id = $(el).parent().parent().attr("id").split('_')[1];
    console.log(config_id);
    $.ajax({
        type: "post",
        url: "/modules/delete_config",
        data: "config_id="+config_id,
        success: function(res) {
            if (res === '1') {
                config_element.remove();
                $.jGrowl('Config have been deleted.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
            } else {
                $.jGrowl('Config have not been deleted.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
            }

        }
    });
}