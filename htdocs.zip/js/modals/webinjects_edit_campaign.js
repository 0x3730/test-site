var currentCampaignEditGroupOrInjectsTab = 1;
$(document).ready(function() {
    $('[data-type-group-or-inject-edit]').on('click', function (el) {
        var $element = $(this);
        currentCampaignEditGroupOrInjectsTab = $element.data('type-group-or-inject-edit');
    });

    $('#form-web-injects-campaign-edit').on('submit', function(el) {
        var data = [];
        data['name'] = $('#edit-webinject-campaign-name').val();
        data['description'] = $('#edit-webinject-campaign-description').val();
        data['botids'] = $('#edit-webinject-campaign-botids').val();
        data['countries'] = $('#edit-webinject-campaign-countries').val();
        data['id'] = $('#form-web-injects-campaign-edit').data('campaign-id');

        var $injects = $('[data-edit-campaign-webinject-checkbox]');

        if (currentCampaignEditGroupOrInjectsTab === 1) {
            data['group_id'] = $('#edit-webinject-campaign-group').val();
        } else {
            var injects = [];
            $injects.each(function(ind, element) {
                if (element.checked === true) {
                    injects.push($(element).data('edit-campaign-webinject-checkbox'));
                }
            });
            data['injects'] = JSON.stringify(injects);
        }

        if ((data['injects'] && data['injects'].length > 0) || (data['group_id'] && data['group_id'].length > 0)) {
            $.ajax({
                type: "post",
                url: "/webinjects_main/update_campaign_info",
                data: Object.assign({}, data),
                success: function (res) {
                    if (res === '1') {
                        clearCampaignEditForm($injects);
                        dataTableWebInjectsCampaigns.draw();
                        $.jGrowl('Campaign was update successfully.', {
                            sticky: false,
                            theme: 'growl-success',
                            header: 'Success!',
                            life: 3000
                        });
                    } else {
                        $.jGrowl('Campaign was not update.', {
                            sticky: false,
                            theme: 'growl-error',
                            header: 'Error!',
                            life: 3000
                        });
                    }
                }
            });
        } else {
            $.jGrowl('Choose the group or injects.', {
                sticky: false,
                theme: 'growl-error',
                header: 'Error!',
                life: 3000
            });
        }
        el.preventDefault();
    });
});

function clearCampaignEditForm($injects) {
    $('#web-injects-edit-campaign').modal('hide');
    $('#edit-webinject-campaign-name').val('');
    $('#edit-webinject-campaign-description').val('');
    $('#edit-webinject-campaign-botids').val('');
    $('#edit-webinject-campaign-countries').val('');
    $injects.each(function (ind, element) {
        $(element).parent().removeClass('checked');
    });
}

function createInjectsListWithSelectedInjects(injects) {
    var injectsOptions = '';
    var isInjectSelected = false;
    injects.forEach(function(inject) {
        if (!isInjectSelected && inject['checked'] === true) {
            isInjectSelected = true;
        }
        injectsOptions += '<div class="checkbox">' +
            '<label>' +
            '<input type="checkbox" data-edit-campaign-webinject-checkbox="' + inject['id'] + '"' + (inject['checked'] === true ? 'checked' : '') + '>' + inject['name'] +
            '</label>' +
            '</div>';
    });
    if (isInjectSelected) {
        editCampaignInjectsTabSelect();
    }
    $('[data-campaign-edit-injects-list]').html(injectsOptions);
    $('[data-edit-campaign-webinject-checkbox]').uniform();
}

function createGroupsListWithSelectedGroup(groups) {
    var groupsListHtml = '<select class="form-control" id="edit-webinject-campaign-group">';
    var isGroupSelected = false;
    groups.forEach(function(group){
        groupsListHtml += '<option value="' + group['id'] + '"' + (group['selected'] === true ? 'selected' : '') + '>' + group['name'] + '</option>';
        if (!isGroupSelected && group['selected'] === true) {
            isGroupSelected = true;
        }
    });
    groupsListHtml += '</select>';
    if (isGroupSelected) {
        editCampaignGroupTabSelect();
    }
    $('[data-campaign-edit-groups-list]').html(groupsListHtml);
}

function editCampaignGroupTabSelect()
{
    currentCampaignEditGroupOrInjectsTab = 1;
    $('[data-type-group-or-inject-edit="1"]').tab('show');
    /*$('[data-type-group-or-inject-edit="2"]').parent().removeClass('active');
    $('[data-type-group-or-inject-edit="1"]').click();
    $('[data-type-group-or-inject-edit="1"]').parent().addClass('active');*/
}

function editCampaignInjectsTabSelect()
{
    currentCampaignEditGroupOrInjectsTab = 2;
    $('[data-type-group-or-inject-edit="2"]').tab('show');
    /*$('[data-type-group-or-inject-edit="1"]').parent().removeClass('active');
    $('[data-type-group-or-inject-edit="2"]').parent().addClass('active');
    $('[data-type-group-or-inject-edit="2"]').click();*/
}
