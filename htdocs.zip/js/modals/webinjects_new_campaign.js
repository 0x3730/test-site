var currentGroupOrInjectsTab = 1;
$(document).ready(function() {
    $('[data-type-group-or-inject]').on('click', function (el) {
        var $element = $(this);
        currentGroupOrInjectsTab = $element.data('type-group-or-inject');
    });

    $('#form-web-injects-campaign-new').on('submit', function(el) {
        var data = [];
        data['name'] = $('#new-webinject-campaign-name').val();
        data['description'] = $('#new-webinject-campaign-description').val();
        data['botids'] = $('#new-webinject-campaign-botids').val();
        data['countries'] = $('#new-webinject-campaign-countries').val();

        var $injects = $('#web-injects-new-campaign').find('[data-webinject-checkbox]');

        if (currentGroupOrInjectsTab === 1) {
            data['group_id'] = $('#new-webinject-campaign-group').val();
        } else {
            var injects = [];
            $injects.each(function(ind, element) {
                if (element.checked === true) {
                    injects.push($(element).data('webinject-checkbox'));
                }
            });
            data['injects'] = JSON.stringify(injects);
        }

        if ((data['injects'] && data['injects'].length > 0) || (data['group_id'] && data['group_id'].length > 0)) {
            $.ajax({
                type: "post",
                url: "/webinjects_main/create_campaign",
                data: Object.assign({}, data),
                success: function (res) {
                    if (res === '1') {
                        clearCampaignForm($injects);
                        dataTableWebInjectsCampaigns.draw();
                        $.jGrowl('Campaign was create successfully.', {
                            sticky: false,
                            theme: 'growl-success',
                            header: 'Success!',
                            life: 3000
                        });
                    } else {
                        $.jGrowl('Campaign was not create.', {
                            sticky: false,
                            theme: 'growl-error',
                            header: 'Error!',
                            life: 3000
                        });
                    }
                }
            });
        } else {
            $.jGrowl('Choose the group or injects.', {
                sticky: false,
                theme: 'growl-error',
                header: 'Error!',
                life: 3000
            });
        }
        el.preventDefault();
    });
});

function clearCampaignForm($injects) {
    $('#web-injects-new-campaign').modal('hide');
    $('#new-webinject-campaign-name').val('');
    $('#new-webinject-campaign-description').val('');
    $('#new-webinject-campaign-botids').val('');
    $('#new-webinject-campaign-countries').val('');
    $injects.each(function (ind, element) {
        $(element).parent().removeClass('checked');
    });
}