$(document).ready(function(){
    $('#form-web-injects-new').on('submit', function(el) {
        var data = [];
        data['name'] = $('#new-webinject-name').val();
        data['description'] = $('#new-webinject-description').val();
        data['source'] = $('#new-webinject-source').val();
        console.log(data);
        $.ajax({
            type: "post",
            url: "/webinjects_main/create_webinject",
            data: Object.assign({}, data),
            success: function(res) {
                if (res == '1') {
                    $('#web-injects-new-webinject').modal('hide');
                    $('#new-webinject-name').val('');
                    $('#new-webinject-description').val('');
                    $('#new-webinject-source').val('');
                    dataTableWebInjects.draw();
                    loadInjectsList();
                    $.jGrowl('Inject was created successfully.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
                } else {
                    $.jGrowl('Inject was not created.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
                }
            }
        });
        el.preventDefault();
    });
});