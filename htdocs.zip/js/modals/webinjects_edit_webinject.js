$(document).ready(function(){
   $('#edit-webinject-update').on('click', function(el){
        var data = [];
        data['id'] = $('#edit-webinject-id').val();
        data['name'] = $('#edit-webinject-name').val();
        data['description'] = $('#edit-webinject-description').val();
        data['source'] = $('#edit-webinject-source').val();
       $.ajax({
           type: "post",
           url: "/webinjects_main/update_inject",
           data: Object.assign({}, data),
           success: function(res) {
               if (res == '1') {
                   $('#web-injects-edit-webinject').modal('hide');
                   $('#form-web-injects-edit').trigger('reset');
                   loadInjectsList();
                   dataTableWebInjects.draw();
                   $.jGrowl('Inject was update successfully.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
               } else {
                   $.jGrowl('Inject was not update.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
               }
           }
       });
       el.preventDefault();
   });

   $('#edit-webinject-delete').on('click', function() {
       var data = {
           inject_id: $('#edit-webinject-id').val()
       };
       $.ajax({
           type: "post",
           url: "/webinjects_main/delete_inject",
           data: data,
           success: function(res) {
               if (res == '1') {
                   $('#web-injects-edit-webinject').modal('hide');
                   $('#form-web-injects-edit').trigger('reset');
                   loadInjectsList();
                   dataTableWebInjects.draw();
                   dataTableWebInjectsGroups.draw();
                   dataTableWebInjectsCampaigns.draw();
                   $.jGrowl('Inject was delete successfully.', { sticky: false, theme: 'growl-success', header: 'Success!', life: 3000 });
               } else {
                   $.jGrowl('Inject was not delete.', { sticky: false, theme: 'growl-error', header: 'Error!', life: 3000 });
               }
           }
       });
   });
});
/*
function getInjectDataById(id) {
    $.ajax({
        type: "get",
        url: "/webinjects_main/get_inject_info",
        data: "id=" + id,
        success: function(res) {
            var inject = JSON.parse(res);
            $('#edit-webinject-name').val(inject['name']);
            $('#edit-webinject-description').val(inject['description']);
            $('#edit-webinject-source').val(inject['source']);
        }
    });
}*/
