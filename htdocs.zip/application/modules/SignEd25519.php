<?php

require_once 'vendor/autoload.php';

use Elliptic\EdDSA;

class SignEd25519
{
    public static function sign($message)
    {
        return SignEd25519::callPythonEd25519(ED25519_SECRET, $message);
    }

    private static function callPythonEd25519($seed, $data)
    {
        $paramsObj = array();
        $paramsObj['seed'] = base64_encode($seed);
        $paramsObj['data'] = base64_encode($data);

        unset($data);

        $params = json_encode($paramsObj);

        unset($paramsObj);

        $cmd = 'python ' . __DIR__ . '/python_scripts/ed25519sign.py';

        $descriptorspec = array(
            0 => array("pipe", "r"),
            1 => array("pipe", "w")
        );

        $process = proc_open($cmd, $descriptorspec, $pipes);

        if (is_resource($process))
        {
            fwrite($pipes[0], $params);
            fclose($pipes[0]);

            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);

            proc_close($process);

            if ($output === '0')
            {
                return null;
            }

            return base64_decode($output);
        }

        return null;
    }

    // Old function. It had problems with stable working
    private static function phpLibEd25519($seed, $message)
    {
        $ec = new EdDSA('ed25519');
        $key = $ec->keyFromSecret($seed);
        return $key->sign(bin2hex($message))->toBin();
    }

}