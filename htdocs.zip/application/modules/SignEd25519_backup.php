<?php

require_once 'vendor/autoload.php';

use Elliptic\EdDSA;

class SignEd25519
{
    public static function sign($message)
    {
        $ec = new EdDSA('ed25519');
        $key = $ec->keyFromSecret(ED25519_SECRET);
        return $key->sign(bin2hex($message))->toBin();
    }
}