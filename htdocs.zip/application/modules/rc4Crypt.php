<?php

class rc4Crypt {
    private $key;

    public function __construct($key) {
        $this->key = $key;
    }

    public function rc4_encrypt($plain_text) {
        //return base64_encode($this->rc4($plain_text));
        return $this->rc4($plain_text);
    }

    public function rc4_decrypt($enc_text) {
        //return $this->rc4(base64_decode($enc_text));
        return $this->rc4($enc_text);
    }

    private function rc4($data)
    {
        $key[] ="";
        $box[] ="";
        $cipher = "";
        $pwd_length = strlen($this->key);
        $data_length = strlen($data);
        for ($i = 0; $i < 256; $i++)
        {
            $key[$i] = ord($this->key[$i % $pwd_length]);
            $box[$i] = $i;
        }
        for ($j = $i = 0; $i < 256; $i++)
        {
            $j = ($j + $box[$i] + $key[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        for ($a = $j = $i = 0; $i < $data_length; $i++)
        {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $k = $box[(($box[$a] + $box[$j]) % 256)];
            $cipher .= chr(ord($data[$i]) ^ $k);
        }
        return $cipher;
    }

    /*private function rc4_init_s() {
        // инициализация вспомогательного массива $k
        $k = unpack('C*', $this->key);
        array_unshift($k, array_shift($k));
        $n = sizeof($k);
        $i = $n;
        for ($i = $n; $i < 0x100; $i++) $k[$i] = $k[$i % $n];
        for ($i--; $i >= 0x100; $i--) $k[$i & 0xff] ^= $k[$i];
        $s = array();
        for ($i = 0; $i < 0x100; $i++) $s[$i] = $i;
        $j = 0;
        for ($i = 0; $i < 0x100; $i++) {
            $j = ($j + $s[$i] + $k[$i]) & 0xff;
            $tmp = $s[$i];
            $s[$i] = $s[$j];
            $s[$j] = $tmp;
        }
        return $s;
    }

    private function rc4_crypt($text1) {
        $s = $this->rc4_init_s();
        $n = strlen($text1);
        $text2 = '';
        $i = $j = 0;
        for ($k = 0; $k < $n; $k++) {
            $i = ($i + 1) & 0xff;
            $j = ($j + $s[$i]) & 0xff;
            $tmp = $s[$i];
            $s[$i] = $s[$j];
            $s[$j] = $tmp;
            $text2 .= $text1{$k} ^ chr($s[$i] + $s[$j]);
        }
        return $text2;
    }*/
}