# !/usr/local/bin/python
import sys
import json
import traceback
from base64 import b64decode, b64encode
from salsa20 import XSalsa20_xor

try:
    paramsJson = sys.stdin.read()
    params = json.loads(paramsJson)
    ciphertext = XSalsa20_xor(b64decode(params['buffer']), b64decode(params['nonce']), b64decode(params['key']))
    print(b64encode(ciphertext))
except Exception:
    traceback.print_exc()