<?php

class GroupsBots
{
    static private $pdo;
    static private $dbh;

    static public function UpdateGroups()
    {
        $check_groups = GroupsBots::getDB()->queryRows('SELECT * FROM `group_bots`');
        if (!empty($check_groups)) {
            foreach ($check_groups as $check_group => $value) {
                echo $value['name_group'];
            }
        }
    }

    static private function getDB()
    {
        if (isset(GroupsBots::$dbh) && !empty(GroupsBots::$dbh)) {
            return GroupsBots::$dbh;
        } else {
            GroupsBots::$pdo = new PDO(DATABASE_SOURCE_NAME, DATABASE_USER_NAME, DATABASE_USER_PASSWORD);
            GroupsBots::$dbh = new Db(GroupsBots::$pdo);
            return GroupsBots::$dbh;
        }
    }
}

GroupsBots::UpdateGroups();

?>