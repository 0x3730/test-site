<?php

class Authorization
{

    static private $pdo;
    static private $dbh;

    static function checkPathForLogin($path)
    {

    }

    static function logOut()
    {
        unset($_SESSION['authorization_data']);
        session_destroy();
        Route::ErrorPage404();
    }

    static function checkLogin()
    {
        if (isset($_SESSION['authorization_data']) && !empty($_SESSION['authorization_data'])) {
            $session_check = explode(':', $_SESSION['authorization_data']);
            $user_id = $session_check[0];
            $user_username = $session_check[1];

            $check_valid_user = Authorization::getDB()->queryRow('SELECT * FROM `users` WHERE id=:id', array(':id' => $user_id));
            if (!empty($check_valid_user) && $check_valid_user['username'] == $user_username) {
                return true;
            } else {
                Route::ErrorPage404();
            }
        }
        Route::ErrorPage404();
    }

    static function doLogin($username, $password)
    {
        $password_hashed = hash("sha256", $password);
        $user = Authorization::getDB()->queryRow('SELECT `id`,`username`,`password`,`privileges`, `list_access` FROM users WHERE username=:username', array(':username' => $username));
        if ($user != false && isset($user['id'])) {
            if ($password_hashed == $user['password']) {
                $last_online = Authorization::getDB()->update('users', array('last_online' => date('Y-m-d H:i:s')), 'id=:id', array(':id' => $user['id']));
                $_SESSION['authorization_data'] = $user['id'] . ':' . $user['username'];
                $privilege_id = $user['privileges'];

                $check_privilege_user = Authorization::getDB()->queryRow('SELECT * FROM `roles_list` WHERE id=:id', array(':id' => $privilege_id));

                $_SESSION['name_role'] = $check_privilege_user['name_role'];
                $_SESSION['list_access'] = $user['list_access'];
                return true;
            }
        }
        return false;
    }

    static private function getDB()
    {
        if (isset(Authorization::$dbh) && !empty(Authorization::$dbh))
            return Authorization::$dbh;
        else {
            Authorization::$pdo = new PDO(DATABASE_SOURCE_NAME, DATABASE_USER_NAME, DATABASE_USER_PASSWORD);
            Authorization::$dbh = new Db(Authorization::$pdo);
            return Authorization::$dbh;
        }
    }
}

?>