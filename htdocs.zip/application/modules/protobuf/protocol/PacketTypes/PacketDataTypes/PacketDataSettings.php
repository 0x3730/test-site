<?php

class PacketDataSettings extends PacketData {

    protected function parsePacket()
    {

    }

    protected function generatePacket()
    {

    }
}