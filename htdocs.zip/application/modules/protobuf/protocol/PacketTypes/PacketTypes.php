<?php

abstract class PacketTypes
{
    const PacketSystemInfo = 1;
    const PacketKnock = 2;
    const PacketTaskExecInfo = 3;
    const PacketReport = 4;
    const PacketModule = 5;
    const PacketModuleContext = 6;
    const PacketData = 7;
}

abstract class PacketReportTypes
{
    const BrowserGrabber = 1;
    const HttpGrabber = 2;
    const ScreenShot = 3;
    const Software = 4;

    // Для антивирусов и фаерволов одна структура пакета
    const Antiviruses = 5;
    const Firewalls = 6;

    const NetView = 7;
}