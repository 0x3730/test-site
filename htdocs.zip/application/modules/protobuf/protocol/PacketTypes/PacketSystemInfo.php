<?php
require_once 'application/modules/protobuf/protocol/Packet.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
class PacketSystemInfo extends Packet {
    public function __construct($data)
    {
        $this->protoPacket = new system_data();
        if (!empty($data))
            $this->protoPacket->ParseFromString($data);
    }
}