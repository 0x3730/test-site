<?php
require_once 'application/modules/protobuf/protocol/Packet.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';
class PacketModuleContext extends Packet {
    public function __construct()
    {
        $this->protoPacket = new moduleContext();
    }

    public function setContext($ImageX64, $ImageX64Size, $ImageX32, $ImageX32Size) {
        if (!empty($ImageX64)) $this->protoPacket->set_ImageX64($ImageX64);
        $this->protoPacket->set_ImageX64Size($ImageX64Size != null ? $ImageX64Size : 0);
        if (!empty($ImageX32)) $this->protoPacket->set_ImageX32($ImageX32);
        $this->protoPacket->set_ImageX32size($ImageX32Size != null ? $ImageX32Size : 0);
    }
}