<?php

class Packet {
    protected $protoPacket;

    public function parsePacket()
    {
        return $this->protoPacket->getAssocArray();
    }
    public function generatePacket()
    {
        return $this->protoPacket->SerializeToString();
    }
}