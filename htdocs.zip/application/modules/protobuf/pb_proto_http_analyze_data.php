<?php
class HttpAnalyzeData extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
    $this->fields["5"] = "PBString";
    $this->values["5"] = "";
  }
  function url()
  {
    return $this->_get_value("1");
  }
  function set_url($value)
  {
    return $this->_set_value("1", $value);
  }
  function userAgent()
  {
    return $this->_get_value("2");
  }
  function set_userAgent($value)
  {
    return $this->_set_value("2", $value);
  }
  function contentType()
  {
    return $this->_get_value("3");
  }
  function set_contentType($value)
  {
    return $this->_set_value("3", $value);
  }
  function acceptEncoding()
  {
    return $this->_get_value("4");
  }
  function set_acceptEncoding($value)
  {
    return $this->_set_value("4", $value);
  }
  function postRequestData()
  {
    return $this->_get_value("5");
  }
  function set_postRequestData($value)
  {
    return $this->_set_value("5", $value);
  }
}
?>