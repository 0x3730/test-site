<?php

class Model_Profile extends Model
{
    public function getProfile()
    {
        //$session_filter = explode(':', $_SESSION['authorization_data']);
        $user_id = 1;

        $profile_info = $this->getDB()->queryRow('SELECT * FROM `users` WHERE `id`=:id', array(':id' => $user_id));

        if (!empty($profile_info)) {
            echo '<input type="hidden" id="edit_profile_id" value="' . $profile_info['id'] . '">';
            echo 'Login: <span class="bot-info-value"><input type="text" id="edit_user_login" placeholder="Login" disabled class="input-group form-control" value="' . $profile_info['username'] . '"></span><br>';
            echo 'Password: <span class="bot-info-value"><input type="password" id="edit_profile_old_password"  placeholder="Old Password" class="input-group form-control"></span><br>';
            echo 'Password: <span class="bot-info-value"><input type="password" id="edit_profile_password"  placeholder="Password" class="input-group form-control"></span><br>';
        } else {
            return NULL;
        }
    }

    public function editProfile()
    {
        if ($this->checkInfoProfileEditCorrect()) {
            $user_id = $this->request_data['user_id'];

            $edit_user_profile_password = $this->request_data['user_profile_password'];
            $edit_user_profile_old_password = $this->request_data['user_profile_old_password'];

            $hash_new_password = hash('sha256', $edit_user_profile_password);
            $hash_old_password = hash('sha256', $edit_user_profile_old_password);

            $profile_user = $this->getDB()->queryRow('SELECT * FROM `users` WHERE `id`=:id', array(':id' => $user_id));

            if ($hash_old_password === $profile_user['password']) {
                $update_profile_user = $this->getDB()->update('users', array('password' => $hash_new_password), 'id=:id', array(':id' => $user_id));
                if (!empty($update_profile_user)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private function checkInfoProfileEditCorrect()
    {
        if (!empty($this->request_data['user_profile_password']) &&
            (!empty($this->request_data['user_profile_old_password']))) {
            return true;
        } else {
            return false;
        }
    }
}

?>