<?php

class Model_Login extends Model
{
    public function get_data() { }

    public function tryToAuth() {
        if(!empty($this->request_data['username'] && !empty($this->request_data['password'])) &&
            Authorization::doLogin($this->request_data['username'], $this->request_data['password']))
        {
            return true;
        }
        return false;
    }
}