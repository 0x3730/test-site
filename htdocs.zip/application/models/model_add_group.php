<?php

class Model_Add_Group extends Model
{
    public function CreateGroup()
    {
        if ($this->NameGroupIsCorrect()) {
            $name_group = $this->request_data['name_group'];
            $new_list_software = $this->request_data['list_install_software'];
            $new_list_url_form_grabber = $this->request_data['list_url_form_grabber'];
            $new_list_os = $this->request_data['list_os'];
            $new_list_netview_domain = $this->request_data['list_netview_domain'];

            $add_new_group = $this->getDB()->insert('group_bots', array('name_group' => $name_group, 'list_install_app' => "$new_list_software", 'list_url_form_grabber' => $new_list_url_form_grabber, 'list_os' => $new_list_os, 'list_domain_netview' => $new_list_netview_domain));
            if ($add_new_group > 0) {
                return true;
            } else {
                return false;
            }
        }
        return false;

    }

    private function NameGroupIsCorrect()
    {
        if (!empty($this->request_data['name_group'])) {
            return true;
        } else {
            return false;
        }
    }
}

?>