<?php

class Model_Users_CP extends Model
{
    public function getUsers()
    {
        $users_info = $this->getDB()->queryRows('SELECT * FROM `users`');
        if (!empty($users_info)) {
            foreach ($users_info as $user_list => $value) {
                echo '<tr>';
                echo '<td>' . $value['id'] . '</td>';
                echo '<td>' . $value['username'] . '</td>';
                echo '<td>' . $value['last_online'] . '</td>';
                echo '<td><a style="margin-left: 9%;" href="/user?user_id=' . $value['id'] . '"><i style="cursor: pointer;" class="fa fa-edit fa-lg text-success"></i></a></td>';
                echo '<td><i style="margin-left: 9%; cursor: pointer;" class="fa fa-trash-o fa-lg text-danger" onclick="deleteUser(' . $value['id'] . ')"></i></td>';
                echo '</tr>';
            }
        }
        return NULL;
    }

    public function getRoles()
    {
        $roles_info = $this->getDB()->queryRows('SELECT * FROM `roles_list`');
        if (!empty($roles_info)) {
            foreach ($roles_info as $roles_list => $value) {
                echo '<tr>';
                echo '<td>' . $value['id'] . '</td>';
                echo '<td>' . $value['name_role'] . '</td>';
                #echo '<td>' . $value['list_access'] . '</td>';
                echo '<td><a style="margin-left: 6%;" href="/role?role_id=' . $value['id'] . '"><i style="cursor: pointer;" class="fa fa-edit fa-lg text-success"></i></a></td>';
                echo '<td><i style="margin-left: 6%; cursor: pointer;" class="fa fa-trash-o fa-lg text-danger" onclick="deleteRole(' . $value['id'] . ')"></i></td>';
                echo '</tr>';
            }
        }
    }

    public function getRolesView()
    {
        $roles_list = $this->getDB()->queryRows('SELECT * FROM `roles_list`');
        if (!empty($roles_list)) {
            foreach ($roles_list as $role => $value) {
                echo '<option id="preset_access" value="' . $value['id'] . '">' . $value['name_role'] . '</option>';
            }
        }
    }

    public function CreateUser()
    {
        if ($this->userInfoIsCorrect()) {
            $new_user_login = $this->request_data['new_user_login'];
            $new_user_password = $this->request_data['new_user_password'];
            $new_user_privilege = $this->request_data['new_user_privilege'];
            $new_user_hash_password = hash("sha256", $new_user_password);
            #$privilege_id = '2';

            $privilege_new_user = $this->getDB()->queryRow('SELECT * FROM `roles_list` WHERE id=:id', array(':id' => $new_user_privilege));
            $add_new_user = $this->getDB()->insert('users', array('username' => "$new_user_login", 'password' => "$new_user_hash_password", "privileges" => $new_user_privilege, "list_access" => $privilege_new_user['list_access']));
            if ($add_new_user > 0) {
                return true;
            }
            return false;
        }
        return false;
    }

    public function CreateRole()
    {
        if ($this->roleInfoIsCorrect()) {
            $new_role_name = $this->request_data['new_role_name'];

            if (empty($this->request_data['access_all'])) {
                $access_all = "DISALLOW_ALL";
            } else {
                $access_all = $this->request_data['access_all'];
            }

            if (empty($this->request_data['access_users_cp'])) {
                $access_users_cp = "DISALLOW_USERS_CP";
            } else {
                $access_users_cp = $this->request_data['access_users_cp'];
            }

            if (empty($this->request_data['access_bots'])) {
                $access_bots = "DISALLOW_BOTS";
            } else {
                $access_bots = $this->request_data['access_bots'];
            }

            if (empty($this->request_data['access_task_cp'])) {
                $access_task_cp = "DISALLOW_TASK_CP";
            } else {
                $access_task_cp = $this->request_data['access_task_cp'];
            }

            if (empty($this->request_data['access_web_inj_cp'])) {
                $access_web_inj_cp = "DISALLOW_WEB_INJ_CP";
            } else {
                $access_web_inj_cp = $this->request_data['access_web_inj_cp'];
            }

            if (empty($this->request_data['access_grabber_settings_cp'])) {
                $access_grabber_settings_cp = "DISALLOW_GRABBER_SETTINGS_CP";
            } else {
                $access_grabber_settings_cp = $this->request_data['access_grabber_settings_cp'];
            }

            if (empty($this->request_data['access_all_report'])) {
                $access_all_report = "DISALLOW_ALL_REPORTS";
            } else {
                $access_all_report = $this->request_data['access_all_report'];
            }

            if (empty($this->request_data['access_report_stealer'])) {
                $access_report_stealer = "DISALLOW_REPORT_STEALER";
            } else {
                $access_report_stealer = $this->request_data['access_report_stealer'];
            }

            if (empty($this->request_data['access_report_socks'])) {
                $access_report_socks = "DISALLOW_REPORT_SOCKS";
            } else {
                $access_report_socks = $this->request_data['access_report_socks'];
            }

            if (empty($this->request_data['access_report_backcmd'])) {
                $access_report_backcmd = "DISALLOW_REPORT_BACKCMD";
            } else {
                $access_report_backcmd = $this->request_data['access_report_backcmd'];
            }

            if (empty($this->request_data['access_report_http_grabber'])) {
                $access_report_http_grabber = 'DISALLOW_REPORT_HTTP_GRABBER';
            } else {
                $access_report_http_grabber = $this->request_data['access_report_http_grabber'];
            }

            if (empty($this->request_data['access_report_screenshots'])) {
                $access_report_screenshots = "DISALLOW_REPORT_SCREENSHOTS";
            } else {
                $access_report_screenshots = $this->request_data['access_report_screenshots'];
            }

            $list_access = $access_all . ',' . $access_users_cp . ',' . $access_bots . ',' . $access_task_cp . ',' . $access_web_inj_cp . ',' . $access_grabber_settings_cp . ',' . $access_all_report . ',' . $access_report_stealer . ',' . $access_report_socks . ',' . $access_report_backcmd . ',' . $access_report_http_grabber . ',' . $access_report_screenshots;

            $add_new_role = $this->getDB()->insert('roles_list', array('name_role' => "$new_role_name", 'list_access' => "$list_access"));
            if ($add_new_role > 0) {
                return true;
            }
            return false;
        }
        return false;
    }

    public function deleteUser()
    {
        if (!empty($this->request_data['user_id'])) {
            $id = $this->request_data['user_id'];

            $this->getDB()->sql("DELETE FROM `users` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }

    }

    public function deleteRole()
    {
        if (!empty($this->request_data['role_id'])) {
            $id = $this->request_data['role_id'];

            $this->getDB()->sql("DELETE FROM `roles_list` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }
    }

    private function userInfoIsCorrect()
    {
        if (!empty($this->request_data['new_user_login']) &&
            (!empty($this->request_data['new_user_password']))) {
            return true;
        } else {
            return false;
        }
    }

    private function roleInfoIsCorrect()
    {
        if (!empty($this->request_data['new_role_name'])) {
            return true;
        } else {
            return false;
        }
    }

}


?>