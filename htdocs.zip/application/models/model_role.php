<?php

class Model_Role extends Model
{
    public function getRole()
    {
        $role_id = $this->request_data['role_id'];

        $role_info = $this->getDB()->queryRow("SELECT * FROM `roles_list` WHERE id=:id", array(':id' => $this->request_data['role_id']));
        $list_access = explode(',', $role_info['list_access']);

        if (!empty($role_info)) {
            echo 'ID: <span class="bot-info-value" data-botid="">' . $role_info['id'] . '</span><br>';
            echo '<input type="hidden" id="edit_role_id" value="' . $role_info['id'] . '">';
            echo 'Role Name <span class="bot-info-value"><input type="text" id="edit_role_name" placeholder="Role Name" class="input-group form-control" value="' . $role_info['name_role'] . '"></span><br>';
            # echo 'List Access: <span class="bot-info-value"><input type="text" disabled placeholder="List Access" class="input-group form-control" value="' . $role_info['list_access'] . '"></span><br>';
            foreach ($list_access as $access => $value) {
                if ($value === 'ALL') {
                    $admin = 'checked';
                } elseif ($value === 'ALLOW_USERS_CP') {
                    $admin_cp = 'checked';
                } elseif ($value === 'ALLOW_BOTS') {
                    $bots_cp = 'checked';
                } elseif ($value === 'ALLOW_TASK_CP') {
                    $task_cp = 'checked';
                } elseif ($value === 'ALLOW_WEB_INJ_CP') {
                    $web_inj_cp = 'checked';
                } elseif ($value === 'ALLOW_GRABBER_SETTINGS_CP') {
                    $grabber_settings_cp = 'checked';
                } elseif ($value === 'ALLOW_ALL_REPORTS') {
                    $report_all = 'checked';
                } elseif ($value === 'ALLOW_REPORT_STEALER') {
                    $report_stealer = 'checked';
                } elseif ($value === 'ALLOW_REPORT_SOCKS') {
                    $report_socks = 'checked';
                } elseif ($value === 'ALLOW_REPORT_BACKCMD') {
                    $report_backcmd = 'checked';
                } elseif ($value === 'ALLOW_REPORT_HTTP_GRABBER') {
                    $report_http_grabber = 'checked';
                } elseif ($value === 'ALLOW_REPORT_SCREENSHOTS') {
                    $report_screenshots = 'checked';
                } elseif ($value === 'DISALLOW_ALL') {
                    $admin = '';
                } elseif ($value === 'DISALLOW_USERS_CP') {
                    $admin_cp = '';
                } elseif ($value === 'DISALLOW_BOTS') {
                    $bots_cp = '';
                } elseif ($value === 'DISALLOW_TASK_CP') {
                    $task_cp = '';
                } elseif ($value === 'DISALLOW_WEB_INJ_CP') {
                    $web_inj_cp = '';
                } elseif ($value === 'DISALLOW_GRABBER_SETTINGS_CP') {
                    $grabber_settings_cp = '';
                } elseif ($value === 'DISALLOW_ALL_REPORTS') {
                    $report_all = '';
                } elseif ($value === 'DISALLOW_REPORT_STEALER') {
                    $report_stealer = '';
                } elseif ($value === 'DISALLOW_REPORT_SOCKS') {
                    $report_socks = '';
                } elseif ($value === 'DISALLOW_REPORT_BACKCMD') {
                    $report_backcmd = '';
                } elseif ($value === 'DISALLOW_REPORT_HTTP_GRABBER') {
                    $report_http_grabber = '';
                } elseif ($value === 'DISALLOW_REPORT_SCREENSHOTS') {
                    $report_screenshots = '';
                }
            }
            echo "<label style='margin-bottom: 2%; margin-top: 6%;'><h5>List Access</h5></label><br>";
            echo '<label>Allow All</label>
                                    <input id="access_all" type="checkbox" value="ALL" ' . $admin . '><br>
                                    <label>Allow Admin CP</label>
                                    <input id="access_users_cp" type="checkbox" value="ALLOW_USERS_CP" ' . $admin_cp . '><br>
                                    <label>Allow Bots</label>
                                    <input id="access_bots" type="checkbox" value="ALLOW_BOTS" ' . $bots_cp . '><br>
                                    <label>Allow Task</label>
                                    <input id="access_task_cp" type="checkbox" value="ALLOW_TASK_CP" ' . $task_cp . '><br>
                                    <label>Allow Web Inject</label>
                                    <input id="access_web_inj_cp" type="checkbox" value="ALLOW_WEB_INJ_CP" ' . $web_inj_cp . '><br>
                                    <label>Allow Grabber Settings</label>
                                    <input id="access_grabber_settings_cp" type="checkbox" value="ALLOW_GRABBER_SETTINGS_CP" ' . $grabber_settings_cp . '><br>
                                    <label>Allow All Reports</label>
                                    <input id="access_all_report" type="checkbox" value="ALLOW_ALL_REPORTS" ' . $report_all . '><br>
                                    <label>Allow Report Stealer</label>
                                    <input id="access_report_stealer" type="checkbox" value="ALLOW_REPORT_STEALER" ' . $report_stealer . '><br>
                                    <label>Allow Report Socks</label>
                                    <input id="access_report_socks" type="checkbox" value="ALLOW_REPORT_SOCKS" ' . $report_socks . '><br>
                                    <label>Allow Report BackCMD</label>
                                    <input id="access_report_backcmd" type="checkbox" value="ALLOW_REPORT_BACKCMD" ' . $report_backcmd . '><br>
                                    <label>Allow Report HTTP Grabber</label>
                                    <input id="access_report_http_grabber" type="checkbox" value="ALLOW_REPORT_HTTP_GRABBER" ' . $report_http_grabber . '><br>
                                    <label>Allow Report Screenshots</label>
                                    <input id="access_report_screenshots" type="checkbox" value="ALLOW_REPORT_SCREENSHOTS" ' . $report_screenshots . '>';
        }

    }

    public function deleteRole()
    {
        if (!empty($this->request_data['role_id'])) {
            $id = $this->request_data['role_id'];

            $this->getDB()->sql("DELETE FROM `roles_list` WHERE `id`=:id", array(':id' => $id));
            return true;
        } else {
            return false;
        }
    }

    public function EditRole()
    {
        if ($this->roleEditInfoCorrect()) {
            $edit_role_name = $this->request_data['edit_role_name'];
            $edit_role_id = $this->request_data['edit_role_id'];

            if (empty($this->request_data['access_all'])) {
                $access_all = "DISALLOW_ALL";
            } else {
                $access_all = $this->request_data['access_all'];
            }

            if (empty($this->request_data['access_users_cp'])) {
                $access_users_cp = "DISALLOW_USERS_CP";
            } else {
                $access_users_cp = $this->request_data['access_users_cp'];
            }

            if (empty($this->request_data['access_bots'])) {
                $access_bots = "DISALLOW_BOTS";
            } else {
                $access_bots = $this->request_data['access_bots'];
            }

            if (empty($this->request_data['access_task_cp'])) {
                $access_task_cp = "DISALLOW_TASK_CP";
            } else {
                $access_task_cp = $this->request_data['access_task_cp'];
            }

            if (empty($this->request_data['access_web_inj_cp'])) {
                $access_web_inj_cp = "DISALLOW_WEB_INJ_CP";
            } else {
                $access_web_inj_cp = $this->request_data['access_web_inj_cp'];
            }

            if (empty($this->request_data['access_grabber_settings_cp'])) {
                $access_grabber_settings_cp = "DISALLOW_GRABBER_SETTINGS_CP";
            } else {
                $access_grabber_settings_cp = $this->request_data['access_grabber_settings_cp'];
            }

            if (empty($this->request_data['access_all_report'])) {
                $access_all_report = "DISALLOW_ALL_REPORTS";
            } else {
                $access_all_report = $this->request_data['access_all_report'];
            }

            if (empty($this->request_data['access_report_stealer'])) {
                $access_report_stealer = "DISALLOW_REPORT_STEALER";
            } else {
                $access_report_stealer = $this->request_data['access_report_stealer'];
            }

            if (empty($this->request_data['access_report_socks'])) {
                $access_report_socks = "DISALLOW_REPORT_SOCKS";
            } else {
                $access_report_socks = $this->request_data['access_report_socks'];
            }

            if (empty($this->request_data['access_report_backcmd'])) {
                $access_report_backcmd = "DISALLOW_REPORT_BACKCMD";
            } else {
                $access_report_backcmd = $this->request_data['access_report_backcmd'];
            }

            if (empty($this->request_data['access_report_http_grabber'])) {
                $access_report_http_grabber = 'DISALLOW_REPORT_HTTP_GRABBER';
            } else {
                $access_report_http_grabber = $this->request_data['access_report_http_grabber'];
            }

            if (empty($this->request_data['access_report_screenshots'])) {
                $access_report_screenshots = "DISALLOW_REPORT_SCREENSHOTS";
            } else {
                $access_report_screenshots = $this->request_data['access_report_screenshots'];
            }

            $list_access = $access_all . ',' . $access_users_cp . ',' . $access_bots . ',' . $access_task_cp . ',' . $access_web_inj_cp . ',' . $access_grabber_settings_cp . ',' . $access_all_report . ',' . $access_report_stealer . ',' . $access_report_socks . ',' . $access_report_backcmd . ',' . $access_report_http_grabber . ',' . $access_report_screenshots;

            $edit_role_info = $this->getDB()->update('roles_list', array('name_role' => "$edit_role_name", 'list_access' => "$list_access"), 'id=:id', array(':id' => $edit_role_id));
            if ($edit_role_info > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    private function roleEditInfoCorrect()
    {
        if (!empty($this->request_data['edit_role_name']) && !empty($this->request_data['edit_role_id'])) {
            return true;
        } else {
            return false;
        }
    }
}

?>