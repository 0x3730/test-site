<?php

class Model_Modules extends Model
{

    public function get_data(){ }

    // modules
    public function getModules($isActive = false)
    {
        $modules = null;
        if ($isActive) {
            $modules = $this->getDB()->queryRows('SELECT id,name FROM modules WHERE status=1');
        } else {
            $modules = $this->getDB()->queryRows('SELECT id,name FROM modules');
        }
        return $modules;
    }

    public function getFirstModuleInfo()
    {
        $module_info = $this->getDB()->queryRow('SELECT * FROM modules LIMIT 1');
        return $module_info;
    }

    public function getModuleInfoForID($module_id)
    {
        $module_info = $this->getDB()->queryRow('SELECT * FROM modules WHERE id=:module_id', array(':module_id' => $module_id));
        return $module_info;
    }

    public function getModuleInfo()
    {
        if (!empty($this->request_data['module_id']))
        {
            $module_info = $this->getModuleInfoForID($this->request_data['module_id']);
            if (!empty($module_info))
                return $module_info;
        }
        return false;
    }

    public function saveModuleInfo() {
        if(!empty($this->request_data['module_id']) && !empty($this->request_data['hash_x32']) &&
            !empty($this->request_data['hash_x64']) && !empty($this->request_data['url_x32']) &&
            !empty($this->request_data['url_x64']) && in_array($this->request_data['status'], array(0,1)))
        {
            $this->getDB()->update('modules',
                array(
                    'hash_x32' => base64_decode($this->request_data['hash_x32']),
                    'hash_x64' => base64_decode($this->request_data['hash_x64']),
                    'url_x32' => base64_decode($this->request_data['url_x32']),
                    'url_x64' => base64_decode($this->request_data['url_x64']),
                    'status' => $this->request_data['status']
                ),
                'id=:module_id', array(':module_id' => $this->request_data['module_id']));
            return true;
        } else {
            return false;
        }
    }

    // configs
    public function getConfigsInformation($module_id = null) {
        if ($module_id == null) {
            if (!empty($this->request_data['module_id']))
                $module_id = $this->request_data['module_id'];
        }
        if (!empty($module_id)) {
            $configs = $this->getDB()->queryRows('SELECT * FROM modules_configs WHERE module_id = :module_id', array(':module_id' => $module_id));
            if ($configs)
                return $configs;
        }
        return array();
    }

    public function deleteConfig() {
        if (!empty($this->request_data['config_id']) && (!$this->isConfigUsed($this->request_data['config_id']))) {
            $res = $this->getDB()->delete('modules_configs', 'id = :config_id', array(':config_id' => $this->request_data['config_id']));
            if ($res)
                return true;
        }
        return false;
    }

    // если конфиг используется на данный момент, возвращает false
    public function updateConfig() {
        if (!empty($this->request_data['config_id']) && !empty($this->request_data['config_name'])) {
            if (!$this->isConfigUsed($this->request_data['config_id'])) {
                $rows = $this->getDB()->update('modules_configs', array('name' => base64_decode($this->request_data['config_name']), 'body' => base64_decode($this->request_data['config_body'])), 'id=:id', array(':id' => $this->request_data['config_id']));
                if (!empty($rows))
                    return true;
            }
        }
        return false;
    }

    public function getConfigData()
    {
        if (!empty($this->request_data['config_id']))
        {
            $res = $this->getDB()->queryValue('SELECT body FROM modules_configs WHERE id = :config_id', array(':config_id' => $this->request_data['config_id']));
            return $res;
        }
    }

    // add config body to function!!! (file or db)
    // files/configs/{module_id}/{base64_encode(module_name)}
    // при удалении модуля, удалять конфиги!
    public function addConfig()
    {
        if (!empty($this->request_data['module_id']) && !empty($this->request_data['config_name']) && !empty($this->request_data['config_body']))
            if (!$this->isConfigExist($this->request_data['module_id'], base64_decode($this->request_data['config_name'])))
            {
                $cfg_id = $this->getDB()->insert('modules_configs',
                    array('module_id' => $this->request_data['module_id'], 'name' => base64_decode($this->request_data['config_name']), 'body' => base64_decode($this->request_data['config_body'])));
                if ($cfg_id > 0)
                    return true;
            }
        return false;
    }

    private function isConfigUsed($cfg_id)
    {
        $count = $this->getDB()->queryValue('SELECT COUNT(*) FROM modules_tasks WHERE config_id = :config_id',
            array(':config_id' => $cfg_id));
        if ($count > 0)
            return true;
        else
            return false;
    }

    private function isConfigExist($module_id, $config_name)
    {
        $count = $this->getDB()->queryValue('SELECT COUNT(*) FROM modules_configs WHERE module_id = :module_id AND name = :name',
            array(':module_id' => $module_id, ':name' => $config_name));
        if ($count > 0)
            return true;
        else
            return false;
    }

}