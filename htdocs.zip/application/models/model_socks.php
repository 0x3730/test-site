<?php

class Model_Socks extends Model
{

    public function get_data()
    {

    }

    public function getSocks()
    {
        // подтягиваем воркер для работы с данными из браузеров
        include 'application/models/accessory_models/BrowserDataWorker.php';
        $browserWorker = new BrowserDataWorker();
        return $browserWorker->sortBackSocks($this->request_data);
    }
}