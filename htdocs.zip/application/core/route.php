<?php
class Route
{
    public static function start()
    {
        // Generate unique request identity
        $_SERVER['UNIQUE_REQUEST_ID'] = uniqid();

        // Check for request creator
        if (self::isClientRequest()) {
            try {
                self::onBotClientStrategy();
            }
            catch(Exception $ex) {
                Logger::Error('Router', 'onBotClientStrategy (exception)', $ex, null);
            }
        } else {
            self::onClientStrategy();
        }
    }

    public static function ErrorPage404()
    {
        $host = 'http://'.$_SERVER['HTTP_HOST'].'/';
        if (!empty(PANEL_PATH) && PANEL_PATH !== '') {
            $host .= PANEL_PATH . '/';
        }
        header('HTTP/1.1 404 Not Found');
        header("Status: 404 Not Found");
        header('Location:'.$host.'404');
        die();
    }

    public static function StartPage()
    {
        $host = 'http://'.$_SERVER['HTTP_HOST'].'/';
        header('Location: '.$host);
    }

    private static function isClientRequest()
    {
        if (self::isProtobufBody() && $_SERVER['REQUEST_METHOD'] === 'POST') {
            return true;
        }
        return false;
    }

    // если запрос прилетел с бота
    private static function onBotClientStrategy()
    {
        /*
         * Подключить воркер, спарсить пакет и забрать название экшена в соответствии с типом пакета
        */
        require_once 'application/modules/protobuf/protocol/ProtobufProtocolWorker.php';

        $postData = file_get_contents('php://input');
        $data_decrypted_string = Crypt::decode($postData);
        unset($postData);

        $pbWorker = new ProtobufProtocolWorker();
        $receiveData = $pbWorker->parsePacket($data_decrypted_string);

        unset($data_decrypted_string, $pbWorker);

        $action = 'action_'.$receiveData['action'];
        include "application/models/model_gate.php";
        include "application/controllers/controller_gate.php";
        $controller_gate = new Controller_Gate();
        if (!empty($receiveData['data'])) {
            Logger::Trace('Router', 'onBotClientStrategy', json_encode($receiveData['data']));
            $controller_gate->setData($receiveData['data']);
        }

        if(method_exists($controller_gate, $action))
        {
            $controller_gate->$action();
        }
        else
        {
            self::ErrorPage404();
        }
    }

    // если запрос прилетел от юзера панели
    private static function onClientStrategy()
    {
		// контроллер и действие по умолчанию
        $controller_name = 'Main';
        $action_name = 'index';
        $path = '';
        $data = array();
		
        // parse request from client
        list($path, $data) = self::parseRequest();

        $routes = explode('/', $path);
        $itemIndexForTake = 1;
        if (!empty(PANEL_PATH) && PANEL_PATH !== '' && in_array(PANEL_PATH, $routes, false)) {
            $itemIndexForTake++;
        }
        // получаем имя контроллера
        if ( !empty($routes[$itemIndexForTake]) ) {
            $controller_name = $routes[$itemIndexForTake];
        }

        // получаем имя экшена
        if ( !empty($routes[$itemIndexForTake + 1]) ) {
            $action_name = $routes[$itemIndexForTake + 1];
        }

        global $CURRENT_PATH;
        $CURRENT_PATH = strtolower($controller_name);

        if ($controller_name === 'gate')
        {
            die("gate");
			self::ErrorPage404();
        }

        // TODO: can be spoofed on client! in future i will change it
        if ($controller_name === 'login') {
            if (!(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')) {
                //die("login");
				//self::ErrorPage404();
            }
        }

        /*TEST FUNCTIONAL*/
        $loginPage = DBClient::DB()->queryValue('SELECT setting_value FROM general_settings WHERE setting_name = :name', array(':name' => 'enter_page'));

        if ($controller_name === $loginPage) {
            $controller_name = 'login';
        }



        // добавляем префиксы
        $model_name = 'Model_'.$controller_name;
        $controller_name = 'Controller_'.$controller_name;
        $action_name = 'action_'.$action_name;
        /*if (!Route::functionIsExist($controller_name, $action_name)) {
            Route::ErrorPage404();
        }*/

        // цепляем файл с классом модели

        $model_file = strtolower($model_name).'.php';
        $model_path = "application/models/".$model_file;
        if(file_exists($model_path))
        {
            include "application/models/".$model_file;
        }

        // цепляем файл с классом контроллера
        $controller_file = strtolower($controller_name).'.php';
        $controller_path = "application/controllers/".$controller_file;
        
		//echo(controller_file);
		if(file_exists($controller_path))
        {
            include "application/controllers/".$controller_file;
        }
        else
        {
			die("xuy");
            //self::ErrorPage404();
        }

        // создаем контроллер
        $controller = new $controller_name;
        $action = $action_name;

        if (!empty($data)) {
            $controller->setData($data);
        }

        if(method_exists($controller, $action))
        {
            // вызываем действие контроллера
            $controller->$action();
        }
        else
        {
			die("xuy 2");
            //self::ErrorPage404();
        }
    }

    private static function parseRequest()
    {
        $tempData = array();
        $path = '';

        switch($_SERVER['REQUEST_METHOD'])
        {
            case 'POST':
                {
                    if (self::isJsonBody())
                    {
                        $postData = file_get_contents('php://input');
                        $tempData = json_decode($postData, true);
                        return array($_SERVER['REQUEST_URI'], $tempData);
                    }

                    $path = $_SERVER['REQUEST_URI'];
                    $tempData = $_POST;
                    return array($path, $tempData);
                }
            case 'GET':
                {
                    $address = explode('?', $_SERVER['REQUEST_URI']);
                    return array($address[0], $_GET);
                }
        }
        //self::ErrorPage404();
    }

    private static function functionIsExist($class_name, $method_name)
    {
        $class_methods = get_class_methods($class_name);
        foreach($class_methods as $method) {
            if ($method_name === $method)
                return true;
        }
        return false;
    }

    private static function isJsonBody()
    {
        if (!empty($_SERVER["CONTENT_TYPE"]) &&
            stristr($_SERVER["CONTENT_TYPE"], 'application/json') !== FALSE)
            return true;
        return false;
    }

    private static function isProtobufBody()
    {
        if (!empty($_SERVER["CONTENT_TYPE"]) &&
            stristr($_SERVER["CONTENT_TYPE"], 'application/protobuf') !== FALSE)
            return true;
        return false;
    }
}
?>