<?php

class View
{
    protected $css_path_array = array();
    protected $meta_array = array();
    protected $scripts_array = array();
    protected $modalWindows = array();
    protected $content;
    protected $data;

    public function __construct() {

	}

	public function generate($content_view, $data = null)
	{

		if(is_array($data)) {
			// преобразуем элементы массива в переменные
			extract($data);
		}

		include 'application/views/template_header.php';
		include 'application/views/' . $content_view;
		if (!empty($this->modalWindows)) {
		    foreach ($this->modalWindows as $modalPath) {
		        include 'application/views/modals/' . $modalPath;
            }
        }
		include 'application/views/template_footer.php';
	}

    public function onePageGenerate($content_view, $data = null) {
        include 'application/views/'.$content_view;
    }

    public function generateMeta() {

	}

    public function generateCSS() {
        $css_html = '';
        foreach($this->css_path_array as $css_path) {
            $css_html.='<link rel="stylesheet" type="text/css" href="'.$css_path.'" />';
        }
        return $css_html;
    }

    public function generateJS() {
        $js_html = '';
        foreach($this->scripts_array as $script_path) {
            $js_html.= '<script type="text/javascript" src="'.$script_path.'"></script>';
        }
        return $js_html;
    }

    public function addCSS($css = array()) {
        foreach($css as $css_style) {
            $this->css_path_array[] = $css_style;
        }
    }

    public function addJavaScripts($scripts  = array()) {
        foreach($scripts as $script) {
            $this->scripts_array[] = $script;
        }
    }

    public function addModalWindows($modalWindows = array()) {
        foreach($modalWindows as $modal_path) {
            $this->modalWindows[] = $modal_path;
        }
    }

    public function generateHead() {
        $this->generateCSS();
        $this->generateMeta();
    }

    public function generateContent() {

    }

}

?>
