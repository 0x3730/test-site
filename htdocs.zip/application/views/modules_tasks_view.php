<div class="page-title">
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Tasks List</h6></div>
            <div class="form-actions text-center">
                <div id="tasks" style="overflow:auto; position:relative;">
                    <table id="currenttasks" class="table table-condensed table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Module</th>
                            <th>Context</th>
                            <th>Flags</th>
                            <th>Config</th>
                            <th>OS</th>
                            <th>Countries</th>
                            <th>Status</th>
                            <th>Time</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $task_list = "";
                        if (!empty($tasks_arr)) {
                            foreach ($tasks_arr as $tsk) {
                                $status = $tsk['status'] == 1 ? '<span class="label label-info">Stoped!</span>' : '<span class="label label-success">Work...</span>';

                                $task_list .= '<tr id="' . $tsk['id'] . '">
                                            <td>' . $tsk['id'] . '</td>
                                            <td>' . $tsk['module_name'] . '</td>
                                            <td><textarea class="form-control" style="resize: none; min-height: 50px; width: 250px;" disabled>' . $tsk['context'] . '</textarea></td>
                                            <td>' . $tsk['flags'] . '</td>
                                            <td>' . $tsk['config_name'] . '</td>
                                            <td>' . implode(', ', json_decode($tsk['os'])) . '</td>
                                            <td>' . implode(', ', json_decode($tsk['country'])) . '</td>
                                            <td>' . $status . '</td>
                                            <td><span class="label label-primary">' . date('d/m/Y H:i', $tsk['time']) . '</span></td>
                                            <td><i data-type="delete" class="fa fa-trash-o fa-lg text-danger" aria-hidden="true"></i><br><i data-type="stop" class="fa fa-stop-circle-o fa-lg text-info" aria-hidden="true"></i><br><i data-type="start" class="fa fa-play-circle-o fa-lg text-success" aria-hidden="true"></i></td>
                                        </tr>';
                            }
                            echo $task_list;
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
                <!--<input type="submit" value="Create task" class="btn btn-primary">
                <input type="reset" value="Reset form" class="btn btn-danger">-->
            </div>
        </div>
    </div>
</div>

<div class="text-right">
    <button onclick="showCreateTaskModal()" type="button" class="btn btn-lg btn-danger">New Task</button>
</div>

<div id="form_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Task's Settings</h5>
            </div>

            <!-- Form inside modal -->
            <form role="form" action="#">
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Module</label>
                        <select data-placeholder="Choose a module..." class="select-full select2-offscreen" tabindex="-1" id="module_chosen">

                        </select>
                    </div>
                    <div class="form-group">
                        <label>Config</label>
                        <div class="input-group">
                            <select data-placeholder="Choose a configuration..." class="select-full select2-offscreen" tabindex="-1" id="config_chosen">
                            </select>
                            <span class="input-group-addon">
                                <!--<div class="checker"><span class=""><input type="checkbox" class="styled" name="input-addon-checkbox" checked="checked"></span></div>-->
                                <input id="config_is_choosing" type="checkbox">
                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Context</label>
                        <textarea id="context" rows="5" cols="5" class="form-control" style="resize: vertical; min-height: 100px;" placeholder="Enter context..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Flags</label>
                        <input id="flags" class="form-control" placeholder="Enter flags...">
                    </div>
                    <div class="form-group">
                        <label>Operation Systems</label>
                        <div class="input-group">
                            <span class="input-group-btn" for="os"><button class="btn btn-default btn-lg unselect_all"  type="button">Clear</button></span>
                            <select class="select2-container select2-container-multi select-multiple" data-placeholder="Choose OS..." multiple id="os" style="width: 100%; display: none;">
                                <?php
                                echo $tasks_settings['select_os'];
                                ?>
                            </select>
                            <span for="os" class="input-group-btn"><button class="btn btn-default btn-lg select_all"  type="button">All</button></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Countries</label>
                        <div class="input-group">
                            <span class="input-group-btn" for="countries"><button class="btn btn-default btn-lg unselect_all"  type="button">Clear</button></span>
                            <select class="select2-container select2-container-multi select-multiple" data-placeholder="Choose countries..." multiple id="countries" style="width: 100%; display: none;">
                                <?php
                                echo $tasks_settings['select_country'];
                                ?>
                            </select>
                            <span for="countries" class="input-group-btn"><button class="btn btn-default btn-lg select_all"  type="button">All</button></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Interval</label>
                        <input id="interval" class="form-control" placeholder="Enter interval...">
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="text-right">
                        <input id="create_task" type="submit" value="Create task" class="btn btn-default">
                        <!--<input type="reset" value="Reset form" class="btn btn-danger">-->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>