<div class="row">
    <?php if (!empty($softwareInfo['antiviruses'])) {?>
    <div class="col-lg-4 col-md-4 col-sm-12 ex-coder-adminki-pidor2">
        <h5>Antiviruses</h5>
        <table class="table table-condensed table-bordered">
            <tbody>
                <?php
                foreach ($softwareInfo['antiviruses'] as $antiVirus)
                {
                    echo '
                    <tr>
                        <td>'.htmlspecialchars($antiVirus['name']).'</td>
                    </tr>
                    ';
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php } ?>
    <?php if (!empty($softwareInfo['firewalls'])) {?>
    <div class="col-lg-4 col-md-4 col-sm-12 ex-coder-adminki-pidor2">
        <h5>Firewalls</h5>
        <table class="table table-condensed table-bordered">
            <tbody>
            <?php
            foreach ($softwareInfo['firewalls'] as $antiVirus)
            {
                echo '
                    <tr>
                        <td>'.htmlspecialchars($antiVirus['name']).'</td>
                    </tr>
                    ';
            }
            ?>
            </tbody>
        </table>
    </div>
    <?php } ?>
    <?php if (!empty($softwareInfo['software'])) {?>
    <div class="col-lg-4 col-md-4 col-sm-12 ex-coder-adminki-pidor2">
        <h5>Software</h5>
        <table class="table table-condensed table-bordered">
            <thead>
            <tr>
                <th>Name</th>
                <th>Vendor</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($softwareInfo['software'] as $software)
            {
                echo '
                    <tr>
                        <td>'.htmlspecialchars($software['name']).'</td>
                        <td>'.htmlspecialchars($software['vendor']).'</td>
                    </tr>
                    ';
            }
            ?>
            </tbody>
        </table>
    </div>
    <?php } ?>
</div>

