<div class="accordion panel-group" id="accordion-filters-passwords" role="tablist" aria-multiselectable="false">
    <div class="panel panel-white">
        <div class="panel-heading" role="tab" id="passwords-general-filter-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion-filters-passwords" href="#passwords-general-filter" aria-expanded="true" aria-controls="passwords-general-filter">
                    General filter
                </a>
            </h4>
        </div>
        <div id="passwords-general-filter" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="passwords-general-filter-heading">
            <div class="panel-body" style="padding: 20px;">
                <div class="input-group">
                    <input type="text" id="passwords_filter" class="form-control search-input" placeholder="Type text for filtering rows...">
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="submit" onclick="searchPasswords(false)"><i class="fa fa-search"></i></button>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-white">
        <div class="panel-heading" role="tab" id="passwords-advanced-filter-heading">
            <h4 class="panel-title">
                <a class="collapsed" data-toggle="collapse" data-parent="#accordion-filters-passwords" href="#passwords-advanced-filter" aria-expanded="false" aria-controls="passwords-advanced-filter">
                    Advanced filter
                </a>
            </h4>
        </div>
        <div id="passwords-advanced-filter" class="panel-collapse collapse" role="tabpanel" aria-labelledby="passwords-advanced-filter-heading">
            <div class="panel-body" style="padding: 20px;">
                <div class="row">
                    <div class="form-group col-lg-4 col-md-4 col-sm-12">
                        <label>Service</label>
                        <input id="passwords_filter_service" type="text" class="form-control" placeholder="Pattern (only supported '*' and '?')">
                    </div>
                    <div class="form-group col-lg-4 col-md-4 col-sm-12">
                        <label>Login</label>
                        <input id="passwords_filter_login" type="text" class="form-control" placeholder="Pattern (only supported '*' and '?')">
                    </div>
                    <div class="form-group col-lg-4 col-md-4 col-sm-12">
                        <label>Browser</label>
                        <input id="passwords_filter_browser" type="text" class="form-control" placeholder="Pattern (only supported '*' and '?')">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-lg-12 col-md-12 col-sm-12 text-right">
                        <button class="btn btn-default" onclick="searchPasswords(true)">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>

<div style="overflow: auto">
    <table class="table table-condensed table-bordered">
        <thead>
        <tr>
            <th>SERVICE</th>
            <th>LOGIN</th>
            <th>PASSWORD</th>
            <th>BROWSER</th>
        </tr>
        </thead>
        <tbody id="passwords-data-container">
        </tbody>
    </table>
</div>

<div id="passwords-data-pagination"></div>