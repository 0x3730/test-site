<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Dashboard</h6></div>

            <div class="row">
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="panel panel-white stats-widget">
                        <div class="panel-body">
                            <div class="pull-left">
                                <span class="stats-number"><?php echo $stats['bots_stats']['bots_count'] ?></span>
                                <p class="stats-info">Total Bots</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="panel panel-white stats-widget">
                        <div class="panel-body">
                            <div class="pull-left">
                                <span class="stats-number"><?php echo $stats['bots_stats']['bots_online'] ?></span>
                                <p class="stats-info">Bots Online</p>
                            </div>
<!--                            <div class="pull-right">
                                <i class="icon-arrow_downward stats-icon"></i>
                            </div>-->
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="panel panel-white stats-widget">
                        <div class="panel-body">
                            <div class="pull-left">
                                <span class="stats-number"><?php echo $stats['bots_stats']['bots_today'] ?></span>
                                <p class="stats-info">Bots Today</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="panel panel-white stats-widget">
                        <div class="panel-body">
                            <div class="pull-left">
                                <span class="stats-number"><?php echo $stats['bots_stats']['bots_dead'] ?></span>
                                <p class="stats-info">Dead Bots</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="panel panel-white stats-widget">
                        <div class="panel-body">
                            <div class="pull-left">
                                <span class="stats-number"><?php echo $stats['tasks_stats']['tasks_count'] ?></span>
                                <p class="stats-info">Total Tasks</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6">
                    <div class="panel panel-white stats-widget">
                        <div class="panel-body">
                            <div class="pull-left">
                                <span class="stats-number"><?php echo $stats['tasks_stats']['active_tasks'] ?></span>
                                <p class="stats-info">Active Tasks</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- Row -->

            <div class="row">

                <div class="col-lg-4 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                            <h4 class="panel-title">Reports</h4>
                        </div>
                        <div class="panel-body">
                            <div class="browser-stats">
                                <ul class="list-unstyled">
                                    <li><i class="fa fa-lock"></i>Passwords<div class="pull-right"><span class="label label-default">Count: <?php echo $stats['reports_stats']['passwords_count'] ?></span> <span class="label label-default">Bots: <?php echo $stats['reports_stats']['passwords_bots_count'] ?></span></div></li>
                                    <li><i class="fa icon-embed2"></i>Forms<div class="pull-right"><span class="label label-default">Count: <?php echo $stats['reports_stats']['forms_count'] ?></span> <span class="label label-default">Bots: <?php echo $stats['reports_stats']['forms_bots_count'] ?></span></div></li>
                                    <li><i class="fa fa-file-image-o"></i>Screenshots<div class="pull-right"><span class="label label-default">Count: <?php echo $stats['reports_stats']['screenshots_count'] ?></span> <span class="label label-default">Bots: <?php echo $stats['reports_stats']['screenshots_bots_count'] ?></span></div></li>
                                    <li><i class="fa icon-sphere"></i>Domains<div class="pull-right"><span class="label label-default">Count: <?php echo $stats['reports_stats']['domains_count'] ?></span> <span class="label label-default">Bots: <?php echo $stats['reports_stats']['domains_bots_count'] ?></span></div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                            <h4 class="panel-title">Layers</h4>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive invoice-table">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <td>Layer IP</td>
                                            <td>Active Bots</td>
                                            <td>Total Bots</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        foreach($stats['layer_stats'] as $layer)
                                        {
                                            echo '
                                            <tr>
                                                <td>'.$layer['ip'].'</td>
                                                <td>'.$layer['active_bots'].'</td>
                                                <td>'.$layer['total_bots'].'</td>
                                            </tr>
                                            ';
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>