<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading panel-heading--with-btn">
                <button type="button" class="btn btn-default" id="add-group-head-button" style="margin-top: 1%; margin-bottom: 2%;">New Group</button>
            </div>
            <div class="panel-body">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#inject-tab-1" role="tab" data-toggle="tab"
                                                                  data-type-web-inject="inject-tab-1">Group Bots
                                List</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active fade in" id="inject-tab-1">
                            <div style="overflow: auto">
                                <table id="table-web-injects-campaigns" class="table table-condensed" cellspacing="0"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th style="word-wrap: break-word;">Name Group</th>
                                        <th style="word-wrap: break-word;">Action Delete</th>
                                        <th style="width: 10px; display: none;"></th>
                                    </tr>
                                    </thead>
                                    <tbody data-groups-list>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>