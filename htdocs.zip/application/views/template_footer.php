                </div><!-- /Page Inner -->
            </div><!-- /Page Content -->
        </div>
        <?php
        echo $this->generateJS();
        ?>
    </body>
</html>