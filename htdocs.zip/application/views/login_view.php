<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Log in</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <link href="css/icomoon.css" rel="stylesheet">

    <!-- Styles -->
    <link href="plugins/uniform/css/default.css" rel="stylesheet"/>
    <link href="plugins/switchery/switchery.min.css" rel="stylesheet"/>

    <!-- Theme Styles -->
    <link href="css/space.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">


    <link href="css/jquery.jgrowl.css" rel="stylesheet" type="text/css">
    <link href="css/multiselect.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <!-- /.login-logo -->
    <div class="login-box-body">
        <p class="login-box-msg">Sign in to start your session</p>

        <form action="" id="login_form" role="form">
            <div class="form-group has-feedback">
                <input type="text" name="username" class="form-control" placeholder="Login">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" name="password" class="form-control" placeholder="Password">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-12">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

    </div>
    <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="js/jquery/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function(){
        $('#login_form').on('submit', function(e) {
            e.preventDefault();
            var formArr = $(this).serialize();
            sendTryToAuthRequest(formArr);
            console.log(formArr);
        });

        function sendTryToAuthRequest(data) {
            sendAjax('post', data);
        }

        function sendAjax(type, data) {
            $.ajax({
                type: type,
                url: "/login/tryauth",
                data: data,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                success: function(res) {
                    if (res) {
                        console.log(res);
						//window.location.href = "../";
                    } else {
                        window.location.href = "../404";
                    }
                }
            });
        }
    });
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' /* optional */
        });
    });
</script>
</body>
</html>
