<div class="page-title">
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab-software" role="tab" data-toggle="tab"
                                                                  data-type-web-inject="tab-passwords">List Software
                                <span class="label label-default"></span></a></li>
                        <li role="presentation"><a href="#tab-form-grabber" role="tab" data-toggle="tab">List Form Grabber <span class="label label-default"></span></a></li>
                        <li role="presentation"><a href="#tab-os" role="tab" data-toggle="tab">List OS <span class="label label-default"></span></a></li>
                        <li role="presentation"><a href="#tab-netview" role="tab" data-toggle="tab">List NetView<span class="label label-default"></span></a></li>
                    </ul>
                    <div class="tab-content">
                        <h5><label>Name Group</label></h5>
                        <input type="text" class="form-control" id="name_group" />
                    </div>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active fade in" id="tab-software">
                            <h5><label>List install Software:</label></h5>
                            <textarea placeholder="Format example -> Google Chrome, Firefox" class="form-control" id="list_install_software"
                                      name="list_install_software"></textarea>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-form-grabber">
                            <h5><label>List url for Form Grabber:</label></h5>
                            <textarea placeholder="Format example -> google.com, bingo.com" class="form-control" id="list_url_form_grabber"
                                      name="list_url_form_grabber"></textarea>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-os">
                            <h5><label>List Operation Systems:</label></h5>
                            <textarea placeholder="Format example -> Windows 10 Pro, Windows 7" class="form-control" id="list_os" name="list_os"></textarea>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-netview">
                            <h5><label>List NetView Domain:</label></h5>
                            <textarea placeholder="Format example -> SYSTEMGROUP, WORKGROUP" class="form-control" id="list_netview_domain"
                                      name="list_netview_domain"></textarea>
                        </div>
                        <div class="form-group text-right" style="margin-top:2%;">
                            <button type="submit" id="add_group" class="btn btn-default">Add Group</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>