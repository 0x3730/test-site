<div class="page-title">
    <h5><i class="fa fa-bars"></i> Modules settings </h5>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="form-group col-sm-12 col-md-10 col-lg-10" style="padding: 0;">
            <select id="modules_names" data-placeholder="Choose a status..." class="select-full select2-offscreen" tabindex="-1">
                <?php
                foreach($modules as $module) {
                    echo '<option value="'.$module['id'].'">'.$module['name'].'</option>';
                }
                ?>
            </select>
        </div>
        <div class="form-group col-sm-12 col-md-2 col-lg-2 text-right" style="padding: 0;">
            <button id="new_module" class="btn btn-default">Add Module</button>
        </div>
    </div>
    <div id="module_info_panel" class="col-sm-12 col-md-6 col-lg-6">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title"><span id="module_name"><?php echo $module_info['name']?></span> (id: <span id="module_id"><?php echo $module_info['id']?></span>)</h6></div>
            <div class="panel-body">
                <form role="form">
                    <div class="form-group" style="margin-bottom: 10px;">
                        <label>URL</label>
                        <div class="row">
                            <div class="col-md-12 col-lg-6">
                                <input id="url_x32" type="text" class="form-control" placeholder="Enter url for x32..." value="<?php echo $module_info['url_x32']?>">
                                <span class="help-block" style="margin-top: 0; margin-bottom: 0;">x32</span>
                            </div>
                            <div class="col-md-12 col-lg-6" style="margin-top: 0;">
                                <input id="url_x64" type="text" class="form-control" placeholder="Enter url for x64..." value="<?php echo $module_info['url_x64']?>">
                                <span class="help-block" style="margin-top: 0; margin-bottom: 0;">x64</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group" style="margin-bottom: 10px;">
                        <label>HASH</label>
                        <div class="row">
                            <div class="col-md-12 col-lg-6">
                                <input id="hash_x32" type="text" class="form-control" placeholder="Enter hash for x32..." value="<?php echo $module_info['hash_x32']?>">
                                <span class="help-block" style="margin-top: 0; margin-bottom: 0;">x32</span>
                            </div>
                            <div class="col-md-12 col-lg-6" style="margin-top: 0;">
                                <input id="hash_x64" type="text" class="form-control" placeholder="Enter hash for x64..." value="<?php echo $module_info['hash_x64']?>">
                                <span class="help-block" style="margin-top: 0; margin-bottom: 0;">x64</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>STATUS</label>
                        <select id="module_status" data-placeholder="Choose a status..." class="select-full select2-offscreen" tabindex="-1">
                            <option value="1" <?php if ($module_info['status'] == 1) echo 'selected'; ?>>Enabled</option>
                            <option value="0" <?php if ($module_info['status'] == 0) echo 'selected'; ?>>Disabled</option>
                        </select>
                    </div>
                </form>
                <div class="text-right">
                    <button id="save_module" class="btn btn-default btn-lg right">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div id="module_configs_panel" class="col-sm-12 col-md-6 col-lg-6">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Configs</h6></div>
            <div class="panel-body">
                <div id="configs_scroll" class="col-sm-12 col-md-12 col-lg-12" style="margin-bottom: 15px; padding: 0; max-height: 300px;">
                    <?php
                    $configs_text = "";
                    foreach($configs as $config) {
                        $configs_text.='
                            <div id="config_'.$config['id'].'" class="input-group">
                                <input type="text" class="form-control" value="'.$config['name'].'" disabled>
                                <div class="input-group-btn">
                                    <button onclick="editCfg(this)" class="btn btn-default open_edit_config" data-toggle="modal" data-target="#editable_config_modal" type="button" style="height: 34px;"><i class="fa fa-cogs"></i></button>
                                    <button onclick="deleteCfg(this)" class="btn btn-default delete_config" type="button" style="height: 34px;"><i class="fa fa-trash-o"></i></button>
                                </div>
                            </div>
                        ';
                    }
                    if (empty($configs_text))
                        $configs_text = "Configs didn't find.";
                    echo $configs_text;

                    ?>
                </div>
                <!--<div id="configs_scroll" class="col-sm-12 col-md-12 col-lg-12" style="margin-bottom: 15px; padding: 0; max-height: 300px;">
                    <div class="input-group">
                        <input type="text" class="form-control" value="Config name" disabled>
                        <div class="input-group-btn">
                            <button class="btn btn-default" type="button" style="height: 34px;"><i class="fa fa-cogs"></i></button>
                            <button class="btn btn-default" type="button" style="height: 34px;"><i class="fa fa-trash-o"></i></button>
                        </div>
                    </div>
                </div>-->
                <div class="text-right">
                    <button data-toggle="modal" data-target="#new_config_modal" type="button" class="btn btn-lg btn-default">New config</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="new_config_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">New Config</h5>
            </div>

            <!-- Form inside modal -->
            <form role="form" action="#">
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Config's name</label>
                        <input id="new_config_name" class="form-control" placeholder="Enter name...">
                    </div>
                    <div class="form-group">
                        <label>Config's field</label>
                        <textarea id="new_config_field" rows="5" cols="5" class="form-control" style="resize: vertical; min-height: 100px;" placeholder="Enter properties and values..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="text-right">
                        <input id="new_config_save" type="submit" value="Save config" class="btn btn-default">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="editable_config_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Edit Config</h5>
            </div>

            <!-- Form inside modal -->
            <form role="form" action="#">
                <div class="modal-body has-padding">
                    <input id="editable_config_id" value="" hidden>
                    <div class="form-group">
                        <label>Config's name</label>
                        <input id="editable_config_name" class="form-control" placeholder="Enter name...">
                    </div>
                    <div class="form-group">
                        <label>Config's field</label>
                        <textarea id="editable_config_field" rows="5" cols="5" class="form-control" style="resize: vertical; min-height: 100px;" placeholder="Enter properties and values..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="text-right">
                        <input id="editable_config_save" type="submit" value="Save config" class="btn btn-default">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>