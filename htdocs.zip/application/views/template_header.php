<?php
global $CURRENT_PATH;
$admin = "1";
$bots_cp = "1";
$task_cp = "1";
$web_inj_cp = "1";
$grabber_settings_cp = "1";

#Check privilege for show menu.
if (isset($_SESSION['list_access']) || !empty($_SESSION['list_access'])) {
    $list_access = explode(',', $_SESSION['list_access']);
    $bots_cp = '0';
    $task_cp = '0';
    $admin_cp = '0';
    $admin = '0';
    $web_inj_cp = '0';
    $grabber_settings_cp = '0';
    $report_cp = '0';
    $report_stealer = '0';
    $report_socks = '0';
    $report_backcmd = '0';
    $report_http_grabber = '0';
    $report_screenshots = '0';

    foreach ($list_access as $value) {
        if ($value === 'ALL') {
            $admin = '1';
            break;
        } elseif ($value === 'ALLOW_USERS_CP') {
            $admin_cp = '1';
        } elseif ($value === 'ALLOW_BOTS') {
            $bots_cp = '1';
        } elseif ($value === 'ALLOW_TASK_CP') {
            $task_cp = '1';
        } elseif ($value === 'ALLOW_WEB_INJ_CP') {
            $web_inj_cp = '1';
        } elseif ($value === 'ALLOW_GRABBER_SETTINGS_CP') {
            $grabber_settings_cp = '1';
        } elseif ($value === 'ALLOW_ALL_REPORTS') {
            $report_cp = '1';
        } elseif ($value === 'ALLOW_REPORT_STEALER') {
            $report_stealer = '1';
        } elseif ($value === 'ALLOW_REPORT_SOCKS') {
            $report_socks = '1';
        } elseif ($value === 'ALLOW_REPORT_BACKCMD') {
            $report_backcmd = '1';
        } elseif ($value === 'ALLOW_REPORT_HTTP_GRABBER') {
            $report_http_grabber = '1';
        } elseif ($value === 'ALLOW_REPORT_SCREENSHOTS') {
            $report_screenshots = '1';
        } elseif ($value === 'DISALLOW_ALL') {
            $admin = '0';
        } elseif ($value === 'DISALLOW_USERS_CP') {
            $admin_cp = '0';
        } elseif ($value === 'DISALLOW_BOTS') {
            $bots_cp = '0';
        } elseif ($value === 'DISALLOW_TASK_CP') {
            $task_cp = '0';
        } elseif ($value === 'DISALLOW_WEB_INJ_CP') {
            $web_inj_cp = '0';
        } elseif ($value === 'DISALLOW_GRABBER_SETTINGS_CP') {
            $grabber_settings_cp = '0';
        } elseif ($value === 'DISALLOW_ALL_REPORTS') {
            $report_cp = '0';
        }
    }
} else {
    //Route::ErrorPage404();
}

#Check privilege for access in page.
if (isset($_SESSION['list_access']) || !empty($_SESSION['list_access'])) {
    if ($CURRENT_PATH === 'bots' && $bots_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'bots' && $bots_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'tasks' && $task_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'tasks' && $task_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'webinjects_main' && $web_inj_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'webinjects_main' && $web_inj_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'http_grabber_settings' && $grabber_settings_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'http_grabber_settings' && $grabber_settings_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'users_cp' && $admin_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'users_cp' && $admin_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'settings' && $admin_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'settings' && $admin_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'group_bots' && $admin_cp === '1' OR $admin === '1') {

    } elseif ($CURRENT_PATH === 'group_bots' && $admin_cp === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'stealer' && $report_stealer === '1' OR $admin === '1' OR $report_cp === '1') {

    } elseif ($CURRENT_PATH === 'stealer' && $report_stealer === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'socks' && $report_socks === '1' OR $admin === '1' OR $report_cp === '1') {

    } elseif ($CURRENT_PATH === 'socks' && $report_socks === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'backcmd' && $report_backcmd === '1' OR $admin === '1' OR $report_cp === '1') {

    } elseif ($CURRENT_PATH === 'backcmd' && $report_backcmd === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'http_grabber' && $report_http_grabber === '1' OR $admin === '1' OR $report_cp === '1') {

    } elseif ($CURRENT_PATH === 'http_grabber' && $report_http_grabber === '0') {
        Route::StartPage();
    } elseif ($CURRENT_PATH === 'screenshots' && $report_screenshots === '1' OR $admin === '1' OR $report_cp === '1') {

    } elseif ($CURRENT_PATH === 'screenshots' && $report_screenshots === '0') {
        Route::StartPage();
    }

}


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'> -->

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">

    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- DataTables -->
    <link href="plugins/datatables/css/jquery.datatables.min.css" rel="stylesheet" type="text/css"/>
    <link href="plugins/datatables/css/jquery.datatables_themeroller.css" rel="stylesheet" type="text/css"/>

    <link href="css/icomoon.css" rel="stylesheet">

    <!-- Styles -->
    <link href="plugins/uniform/css/default.css" rel="stylesheet"/>
    <link href="plugins/switchery/switchery.min.css" rel="stylesheet"/>

    <!-- Contry Flags -->
    <link href="css/flags/flags.min.css" rel="stylesheet" type="text/css"/>

    <!-- Theme Styles -->
    <link href="css/space.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">


    <link href="css/jquery.jgrowl.css" rel="stylesheet" type="text/css">
    <link href="css/multiselect.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <?php
    echo $this->generateCSS();
    ?>


    <script type="text/javascript" src="js/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery/jquery-ui.min.js"></script>

    <script type="text/javascript" src="js/plugins/base64.js"></script>

    <script type="text/javascript" src="js/plugins/forms/uniform.min.js"></script>
    <script type="text/javascript" src="js/plugins/forms/select2.min.js"></script>
    <script type="text/javascript" src="js/plugins/forms/inputmask.js"></script>
    <script type="text/javascript" src="js/plugins/forms/autosize.js"></script>
    <script type="text/javascript" src="js/plugins/forms/inputlimit.min.js"></script>
    <script type="text/javascript" src="js/plugins/forms/listbox.js"></script>
    <script type="text/javascript" src="js/plugins/forms/multiselect.js"></script>
    <script type="text/javascript" src="js/plugins/forms/validate.min.js"></script>
    <script type="text/javascript" src="js/plugins/forms/tags.min.js"></script>

    <script type="text/javascript" src="js/plugins/forms/uploader/plupload.full.min.js"></script>
    <script type="text/javascript" src="js/plugins/forms/uploader/plupload.queue.min.js"></script>

    <!--<script type="text/javascript" src="js/plugins/forms/wysihtml5/wysihtml5.min.js"></script>
    <script type="text/javascript" src="js/plugins/forms/wysihtml5/toolbar.js"></script>-->

    <script type="text/javascript" src="js/plugins/interface/jgrowl.min.js"></script>
    <!--<script type="text/javascript" src="js/plugins/interface/datatables.min.js"></script>-->

    <script src="js/plugins/interface/datatables.min.js"></script>

    <script type="text/javascript" src="js/plugins/interface/prettify.js"></script>
    <script type="text/javascript" src="js/plugins/interface/fancybox.min.js"></script>
    <!--<script type="text/javascript" src="js/plugins/interface/colorpicker.js"></script>
    <script type="text/javascript" src="js/plugins/interface/timepicker.min.js"></script>
    <script type="text/javascript" src="js/plugins/interface/fullcalendar.min.js"></script>-->
    <script type="text/javascript" src="js/plugins/interface/collapsible.min.js"></script>

    <!-- SPACE TEMPLATE -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="plugins/uniform/js/jquery.uniform.standalone.js"></script>
    <script src="plugins/switchery/switchery.min.js"></script>
    <script src="js/space.min.js"></script>
    <script src="js/logout.js"></script>
    <!-- /SPACE TEMPLATE -->

    <!-- Bootstrap 3.3.7 -->
    <script src="js/bootstrap.min.js"></script>

    <!--<script type="text/javascript" src="js/bootstrap.min.js"></script>-->
    <script type="text/javascript" src="js/application.js"></script>

    <!--<script type="text/javascript" src="js/charts/simple_graph.js"></script>-->
</head>
<body>
<!-- Page Container -->
<div class="page-container">
    <!-- Page Sidebar -->
    <div class="page-sidebar">
        <a class="logo-box">
            <span class="logo-text">Bot's Panel</span>
            <!--<i class="icon-radio_button_unchecked" id="fixed-sidebar-toggle-button"></i>-->
            <i class="icon-close" id="sidebar-toggle-button-close"></i>
        </a>
        <div class="page-sidebar-inner">
            <div class="page-sidebar-menu">
                <ul class="accordion-menu">
                    <li<?php echo $CURRENT_PATH === 'main' ? ' class="active-page"' : '' ?>><a href="/main"><i
                                    class="menu-icon icon-dashboard"></i><span>Dashboard</span></a></li>
                    <li<?php echo $CURRENT_PATH === 'operating_systems' ||
                    $CURRENT_PATH === 'browsers' ||
                    $CURRENT_PATH === 'countries' ||
                    $CURRENT_PATH === 'installed_software'
                        ? ' class="active-page"' : '' ?>>
                        <a href="javascript:void(0);">
                            <i class="menu-icon fa fa-bar-chart"></i><span>Statistics</span><i
                                    class="accordion-icon fa fa-angle-left"></i>
                        </a>
                        <ul class="sub-menu">
                            <li<?php echo $CURRENT_PATH === 'operating_systems' ? ' class="active-page"' : '' ?>><a
                                        href="/operating_systems">Operating systems</a></li>
                            <li<?php echo $CURRENT_PATH === 'browsers' ? ' class="active-page"' : '' ?>><a
                                        href="/browsers">Browsers</a></li>
                            <li<?php echo $CURRENT_PATH === 'countries' ? ' class="active-page"' : '' ?>><a
                                        href="/countries">Countries</a></li>
                            <li<?php echo $CURRENT_PATH === 'installed_software' ? ' class="active-page"' : '' ?>><a
                                        href="/installed_software">Software</a></li>
                        </ul>
                    </li>

                    <?php if ($bots_cp === '1' || $admin === '1') {
                        echo '<li';
                        echo $CURRENT_PATH === 'bots' ? ' class="active-page"' : '';
                    } ?>
                    <?php if ($bots_cp === '1' || $admin === '1') {
                        echo '><a href="/bots"><i class="menu-icon icon-user"></i><span>Bots</span></a></li>';
                    } ?>

                    <?php if ($task_cp === '1' || $admin === '1') {
                        echo '<li';
                        echo $CURRENT_PATH === 'tasks' ? ' class="active-page"' : '';
                    } ?>
                    <?php if ($task_cp === '1' || $admin === '1') {
                        echo '><a href="/tasks"><i class="menu-icon fa fa-tasks"></i><span>Tasks</span></a></li>';
                    } ?>

                    <?php if ($web_inj_cp === '1' || $admin === '1') {
                        echo '<li';
                        echo $CURRENT_PATH === 'webinjects_main' ? ' class="active-page"' : '';
                    } ?>
                    <?php if ($web_inj_cp === '1' || $admin === '1') {
                        echo ' ><a href="/webinjects_main"><i class="menu-icon fa fa-bug"></i><span>Web Injects</span></a></li>';
                    } ?>

                    <!--<li>
                        <a href="javascript:void(0);">
                            <i class="menu-icon fa fa-plus-square"></i><span>Modules</span><i class="accordion-icon fa fa-angle-left"></i>
                        </a>
                        <ul class="sub-menu">
                            <li><a href="/modules">Settings</a></li>
                            <li><a href="/modules_tasks">Tasks</a></li>
                        </ul>
                    </li>-->
                    <li<?php echo $CURRENT_PATH === 'stealer' ||
                    $CURRENT_PATH === 'socks' ||
                    $CURRENT_PATH === 'backcmd' ||
                    $CURRENT_PATH === 'http_grabber' ||
                    $CURRENT_PATH === 'screenshots'
                        ? ' class="active-page"' : '' ?>>
                        <a href="javascript:void(0);">
                            <i class="menu-icon fa fa-file-text"></i><span>Reports</span><i
                                    class="accordion-icon fa fa-angle-left"></i>
                        </a>
                        <ul class="sub-menu">
                            <li<?php echo $CURRENT_PATH === 'stealer' ? ' class="active-page"' : '' ?>><a
                                        href="/stealer">Stealer</a></li>
                            <li<?php echo $CURRENT_PATH === 'socks' ? ' class="active-page"' : '' ?>><a href="/socks">Socks</a>
                            </li>
                            <li<?php echo $CURRENT_PATH === 'backcmd' ? ' class="active-page"' : '' ?>><a
                                        href="/backcmd">Backcmd</a></li>
                            <li<?php echo $CURRENT_PATH === 'http_grabber' ? ' class="active-page"' : '' ?>><a
                                        href="/http_grabber">HTTP Grabber</a></li>
                            <li<?php echo $CURRENT_PATH === 'screenshots' ? ' class="active-page"' : '' ?>><a
                                        href="/screenshots">Screenshots</a></li>
                        </ul>
                    </li>

                    <?php if ($grabber_settings_cp === '1' || $admin === '1') {
                        echo '<li';
                        echo $CURRENT_PATH === 'http_grabber_settings' ? ' class="active-page"' : '';
                    } ?>
                    <?php if ($grabber_settings_cp === '1' || $admin === '1') {
                        echo '><a href="/http_grabber_settings"><i class="menu-icon fa fa-user-secret"></i><span>Grabber Settings</span></span></a></li>';
                    } ?>

                    <li class="menu-divider"></li>


                    <li <?php echo $CURRENT_PATH === 'settings' ||
                    $CURRENT_PATH === 'users_cp' || $CURRENT_PATH === 'group_bots'
                        ? 'class="active-page"' : '' ?>>
                        <?php
                        if ($admin === '1' || $admin_cp === '1') {
                            echo '<a href="javascript:void(0);">
                                    <i class="menu-icon fa fa-cogs"></i><span>Admin CP</span><i class="accordion-icon fa fa-angle-left"></i>
                                </a>';
                        } else {
                        }
                        ?>
                        <ul class="sub-menu">
                            <li<?php echo $CURRENT_PATH === 'settings' ? ' class="active-page"' : '' ?>><a
                                        href="<?php if ($admin === '1' || $admin_cp === '1') {
                                            echo '/settings';
                                        } ?>">General Settings</a></li>
                            <li<?php echo $CURRENT_PATH === 'users_cp' ? ' class="active-page"' : '' ?>><a
                                        href="<?php if ($admin === '1' || $admin_cp === '1') {
                                            echo '/users_cp';
                                        } ?>">Users CP</a></li>

                            <li<?php echo $CURRENT_PATH === 'group_bots' ? ' class="active-page "' : '' ?>><a
                                        href="<?php if ($admin === '1' || $admin_cp === '1') {
                                            echo '/group_bots';
                                        } ?>">Group Bots CP</a></li>
                        </ul>

                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /Page Sidebar -->

    <!-- Page Content -->
    <div class="page-content">
        <!-- Page Header -->
        <div class="page-header">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <div class="logo-sm">
                            <a href="javascript:void(0)" id="sidebar-toggle-button"><i class="fa fa-bars"></i></a>
                            <a class="logo-box logo-text2"><span>bot's panel</span></a>
                        </div>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <i class="fa fa-angle-down"></i>
                        </button>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li><a href="javascript:void(0)" id="collapsed-sidebar-toggle-button"><i
                                            class="fa fa-bars"></i></a></li>
                            <li><a href="javascript:void(0)" id="toggle-fullscreen"><i class="fa fa-expand"></i></a>
                            </li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <!--<li><a href="javascript:void(0)" id="toggle-fullscreen"><i class="fa fa-expand"></i></a></li>-->
                            <li class="dropdown user-dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                   aria-haspopup="true" aria-expanded="false"><img src="/images/36x36.png" alt=""
                                                                                   class="img-circle"></a>
                                <ul class="dropdown-menu">
                                    <li><a href="/profile">Profile</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="javascript:void(0)" onclick="sendLogOut()">Log Out</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </nav>
        </div><!-- /Page Header -->
        <!-- Page Inner -->
        <div class="page-inner" style="font-size: 12px;">