<div id="bot-tab-forms-show-more-info" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">HTTP-Grabber addition info</h5>
            </div>

            <!-- Table inside modal -->
            <div class="modal-body has-padding">
                <div class="panel panel-white">
                    <div id="bot-tab-forms-show-more-info-data">

                    </div>
                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>
