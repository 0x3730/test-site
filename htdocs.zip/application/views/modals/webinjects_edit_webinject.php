<div id="web-injects-edit-webinject" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title">Edit web-inject</h5>
            </div>

            <!-- Table inside modal -->
            <form id="form-web-injects-edit" role="form" action="javascript:void(0)">
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Name</label>
                        <input id="edit-webinject-name" class="form-control" placeholder="Enter inject name..." required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea id="edit-webinject-description" class="form-control" style="resize: none; min-height: 80px;"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Source code</label>
                        <textarea id="edit-webinject-source" class="form-control textarea-expanded" style="resize: none; min-height: 200px;" required></textarea>
                    </div>
                    <input id="edit-webinject-id" hidden>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <div class="text-right">
                        <input id="edit-webinject-delete" type="submit" value="Delete" class="btn btn-default">
                        <input id="edit-webinject-update" type="submit" value="Save changes" class="btn btn-default">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
