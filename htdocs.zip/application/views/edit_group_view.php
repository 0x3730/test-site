<script>
    $(document).ready(function () {
        groupInfo.updateGroupInfo();
    });

    const groupInfo = {
        updateGroupInfo: function () {
            $.get(document.location.pathname + '/get_group_info?group_id=<?php echo $_GET['group_id']; ?>')
                .success(function (res) {
                    $('[data-group-info]').empty();
                    $('[data-group-info]').append(res);
                });
        }
    };
</script>
<div class="page-title">
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab-software" role="tab" data-toggle="tab"
                                                                  data-type-web-inject="tab-passwords">List Software
                                <span class="label label-default"></span></a></li>
                        <li role="presentation"><a href="#tab-form-grabber" role="tab" data-toggle="tab">List Form
                                Grabber <span class="label label-default"></span></a></li>
                        <li role="presentation"><a href="#tab-os" role="tab" data-toggle="tab">List OS <span
                                        class="label label-default"></span></a></li>
                        <li role="presentation"><a href="#tab-netview" role="tab" data-toggle="tab">List NetView<span
                                        class="label label-default"></span></a></li>
                    </ul>
                    <div class="tab-content">

                    </div>
                    <!-- Tab panes -->
                    <div class="tab-content" data-group-info>

                    </div>
                    <div class="form-group text-right" style="margin-top:2%;">
                        <button type="submit" id="edit-group" class="btn btn-default" style="margin-right: 0.3%;">Edit Group</button>
                        <button type="submit" id="delete-group" class="btn btn-danger">Delete Group</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>