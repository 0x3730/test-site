<?php
session_start();

class Controller_Settings extends Controller
{

    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Settings();
            $settings = $this->model->getSettings();
            $general_settings = $this->model->getGeneralSettings();
            $this->view->addJavaScripts(array('js/pages/general_settings.js'));
            $this->view->generate('settings_view.php', array('settings' => $settings, 'general_settings' => $general_settings));
        //}
    }

    public function action_update_setting() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Settings();
            $this->model->setRequestData($this->data);
            $result = $this->model->updateSetting();
            if ($result)
                die('1');
            else
                die('0');
        //}
    }

    public function action_update_modules() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Settings();
            $this->model->setRequestData($this->data);
            $result = $this->model->updateModulesHash();
            if ($result == true)
                die('1');
            else
                die('0');
        //}
    }

    public function action_download_all_reports() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Settings();
            $this->model->setRequestData($this->data);
            $this->model->downloadAllReports();
        //}
    }
}