<?php
session_start();

class Controller_Backcmd extends Controller
{
    public function action_index()
    {
        //if (Authorization::checkLogin())
        //{
            $this->model = new Model_Backcmd();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/backcmd.js'));
            $this->view->generate('backcmd_view.php', array('settings' => $settings));
        //}
    }

    public function action_getbackcmd()
    {
        //if (Authorization::checkLogin())
        //{
            $this->model = new Model_Backcmd();
            $this->model->setRequestData($this->data);
            die($this->model->getBackcmd());
        //}
    }
}
