<?php
session_start();

class Controller_Updater_Groups extends Controller
{
    public function action_index()
    {
        $this->model = new Model_Updater_Groups();
        $settings = $this->model->getSettings();
        $this->view->generate('updater_groups_view.php', array('settings' => $settings));
    }
}

?>