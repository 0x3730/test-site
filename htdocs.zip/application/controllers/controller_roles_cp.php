<?php
session_start();

class Controller_Roles_CP extends Controller
{
    public function action_index()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Roles_CP();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/roles_cp.js'));
            $this->view->generate('roles_cp_view.php', array('settings' => $settings));
        }
    }

    public function action_get_roles_list()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Roles_CP();
            $this->model->setRequestData($this->data);
            die($this->model->getRoles());
        }
    }

    public function action_add_new_role()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Roles_CP();
            $this->model->setRequestData($this->data);
            if ($this->model->CreateRole()) {
                die('1');
            } else {
                die('0');
            }
        }
    }

    public function action_role_delete()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Roles_CP();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteRole()) {
                die('1');
            } else {
                die('0');
            }
        }
    }
}


?>