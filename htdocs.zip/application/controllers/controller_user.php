<?php
session_start();

class Controller_User extends Controller
{
    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_User();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/user.js'));
            $this->view->generate('user_view.php', array('settings' => $settings));
        //}
    }

    public function action_get_user_info()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_User();
            $this->model->setRequestData($this->data);
            die($this->model->getUserInfo());
        //}
    }

    public function action_edit_user()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_User();
            $this->model->setRequestData($this->data);
            if ($this->model->editUser()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }

    public function action_user_delete()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_User();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteUser()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }
}

?>