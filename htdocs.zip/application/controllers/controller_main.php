<?php
session_start();

class Controller_Main extends Controller
{

    public function action_index()
	{
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Main();
			$settings = $this->model->getSettings();
            $stats = $this->model->getStats();
            $this->view->generate('main_view.php', array('settings' => $settings, 'stats' => $stats));
        //}
	}
}