<?php
session_start();

class Controller_Installed_Software extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Installed_Software();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $firewalls = $this->model->getInstalledFirewalls();
            $antiViruses = $this->model->getInstalledAntiviruses();
            $software = $this->model->getInstalledSoftware();
            $this->view->generate('installed_software_view.php', array(
                'settings' => $settings,
                'firewalls' => $firewalls,
                'antiViruses' => $antiViruses,
                'software' => $software
            ));
        //}
    }
}