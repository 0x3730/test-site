<?php
session_start();

class Controller_Webinjects_Main extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();

            $this->view->addJavaScripts(array(
                'js/plugins/mustache.min.js',
                'js/pages/webinjects_main.js',
                'js/modals/webinjects_new_webinject.js',
                'js/modals/webinjects_new_group.js',
                'js/modals/webinjects_new_campaign.js',
                'js/modals/webinjects_edit_webinject.js',
                'js/modals/webinjects_edit_group.js',
                'js/modals/webinjects_edit_campaign.js'));
            $this->view->addCSS(array('css/pages/webinjects_main.css'));
            $this->view->addModalWindows(array(
                'webinjects_new_webinject.php',
                'webinjects_new_group.php',
                'webinjects_new_campaign.php',
                'webinjects_edit_webinject.php',
                'webinjects_edit_group.php',
                'webinjects_edit_campaign.php'));

            $injectsListForView = $this->model->getInjectsListForView();
            $groupsListForView = $this->model->getGroupsListForView();

            $this->view->generate('webinjects_main_view.php', array('settings' => $settings, 'injectsList' => $injectsListForView, 'groupsList' => $groupsListForView));
        //}
    }

    /**
     * Get list of injects for group or campaign view
     */
    public function action_get_injects_list()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die(json_encode($this->model->getInjectsListForView()));
        //}
    }

    /**
     * Get list of groups for campaign view
     */
    public function action_get_groups_list()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die(json_encode($this->model->getGroupsListForView()));
        //}
    }

    /**
     * A new inject creation
     */
    public function action_create_webinject()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->createInject()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * A new group creation
     */
    public function action_create_group()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->createGroup()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * A new campaign creation
     */
    public function action_create_campaign()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->createCampaign()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * Get list of injects for table
     */
    public function action_get_webinjects()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getInjectsList());
        //}
    }

    /**
     * Get list of groups for table
     */
    public function action_get_groups()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getGroupsList());
        //}
    }

    /**
     * Get list of campaigns for table
     */
    public function action_get_campaigns()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getCampaignsList());
        //}
    }

    /**
     * Take info about inject by id
     */
    public function action_get_inject_info()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getInjectInfo());
        //}
    }

    /**
     * Update info about inject by id
     */
    public function action_update_inject()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->updateInject()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * Update info about group by id
     */
    public function action_update_group()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->updateGroup()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * Take info about group by id
     */
    public function action_get_group_info()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getGroupInfo());
        //}
    }

    /**
     * Take excluded from group injects
     */
    public function action_get_excluded_injects()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getExcludedInjects());
        //}
    }

    /**
     * Include inject into group
     */
    public function action_add_inject_to_group()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->addInjectToGroup()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * Delete inject from group
     */
    public function action_delete_inject_from_group()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteInjectFromGroup()) {
                die('1');
            }
            die('0');
        //}
    }

    /**
     * Delete inject finally
     */
    public function action_delete_inject()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteInject()) {
                die('1');
            }
            die('0');
        //}
    }

    public function action_get_campaign_info()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            die($this->model->getCampaignInfo());
        //}
    }

    public function action_update_campaign_info()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Webinjects_Main();
            $this->model->setRequestData($this->data);
            if ($this->model->updateCampaignInfo()) {
                die('1');
            }
            die('0');
        //}
    }
}