<?php
session_start();

class Controller_Countries extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Countries();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $countriesStats = $this->model->getCountriesStats();
            $this->view->generate('countries_view.php', array(
                'settings' => $settings,
                'countries_stats' => $countriesStats
            ));
        //}
    }
}