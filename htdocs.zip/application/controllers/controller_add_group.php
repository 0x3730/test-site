<?php
session_start();

class Controller_Add_Group extends Controller
{
    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Add_Group();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/add_group.js'));
            $this->view->generate('add_group_view.php', array('settings' => $settings));
        //}
    }

    public function action_add_new_group()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Add_Group();
            $this->model->setRequestData($this->data);
            if ($this->model->CreateGroup()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }
}

?>