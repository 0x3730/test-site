<?php
session_start();

class Controller_Browsers extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Browsers();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $browserStats = $this->model->getBrowserStats();
            $this->view->generate('browsers_view.php', array(
                'settings' => $settings,
                'browser_stats' => $browserStats
            ));
        //}
    }
}