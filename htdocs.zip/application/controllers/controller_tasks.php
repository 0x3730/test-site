<?php
session_start();

class Controller_Tasks extends Controller {

    public function action_index()
    {
        //if (Authorization::checkLogin())
        //{
            $this->model = new Model_Tasks();
            $settings = $this->model->getSettings();
            $tasks_settings = $this->model->getTasksOptions();
            $this->view->addCSS(array(
                'css/bootstrap-rangeSlider/ion.rangeSlider.css',
                'css/bootstrap-rangeSlider/ion.rangeSlider.skin.css',
                'css/pages/tasks.css'));
            $this->view->addJavaScripts(array('js/plugins/bootstrap-rangeSlider/ion.rangeSlider.min.js', 'js/pages/tasks.js'));
            $this->view->generate('tasks_view.php', array('settings' => $settings, 'tasks_settings' => $tasks_settings));
        //}
    }

    public function action_newtask()
    {
        //if (Authorization::checkLogin())
        //{
            $this->model = new Model_Tasks();
            $this->model->setRequestData($this->data);
            if ($this->model->createTask())
                die('1');
            else
                die('0');
        //}
    }

    public function action_updtask()
    {
        //if (Authorization::checkLogin())
        //{
            $this->model = new Model_Tasks();
            $this->model->setRequestData($this->data);
            if ($this->model->updateTask()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }

    public function action_get_tasks_list()
    {
        //if (Authorization::checkLogin())
        //{
            $this->model = new Model_Tasks();
            $this->model->setRequestData($this->data);
            die($this->model->loadTasksList());
        //}
    }
}