<?php
session_start();

class Controller_Role extends Controller
{
    public function action_index()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Role();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/role.js'));
            $this->view->generate('role_view.php', array('settings' => $settings));
        }
    }

    public function action_get_role_info()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Role();
            $this->model->setRequestData($this->data);
            die($this->model->getRole());
        }
    }

    public function action_edit_role_info()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Role();
            $this->model->setRequestData($this->data);
            if ($this->model->EditRole()) {
                die('1');
            } else {
                die('0');
            }
        }
    }

    public function action_role_delete()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Role();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteRole()) {
                die('1');
            } else {
                die('0');
            }
        }
    }
}

?>