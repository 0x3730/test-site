<?php
session_start();

class Controller_Edit_Group extends Controller
{
    public function action_index()
    {
        if (Authorization::checkLogin()) {
            $this->model = new Model_Edit_Role();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/edit_group.js'));
            $this->view->generate('edit_group_view.php', array('settings' => $settings));
        }
    }

    public function action_get_group_info()
    {
        $this->model = new Model_Edit_Role();
        $this->model->setRequestData($this->data);
        die($this->model->getGroup());
    }

    public function action_edit_group()
    {
        $this->model = new Model_Edit_Role();
        $this->model->setRequestData($this->data);
        if ($this->model->EditGroup()) {
            die('1');
        } else {
            die('0');
        }
    }

    public function action_group_delete()
    {
        $this->model = new Model_Edit_Role();
        $this->model->setRequestData($this->data);
        if ($this->model->deleteGroup()) {
            die('1');
        } else {
            die('0');
        }
    }
}

?>