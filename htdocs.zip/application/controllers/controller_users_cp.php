<?php
session_start();

class Controller_Users_CP extends Controller
{
    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/users_cp.js'));
            $this->view->generate('users_cp_view.php', array('settings' => $settings));
        //}
    }

    public function action_get_users_list()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            die($this->model->getUsers());
        //}
    }

    public function action_get_roles_list()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            die($this->model->getRoles());
        //}
    }

    public function action_get_roles_list_view()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            die($this->model->getRolesView());
        //}
    }

    public function action_add_new_user()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            if ($this->model->CreateUser()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }

    public function action_user_delete()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteUser()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }

    public function action_add_new_role()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            if ($this->model->CreateRole()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }

    public function action_role_delete()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Users_CP();
            $this->model->setRequestData($this->data);
            if ($this->model->deleteRole()) {
                die('1');
            } else {
                die('0');
            }
        //}
    }
}

?>