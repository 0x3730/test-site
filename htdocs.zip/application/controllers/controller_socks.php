<?php
session_start();

class Controller_Socks extends Controller
{

    public function action_index()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Socks();
            $this->model->setRequestData($this->data);
            $settings = $this->model->getSettings();
            $this->view->addJavaScripts(array('js/pages/socks.js'));
            $this->view->generate('socks_view.php', array('settings' => $settings));
        //}
    }

    public function action_getsocks()
    {
        //if (Authorization::checkLogin()) {
            $this->model = new Model_Socks();
            $this->model->setRequestData($this->data);
            die($this->model->getSocks());
        //}
    }
}