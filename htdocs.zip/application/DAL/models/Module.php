<?php
namespace DAL\Models
{
    class Module
    {

    }
}