<?php
namespace DAL\Models
{
    class Bot
    {

    }
}