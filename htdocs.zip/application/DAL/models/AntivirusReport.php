<?php
namespace DAL\Models
{
    class AntivirusReport
    {

    }
}