<?php
namespace DAL\Models
{
    class FirewallReport
    {

    }
}