<?php

abstract class ModuleStatus
{
    const NotActive = 0;
    const Active = 1;
    const ConstantlyActive = 2;
}
