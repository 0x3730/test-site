<?php

abstract class TaskStatus
{
    const Active = 0;
    const Stopped = 1;
    const Completed = 2;
    const Paused = 3;
}