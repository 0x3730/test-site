<?php

abstract class LogLevel
{
    const Trace = 0;
    const Warning = 1;
    const Error = 2;
    const CriticalError = 3;
}