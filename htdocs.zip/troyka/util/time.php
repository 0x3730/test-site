<?php
	function CalcTime($t_Date, $b_Type)
	{
		$seconds = 0;
	
		if($b_Type)
			$seconds = time() - strtotime($t_Date);
		else
			$seconds = strtotime($t_Date) - time();
	
		$times = [
			'seconds' => $seconds,
			'minutes' => 0,
			'hours' => 0,
			'days' => 0,
			'years' => 0
		];

		$minutes = floor($seconds / 60);
		if ($minutes > 0) {
			$seconds -= $minutes * 60;

			$times['seconds'] = $seconds;
			$times['minutes'] = $minutes;

			$hours = floor($minutes / 60);
			if ($hours > 0) {
				$minutes -= $hours * 60;

				$times['minutes'] = $minutes;
				$times['hours'] = $hours;

				$days = floor($hours / 24);
				if ($days > 0) {
					$hours -= $days * 24;

					$times['hours'] = $hours;
					$times['days'] = $days;

					$years = floor($days / 365);
					if ($years > 0) {
						$days -= $years * 365;

						$times['days'] = $days;
						$times['years'] = $years;
					}
				}
			}
		}
	
		if($times['years'] > 0)
			return $times['years']."y ".$times['days']."d";
		else if($times['days'] > 0)
			return $times['days']."d ".$times['hours']."h";
		else if($times['hours'] > 0)
			return $times['hours']."h ".$times['minutes']."m";
		else if($times['minutes'] > 0)
			return $times['minutes']."m ".$times['seconds']."s";
		else
			return $times['seconds']."s";
	}
?>