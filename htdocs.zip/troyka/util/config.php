<?php
	session_start();
	date_default_timezone_set("Europe/Moscow");
	
	$PDO_DBNAME = "troyka";
	$PDO_DBLOGIN = "root";
	$PDO_DBPASS = "";
	$ADMIN_LOGIN = "admin";
	$ADMIN_PASS = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8";
	
	try 
	{
		$PDOConnection = new PDO("mysql:host=localhost;dbname={$PDO_DBNAME}", $PDO_DBLOGIN, $PDO_DBPASS);
	} catch (PDOException $e)
	{
		print "Error!: " . $e->getMessage();
		die();
	}
?>