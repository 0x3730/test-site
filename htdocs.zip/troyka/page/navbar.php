<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="./css/navbar.css">
		<title>Admin Panel</title>
	</head>
			
	<body>
		<div class="navbar-container">
			<?php
				$s_GetPage = $_GET["pg"];
				
				if($s_GetPage == "db" or $s_GetPage == "")
					echo "<a class=\"link-selected\" href=\"index.php?pg=db\">Dashboard</a>";
				else
					echo "<a href=\"index.php?pg=db\">Dashboard</a>";
				
				if($s_GetPage == "bs")
					echo "<a class=\"link-selected\" href=\"index.php?pg=bs\">Bots</a>";
				else
					echo "<a href=\"index.php?pg=bs\">Bots</a>";
				
				if($s_GetPage == "cs")
					echo "<a class=\"link-selected\" href=\"index.php?pg=cs\">Commands</a>";
				else
					echo "<a href=\"index.php?pg=cs\">Commands</a>";		

				echo "<a href=\"index.php?pg=lt\">Logout</a>";					
			?>
		</div>
	</body>
</html>