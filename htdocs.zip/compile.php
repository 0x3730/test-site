<?php

require_once('application/modules/protobuf/parser/pb_parser_v2.php');
$test = new PBParser();
$test->parse('application/modules/protobuf/protocol.proto');